import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import NavbarCandidat from "./Components/CandidatProfil/NavbarCandidat";
import Sidebar from "./Components/CandidatProfil/Sidebar";
import MyProfil from "./Components/CandidatProfil/MyProfil";
import MyApplications from "./Components/CandidatProfil/MyApplications";
import Settings from "./Components/CandidatProfil/Settings";
import Notifications from "./Components/CandidatProfil/Notifications";

const ProfilApp = () => {
  return (
    <Router>
      <div>
        <NavbarCandidat />
        <Sidebar />
        <div >
          <Routes>
            <Route path="/profile" element={<MyProfil />} />
            <Route path="/applications" element={<MyApplications />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/notifications" element={<Notifications />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
};

export default ProfilApp;
