import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import AuthForm from "./Components/FirstPage/AuthForm";
import Accueilpage from "./Components/FirstPage/Accueilpage"
import ContactForm from './Components/FirstPage/ContactForm';
import CompanyForm from './Components/FirstPage/CompanyForm'

function App() {
  return (
    <Router>
      
      <Routes>
      
         <Route path="/" element={<Accueilpage  />} />
        <Route path="/auth" element={<AuthForm />} />
        <Route path="/contact" element={<ContactForm />} />
        <Route path="/register" element={<CompanyForm />} /> 

      </Routes>
    </Router>
  );
}

export default App;
