import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Outlet,
} from "react-router-dom";

import NavbarEntreprise from "./Components/Entreprise/NavbarEntreprise.jsx";
import AccueilEntreprise from "./Components/Entreprise/AccueilEntreprise.jsx";
import MyApplicationEntreprise from "./Components/ProfilEntreprise/MyApplicationEntreprise.jsx";
import MyProfilEntreprise from "./Components/ProfilEntreprise/MyProfilEntreprise.jsx";
import NotificationsEntreprise from "./Components/ProfilEntreprise/NotificationsEntreprise.jsx";
import SettingsEntreprise from "./Components/ProfilEntreprise/SettingsEntreprise.jsx";
import Details from "./Components/Entreprise/Details.jsx";
import Talents from "./Components/Entreprise/Talents.jsx";
import FeedBackEntreprise from "./Components/Entreprise/FeedBackEntreprise.jsx";

// Candidat imports
import Accueilpage from "./Components/FirstPage/Accueilpage.jsx";
import AuthForm from "./Components/FirstPage/AuthForm.jsx";
import CompanyForm from "./Components/FirstPage/CompanyForm.jsx";
import ContactForm from "./Components/FirstPage/ContactForm.jsx";
import Home from "./Components/CandidatHome/Home.jsx";
import FeedBack from "./Components/CandidatHome/FeedBack.jsx";
import Opportunities from "./Components/CandidatHome/Opportunities.jsx";
import Offre from "./Components/CandidatHome/Offre.jsx";

import MyProfile from "./Components/CandidatProfil/MyProfil.jsx";
import MyApplications from "./Components/CandidatProfil/MyApplications.jsx";
import Settings from "./Components/CandidatProfil/Settings.jsx";
import Notifications from "./Components/CandidatProfil/Notifications.jsx";

// Admin imports
import LogInAdmin from "./Components/Admin/LogInAdmin.jsx";
import NavbarAdmin from "./Components/Admin/NavbarAdmin.jsx";
import SidebarAdmin from "./Components/Admin/SidebarAdmin.jsx";
import FeedbackAdmin from "./Components/Admin/FeedbackAdmin.jsx";
import CompaniesAdmin from "./Components/Admin/CompaniesAdmin.jsx";
import CandidateAdmin from "./Components/Admin/CandidateAdmin.jsx";
import SettingsAdmin from "./Components/Admin/SettingsAdmin.jsx";
import JobOffersManagementAdmin from "./Components/Admin/JobOffersManagementAdmin.jsx";
import ApplicationsManagementAdmine from "./Components/Admin/ApplicationsManagementAdmin.jsx";
import JobOffersAdmin from "./Components/Admin/JobOffersAdmin.jsx";
import ApplicationAdmin from "./Components/Admin/ApplicationAdmin.jsx";
import AdminLayout from "./Components/Admin/AdminLayout.jsx";
import StatisticsAdmin from "./Components/Admin/StatisticsAdmin.jsx";
import Navbar from "./Components/CandidatProfil/NavbarCandidat.jsx";

const Layout = () => {
  return (
    <div>
      <Outlet />
    </div>
  );
};

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          {/*  Entreprise Routes */}
          <Route path="AccueilEntreprise" element={<AccueilEntreprise />} />
          <Route path="entreprise/profile" element={<MyProfilEntreprise />} />
          <Route
            path="entreprise/application"
            element={<MyApplicationEntreprise />}
          />
          <Route
            path="entreprise/notifications"
            element={<NotificationsEntreprise />}
          />
          <Route path="entreprise/settings" element={<SettingsEntreprise />} />
          <Route path="talents" element={<Talents />} />
          <Route path="talent/:name" element={<Details />} />
          <Route path="FeedBackEntreprise" element={<FeedBackEntreprise />} />
          {/* first page */}
          <Route path="/" element={<Accueilpage />} />
          <Route path="auth" element={<AuthForm />} />
          <Route path="register" element={<CompanyForm />} />
          <Route path="contact" element={<ContactForm />} />
          <Route path="feedback" element={<FeedBack />} />
          {/* candidat home */}
          <Route path="Home" element={<Home />} />
          <Route path="opportunities" element={<Opportunities />} />
          <Route path="offre/:id" element={<Offre />} />
          {/* candidat profilee */}
          <Route path="my-profile" element={<MyProfile />} />
          <Route path="applications" element={<MyApplications />} />
          <Route path="notifications" element={<Notifications />} />
          <Route path="settings" element={<Settings />} />
          <Route path="profile" element={<MyProfile />} />

          {/* Admin Layout */}
          <Route path="admin" element={<AdminLayout />}>
            <Route path="/admin/login" element={<LogInAdmin />} />
            <Route path="/admin/companies" element={<CompaniesAdmin />} />
            <Route path="/admin/candidates" element={<CandidateAdmin />} />
            <Route
              path="/admin/applicationsAdmin"
              element={<ApplicationAdmin />}
            />
            <Route
              path="/admin/applications-management"
              element={<ApplicationsManagementAdmine />}
            />
            <Route
              path="/admin/job-offers-management"
              element={<JobOffersManagementAdmin />}
            />
            <Route path="/admin/job-offers" element={<JobOffersAdmin />} />
            <Route path="/admin/feedbackAdmin" element={<FeedbackAdmin />} />
            <Route
              path="/admin/StatisticsAdmin"
              element={<StatisticsAdmin />}
            />

            <Route path="/admin/settings" element={<SettingsAdmin />} />
          </Route>
        </Route>
      </Routes>
    </Router>
  </StrictMode>
);
