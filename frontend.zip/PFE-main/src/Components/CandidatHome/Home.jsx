import React, { useState, useEffect } from "react";
import axios from "axios";
import NavbarCandidat from "../CandidatProfil/NavbarCandidat";
import Footer from "../FirstPage/Footer";
import rectengleright from "../../assets/rectengleright.png";
import {
  FaBriefcase,
  FaBuilding,
  FaMapMarkerAlt,
  FaFileContract,
  FaUserTie,
} from "react-icons/fa";
import { Link } from "react-router-dom";

const Home = () => {
  const [darkMode, setDarkMode] = useState(() => {
    return localStorage.getItem("theme") === "dark";
  });

  const [jobOffers, setJobOffers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
  }, [darkMode]);

  useEffect(() => {
    // Simulate static data
    const dummyOffers = [
      {
        id: 1,
        title: "Frontend Developer",
        company: "TechCorp",
        location: "New York",
        type: "Full-time",
        experience: "2+ years",
      },
      {
        id: 2,
        title: "Backend Developer",
        company: "Innovatech",
        location: "San Francisco",
        type: "Part-time",
        experience: "3+ years",
      },
      {
        id: 3,
        title: "UI/UX Designer",
        company: "DesignIt",
        location: "Berlin",
        type: "Internship",
        experience: "1+ year",
      },
    ];

    setJobOffers(dummyOffers);
    setLoading(false);
  }, []);

  return (
    <div className="bg-white text-black dark:bg-gray-900 dark:text-white min-h-screen">
      <NavbarCandidat darkMode={darkMode} setDarkMode={setDarkMode} />

      {/* Hero Section */}
      <section className="px-4 md:px-6 py-10 text-center">
        <h1 className="text-3xl md:text-5xl font-bold mt-12 font-[Inria-Serif]">
          WELCOME TO THE TALENT ECOSYSTEM
        </h1>

        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row items-center text-left mt-16 md:mt-32 gap-10 md:gap-[10px]">
            <p className="size- md:text-[44px] leading-[170%] font-[poppins] md:mr-20">
              nextJob offers you the opportunity to find a job based on your
              skills and experience in the IT field
            </p>
            <img
              src={rectengleright}
              alt="Job Seekers"
              className="w-[300px] md:w-[400px] h-auto"
            />
          </div>
        </div>
      </section>

      {/* Job Offers Section */}
      <section className="flex flex-col items-center py-8 px-4">
        <h1 className="font-[Inria-Serif] font-medium text-4xl md:text-[64px] mt-8 mb-9 text-center uppercase">
          LAST OFFERS
        </h1>

        {loading && <p>Loading job offers...</p>}
        {error && <p className="text-red-600 dark:text-red-400">{error}</p>}

        {!loading && !error && (
          <div className="flex flex-col items-center mb-8 w-full max-w-5xl gap-4">
            {jobOffers.length === 0 ? (
              <p>No job offers found.</p>
            ) : (
              jobOffers.map((offer, index) => (
                <div
                  key={offer.id || offer._id}
                  className={`w-full md:w-[570px] ${
                    index % 2 === 0 ? "self-start" : "self-end"
                  }`}
                >
                  <div className="border-4 border-[#6688CC] rounded-xl p-6 shadow-md flex flex-col gap-3 bg-white dark:bg-gray-800">
                    <div className="flex items-center gap-2 font-[poppins] font-light text-lg md:text-[20px]">
                      <FaBriefcase className="text-[#3B5D8F] w-5 h-5" />
                      <h2 className="font-bold">{offer.title}</h2>
                    </div>

                    <div className="flex items-center gap-2 text-[#3B5D8F] text-sm md:text-[16px] font-medium ml-7 md:ml-11">
                      <FaBuilding className="w-4 h-4" />
                      <p>{offer.company}</p>
                    </div>

                    <div className="flex items-center gap-2 text-[#3B5D8F] font-[poppins] font-light ml-7 md:ml-11">
                      <FaMapMarkerAlt className="w-4 h-4" />
                      <span>{offer.location}</span>
                    </div>

                    <div className="flex gap-2 mt-2 justify-end h-7">
                      <span className="bg-[#3B5D8F]  text-white text-xs px-2 py-1 rounded-full flex items-center gap-1">
                        <FaFileContract className="w-3 h-3" />
                        {offer.type}
                      </span>
                      <span className="bg-[#3B5D8F] text-white text-xs px-2 py-1 rounded-full flex items-center gap-1">
                        <FaUserTie className="w-3 h-3" />
                        {offer.experience}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        <Link to="/Opportunities">
          <button className="bg-[#3B5D8F] text-white px-6 py-2 rounded-lg hover:bg-blue-700 mb-8 transition-colors w-40 h-12">
            More Offers
          </button>
        </Link>

        <p className="text-center mb-2 font-medium text-2xl md:text-[40px] font-[Inria-Serif]">
          Enjoying your experience?{" "}
          <span>We'd love to hear your feedback!</span>
        </p>
        <Link
          to="/feedback"
          className="text-lg md:text-[28px] mt-3 text-[#3B5D8F] dark:text-[#3B5D8F] font-bold underline hover:text-blue-700 dark:hover:text-blue-300"
        >
          Feedback Here!
        </Link>
      </section>

      <Footer />
    </div>
  );
};

export default Home;
