import { useState, useEffect } from "react";
import {
  FaSearch,
  FaBriefcase,
  FaBuilding,
  FaMapMarkerAlt,
  FaFileContract,
  FaUserTie,
} from "react-icons/fa";
import { BsStars } from "react-icons/bs";
import { FaAngleRight } from "react-icons/fa6";
import NavbarCandidat from "../CandidatProfil/NavbarCandidat";
import Footer from "../../Components/FirstPage/Footer";
import imgHome from "../../assets/imgHome.png";
import { Link } from "react-router-dom";
import axios from "axios";

const educationLevels = ["High School", "Bachelor", "Master", "PhD"];
const domains = ["IT", "Finance", "Marketing", "Engineering", "Healthcare"];
const experienceYears = ["0-2 years", "3-5 years", "6-10 years", "10+ years"];
const telecommutingOptions = ["Yes", "No"];

const Opportunities = () => {
  const [applications, setApplications] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [educationLevel, setEducationLevel] = useState("");
  const [domain, setDomain] = useState("");
  const [experience, setExperience] = useState("");
  const [telecommuting, setTelecommuting] = useState("");

  // Fetch opportunities from Django backend
  useEffect(() => {
    axios
      .get("/api/candidat/opportunities/") // Adjust the base URL if needed
      .then((res) => setApplications(res.data))
      .catch((err) => console.error("Failed to fetch opportunities", err));
  }, []);

  const filteredApplications = applications.filter((app) => {
    const matchesSearch = app.title
      .toLowerCase()
      .includes(searchTerm.toLowerCase());
    const matchesEducation = educationLevel
      ? app.educationLevel === educationLevel
      : true;
    const matchesDomain = domain ? app.domain === domain : true;
    const matchesExperience = experience ? app.experience === experience : true;
    const matchesTelecommuting = telecommuting
      ? app.telecommuting === (telecommuting === "Yes")
      : true;

    return (
      matchesSearch &&
      matchesEducation &&
      matchesDomain &&
      matchesExperience &&
      matchesTelecommuting
    );
  });

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <NavbarCandidat />
      <div className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="flex flex-col md:flex-row items-center justify-between mb-12 ml-12 dark:text-white">
          <div className="md:w-1/2">
            <h1 className="font-semibold text-[52px] font-['Inria-Serif']">
              We are hiring!
            </h1>
            <p className="font-medium text-[23px] font-['Poppins'] max-w-[290px] mt-5 ml-2">
              A job can change a life...
              <br />
              Yours may be just down the road
            </p>
          </div>
          <div className="md:w-1/2 flex justify-center mt-5">
            <img
              src={imgHome}
              alt="Career opportunities"
              className="w-full max-w-md"
            />
          </div>
        </div>

        {/* Search and Filter Section */}
        <div className="mb-8 flex justify-center">
          <form onSubmit={(e) => e.preventDefault()} className="space-y-6 w-full max-w-4xl">
            {/* Search Bar */}
            <div className="flex items-center">
              <div className="relative flex-1">
                <FaSearch className="absolute left-4 top-1/2 transform -translate-y-1/2 text-black" />
                <input
                  type="text"
                  placeholder="Name a job, keywords"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 border-4 border-[#3B5D8F] rounded-[11px] font-[poppins]"
                />
              </div>
              <button
                type="submit"
                className="ml-4 h-[50px] bg-[#3B5D8F] text-white hover:bg-blue-600 px-6 py-3 rounded-[11px] font-[poppins] font-semibold"
              >
                Search
              </button>
            </div>

            <div className="text-center text-[29px] font-[poppins] font-medium dark:text-white">
              <p>or</p>
            </div>

            {/* Filters */}
            <div className="border-4 border-[#5786e3] rounded-lg flex flex-col md:flex-row">
              {/* Filters Column */}
              <div className="flex-1 bg-white p-6">
                <h3 className="text-[30px] font-bold font-[Inria-Serif] ml-24 mb-6">Filter</h3>

                <div className="space-y-4">
                  <div>
                    <h4 className="text-[24px] font-bold font-[poppins] ml-4 mb-2">
                      Education Level
                    </h4>
                    <select
                      value={educationLevel}
                      onChange={(e) => setEducationLevel(e.target.value)}
                      className="w-[330px] p-3 border-2 ml-2 border-[#5786e3] rounded-[11px] font-[Poppins]"
                    >
                      <option value="">Education level</option>
                      {educationLevels.map((level) => (
                        <option key={level} value={level}>
                          {level}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <h4 className="text-[24px] font-bold font-[poppins] ml-4 mb-2">
                      Domain
                    </h4>
                    <select
                      value={domain}
                      onChange={(e) => setDomain(e.target.value)}
                      className="w-[330px] p-3 border-2 ml-2 border-[#5786e3] rounded-[11px] font-[Poppins]"
                    >
                      <option value="">Domain</option>
                      {domains.map((d) => (
                        <option key={d} value={d}>
                          {d}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <h4 className="text-[24px] font-bold font-[poppins] ml-4 mb-2">
                      Experience
                    </h4>
                    <select
                      value={experience}
                      onChange={(e) => setExperience(e.target.value)}
                      className="w-[330px] p-3 border-2 ml-2 border-[#5786e3] rounded-[11px] font-[Poppins]"
                    >
                      <option value="">Years of Experience</option>
                      {experienceYears.map((exp) => (
                        <option key={exp} value={exp}>
                          {exp}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <h4 className="text-[20px] font-bold font-[poppins] ml-4 mb-2">
                      Telecommuting
                    </h4>
                    <select
                      value={telecommuting}
                      onChange={(e) => setTelecommuting(e.target.value)}
                      className="w-[330px] p-3 border-2 ml-2 border-[#5786e3] rounded-[11px] font-[Poppins]"
                    >
                      <option value="">Select Option</option>
                      {telecommutingOptions.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* For Me Button */}
              <div className="bg-gradient-to-b from-[#ACBFE6] to-[#6587CB] flex items-center justify-center p-6 md:w-[450px]">
                <button
                  type="button"
                  className="bg-[#3B5D8F] text-white px-8 py-4 rounded-[11px]  hover:bg-blue-600 dark:hover:bg-blue-400 transition-colors font-[poppins] text-lg flex items-center space-x-2"
                  onClick={() => {
                    // Maybe a quick filter for "For Me" - e.g. education = Bachelor, domain = IT as example
                    setEducationLevel("Bachelor");
                    setDomain("IT");
                    setExperience("");
                    setTelecommuting("");
                    setSearchTerm("");
                  }}
                >
                  <span>For me</span>
                  <BsStars className="text-white text-2xl" />
                </button>
              </div>
            </div>
          </form>
        </div>

        {/* Filtered Job Opportunities */}
        <div className="max-w-5xl mx-auto space-y-8 border-4 h-auto w-[820px] mt-16 border-[#5786e3] rounded-[11px]">
          {filteredApplications.length === 0 ? (
            <p className="text-center font-[poppins] mt-8 text-[23px] text-black">
              No results found.
            </p>
          ) : (
            filteredApplications.map((app, index) => (
              <div
                key={index}
                className="p-6 border-2 border-[#5786e3] bg-white rounded-xl w-2/3 ml-[140px] mt-9"
              >
                <Link
                  to={`/offre/${app.id || index}`}
                  className="font-[Poppins] font-semibold text-[21px] flex items-center gap-2 text-black hover:text-blue-600"
                >
                  <FaBriefcase className="text-[#3B5D8F]" />
                  {app.title}
                </Link>

                <p className="font-[Poppins] text-[#3B5D8F] font-medium text-[15px] ml-5 mt-3 flex items-center gap-2">
                  <FaBuilding />
                  {app.company}
                </p>
                <p className="font-[Poppins] text-[#3B5D8F] mt-3 font-medium text-[15px] ml-5 flex items-center gap-2">
                  <FaMapMarkerAlt />
                  {app.location}
                </p>
                <div className="mt-4 flex flex-wrap gap-3 text-sm font-[poppins] items-center">
                  <span className="bg-[#6587CB] text-white ml-[260px] px-3 py-1 rounded-full flex items-center gap-2">
                    <FaFileContract />
                    {app.contract}
                  </span>
                  <span className="bg-[#6587CB] text-white px-3 py-1 rounded-full flex items-center gap-2">
                    <FaUserTie />
                    {app.experience}
                  </span>
                </div>
              </div>
            ))
          )}
          <p className="text-[18px] ml-[400px] font-semibold inline-flex items-center gap-1">
            1 <FaAngleRight className="mt-1" />
          </p>
        </div>
      </div>
      <div className="mt-[115px]">
        <Footer />
      </div>
    </div>
  );
};

export default Opportunities;
