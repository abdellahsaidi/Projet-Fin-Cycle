import React, { useEffect, useState } from "react";
import NavbarCandidat from "../CandidatProfil/NavbarCandidat";
import {
  FaMapMarkerAlt,
  FaFacebook,
  FaGithub,
  FaLinkedin,
} from "react-icons/fa";
import { MdEmail } from "react-icons/md";
import { FiPhone } from "react-icons/fi";
import { HiBuildingOffice2 } from "react-icons/hi2";
import Footer from "../../Components/FirstPage/Footer";
import axios from "axios";

const Offre = ({ offerId }) => {
  const [offer, setOffer] = useState(null);
  const [loading, setLoading] = useState(true);
  const [applyStatus, setApplyStatus] = useState(null);

  // Get token from localStorage (or context/state)
  const token = localStorage.getItem("token");

  useEffect(() => {
    // Fetch job offer details from API
    const fetchOffer = async () => {
      try {
        setLoading(true);
        const response = await axios.get(
          `http://your-django-api.com/candidat/offers/${offerId}/`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setOffer(response.data);
      } catch (error) {
        console.error("Error fetching offer:", error);
      } finally {
        setLoading(false);
      }
    };

    if (offerId && token) {
      fetchOffer();
    }
  }, [offerId, token]);

  const handleApply = async () => {
    try {
      setApplyStatus("loading");
      await axios.post(
        `http://your-django-api.com/offers/${offerId}/apply/`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setApplyStatus("success");
    } catch (error) {
      console.error("Apply failed:", error);
      setApplyStatus("error");
    }
  };

  if (loading) return <p>Loading offer...</p>;

  if (!offer) return <p>Offer not found or not accessible.</p>;

  return (
    <div className="font-poppins bg-[#f4f6fa] dark:bg-gray-900 min-h-screen">
      <NavbarCandidat />

      {/* Company Header */}
      <div className="w-full bg-gradient-to-r from-[#415C99] to-[#6587CB] text-white px-4 py-8 border-b">
        <div className="max-w-7xl mx-auto md:ml-28 h-[160px] flex flex-col md:flex-row items-center md:items-start justify-center md:justify-start">
          <div className="bg-white dark:bg-gray-900 border rounded-xl mt-24 h-[150px] w-[130px] shadow-[0_4px_4px_0_rgba(0,0,0,0.64)] p-4 mr-4 flex flex-col items-center">
            <HiBuildingOffice2 className="text-black dark:text-white text-[68px] mb-2" />
            <div className="flex dark:text-white justify-center gap-4 mt-2 text-[#415C99] text-[18px]">
              <FaFacebook className="cursor-pointer text-[22px] hover:text-blue-600" />
              <FaGithub className="cursor-pointer text-[22px] hover:text-black" />
              <FaLinkedin className="cursor-pointer text-[22px] hover:text-blue-500" />
            </div>
          </div>

          <div className="text-center md:text-left mt-24">
            <h1 className="font-bold text-[32px]">
              {offer.company_name || "Company Name"}
            </h1>
            <div className="flex flex-wrap justify-center md:justify-start items-center text-white text-[18px] mt-2 gap-x-4 gap-y-1">
              <span className="flex items-center gap-1">
                <FaMapMarkerAlt /> {offer.location || "Alger, Algeria"}
              </span>
              <span>|</span>
              <span className="flex items-center gap-1">
                <MdEmail /> {offer.email || "contact@company.com"}
              </span>
              <span>|</span>
              <span className="flex items-center gap-1">
                <FiPhone /> {offer.phone || "+213 59 XX XX XX"}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Job Details Section */}
      <div className="max-w-4xl mt-20 mx-auto px-4 py-10">
        <div className="w-full bg-[#3B5D8F] rounded-tl-lg rounded-tr-lg">
          <h1 className="text-white font-[poppins] ml-8 font-semibold text-[34px] py-4">
            {offer.title || "Job Title"}
          </h1>
        </div>

        <div className="bg-[#91aee9] rounded-bl-lg rounded-br-lg h-auto shadow-lg p-8">
          <div className="flex flex-col md:flex-row justify-between mb-6">
            <div className="flex flex-col gap-2">
              <div className="flex items-center mt-6">
                <span className="font-[poppins] font-semibold text-[19px]">
                  Location :{" "}
                </span>
                <FaMapMarkerAlt className="text-black ml-1" />
                <span className="ml-2 font-[poppins] font-normal text-[16px]">
                  {offer.location}
                </span>
              </div>
              <div className="flex items-center gap-1">
                <span className="font-[poppins] font-semibold text-[19px] mt-3">
                  Number of positions:
                </span>
                <span className="ml-2 font-[poppins] font-normal text-[16px] mt-3">
                  {offer.positions_available}
                </span>
              </div>
              <div className="flex items-center gap-1">
                <span className="font-[poppins] font-semibold text-[19px] mt-3">
                  Education level:
                </span>
                <span className="ml-2 font-[poppins] font-normal text-[16px] mt-3">
                  {offer.education_level}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1 mr-14 mb-16 md:mt-0">
              <span className="font-[poppins] font-normal text-[19px]">
                Contract type:
              </span>
              <span className="ml-2 font-[poppins] font-normal text-[16px]">
                {offer.contract_type}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1 mb-6">
            <span className="font-[poppins] font-semibold text-[19px]">
              Expiration date:
            </span>
            <span className="ml-2 font-[poppins] font-normal text-[16px]">
              {offer.expiration_date}
            </span>
          </div>

          <hr className="w-[95vh] -ml-7" />

          {/* Requirements */}
          <div className="mb-8 font-[poppins]">
            <h2 className="text-xl font-semibold mb-6 mt-8 tracking-[0.12em]">
              Requirements :
            </h2>
            <ul className="list-disc pl-6 space-y-3 font-normal text-[17px]">
              {offer.requirements?.map((req, idx) => (
                <li key={idx}>{req}</li>
              ))}
            </ul>
          </div>

          {/* Advantages */}
          <div className="mb-8 font-[poppins]">
            <h2 className="text-xl font-semibold mb-3 tracking-[0.12em]">
              Advantages :
            </h2>
            <ul className="list-disc pl-6 space-y-4 font-normal text-[17px]">
              {offer.advantages?.map((adv, idx) => (
                <li key={idx}>{adv}</li>
              ))}
            </ul>
          </div>

          {/* Apply Button */}
          <div className="text-center">
            <button
              onClick={handleApply}
              className="bg-[#415C99] ml-[660px] font-[poppins] w-[120px] hover:bg-blue-600 text-white font-semibold py-3 px-8 rounded-full transition duration-300 shadow-md"
              disabled={applyStatus === "loading"}
            >
              {applyStatus === "loading"
                ? "Applying..."
                : applyStatus === "success"
                ? "Applied"
                : "Apply"}
            </button>
            {applyStatus === "error" && (
              <p className="text-red-600 mt-2">
                Failed to apply. Please try again.
              </p>
            )}
          </div>
        </div>
      </div>

      <div className="mt-[115px]">
        <Footer />
      </div>
    </div>
  );
};

export default Offre;
