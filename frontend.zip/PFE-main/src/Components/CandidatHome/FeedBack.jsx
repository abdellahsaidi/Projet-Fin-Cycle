import React, { useState } from "react";
import axios from "axios";
import { FiMapPin, FiPhone, FiMail } from "react-icons/fi";
import NavbarCandidat from "../CandidatProfil/NavbarCandidat";
import Footer from "../FirstPage/Footer";

const API_BASE = "http://localhost:8000/api"; // <-- replace with your actual API base URL

export default function FeedBack() {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    message: "",
  });

  const [status, setStatus] = useState({
    loading: false,
    success: null,
    error: null,
  });

  const [darkMode, setDarkMode] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.firstName || !formData.email || !formData.message) {
      setStatus({
        loading: false,
        success: null,
        error: "Please fill in required fields!",
      });
      return;
    }

    setStatus({ loading: true, success: null, error: null });

    try {
      const token = localStorage.getItem("token");

      const response = await axios.post(
        `${API_BASE}/candidate/feedback/`,
        formData,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: token ? `Bearer ${token}` : "",
          },
        }
      );

      setStatus({
        loading: false,
        success: "Message sent successfully!",
        error: null,
      });

      setFormData({
        firstName: "",
        lastName: "",
        email: "",
        phone: "",
        message: "",
      });
    } catch (err) {
      let message =
        err.response?.data?.detail || err.message || "Failed to send message";

      setStatus({
        loading: false,
        success: null,
        error: message,
      });
    }
  };

  return (
    <div
      className={
        darkMode
          ? "dark bg-gray-900 min-h-screen"
          : "bg-white min-h-screen dark:bg-gray-900"
      }
    >
      <NavbarCandidat darkMode={darkMode} setDarkMode={setDarkMode} />

      <div className="relative flex flex-col md:flex-row font-[poppins] bg-[#ACBFE6] rounded-2xl p-6 gap-4 max-w-5xl mx-auto mt-28 h-[58vh]">
        {/* Left Side - Contact Info */}
        <div className="absolute -left-24 bg-[#3B5D8F] text-white p-6 rounded-2xl flex flex-col justify-center items-start gap-4 h-[392px]">
          <h2 className="font-semibold text-[21px] leading-[100%] text-center ml-8 mb-9">
            Contact Info:
          </h2>

          <div className="flex items-center mb-8 ml-8 gap-2">
            <FiMapPin />
            <p>Alger, Blida, USDB</p>
          </div>

          <div className="flex items-center mb-7 ml-8 gap-2">
            <FiPhone />
            <p>+231 59 XX XX XX</p>
          </div>

          <div className="flex items-center ml-8 gap-2">
            <FiMail />
            <p>contact@nextJob.com</p>
          </div>
        </div>

        {/* Right Side - Message Form */}
        <div className="flex-1 p-4 absolute left-48">
          <h2 className="font-semibold text-[23px] ml-4 mb-8 tracking-[0.02em]">
            Send Message:
          </h2>
          <form onSubmit={handleSubmit} className="flex flex-col gap-8">
            <div className="flex flex-col md:flex-row">
              <input
                type="text"
                name="firstName"
                placeholder="First Name"
                value={formData.firstName}
                onChange={handleChange}
                className="border-b border-black w-[39vh] text-color-black outline-none bg-transparent placeholder:text-black"
              />
              <input
                type="text"
                name="lastName"
                placeholder="Last Name"
                value={formData.lastName}
                onChange={handleChange}
                className="border-b border-black w-[39vh] ml-24 outline-none bg-transparent placeholder:text-black"
              />
            </div>
            <div className="flex flex-col md:flex-row">
              <input
                type="email"
                name="email"
                placeholder="Your Email"
                value={formData.email}
                onChange={handleChange}
                className="border-b border-black w-[39vh] outline-none bg-transparent placeholder:text-black"
              />
              <input
                type="tel"
                name="phone"
                placeholder="Your Phone number"
                value={formData.phone}
                onChange={handleChange}
                className="border-b border-black w-[39vh] ml-24 outline-none bg-transparent placeholder:text-black"
              />
            </div>
            <textarea
              name="message"
              placeholder="write your message here ......"
              value={formData.message}
              onChange={handleChange}
              className="border-b border-black outline-none bg-[#ACBFE6] h-24 resize-none placeholder:text-black"
            />
            <div className="ml-[500px] h-[90px] justify-around flex">
              <button
                type="submit"
                className="bg-[#3B5D8F] font-semibold text-white px-6 py-2 mt-11 rounded-xl hover:bg-blue-600 transition-all"
                disabled={status.loading}
              >
                {status.loading ? "Sending..." : "Send"}
              </button>
            </div>
            {status.error && (
              <p className="text-red-600 text-xl top-80 absolute">
                {status.error}
              </p>
            )}
            {status.success && (
              <p className="text-green-600 left-10 text-xl top-80 absolute">
                {status.success}
              </p>
            )}
          </form>
        </div>
      </div>

      <div className="mt-[160px]">
        <Footer />
      </div>
    </div>
  );
}
