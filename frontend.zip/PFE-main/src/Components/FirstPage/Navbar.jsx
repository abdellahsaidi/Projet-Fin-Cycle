import React from "react";
import { FaSun, FaMoon } from "react-icons/fa";
import { Link, useLocation } from "react-router-dom";
import logo from "../../assets/logo.png";

const Navbar = ({ darkMode, setDarkMode }) => {
  const location = useLocation();

  const isAuthPage =
    location.pathname === "/auth" || location.pathname.startsWith("/register");

  const navbarClass = isAuthPage
    ? darkMode
      ? "bg-[#ACBFE6] text-black "
      : "bg-blue-200 text-black "
    : darkMode
    ? "bg-gray-900 text-white "
    : "bg-white text-black";

  return (
    <nav
      className={`flex items-center justify-between px-6 py-4 shadow-md dark:shadow-lg ${navbarClass}`}
    >
      <div className="flex items-center space-x-2">
        <Link to="/">
          <img src={logo} alt="nextJob logo" className="h-18" />
        </Link>
      </div>

      <div className="flex items-center space-x-4">
        <Link to="/auth?mode=register">
          <button className="border-4 border-[#3B5D8F] dark:border-blue-300 dark:text-white rounded-full px-4 py-1 text-[19px] font-semibold font-[poppins] hover:bg-blue-600 ">
            Register
          </button>
        </Link>

        <Link to="/auth?mode=login">
          <button className="border-4 border-[#3B5D8F] dark:border-blue-300 dark:text-white rounded-full px-4 py-1 text-[19px] font-semibold font-[poppins] hover:bg-blue-600  ">
            Login
          </button>
        </Link>
        <button onClick={() => setDarkMode(!darkMode)}>
          {darkMode ? (
            <FaSun className="text-yellow-400 hover:bg-gray-200 transition-colors dark:hover:bg-gray-700 rounded-full text-[25px]  " />
          ) : (
            <FaMoon className="text-black hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors dark:text-white rounded-full text-[25px]  " />
          )}
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
