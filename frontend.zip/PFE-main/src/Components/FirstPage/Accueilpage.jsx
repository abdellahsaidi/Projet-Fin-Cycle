import React, { useState, useEffect } from "react";
import Navbar from "../FirstPage/Navbar";
import Footer from "../FirstPage/Footer";
import { Link } from "react-router-dom";
import axios from "axios";
import rectengleleft from "../../assets/rectengleleft.png";
import rectengleright from "../../assets/rectengleright.png";
import {
  FaBriefcase,
  FaBuilding,
  FaMapMarkerAlt,
  FaFileContract,
  FaUserTie,
} from "react-icons/fa";

const Accueilpage = () => {
  const [darkMode, setDarkMode] = useState(() => {
    return localStorage.getItem("theme") === "dark";
  });

  const [jobOffers, setJobOffers] = useState([]);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
  }, [darkMode]);

  useEffect(() => {
    const fetchOffers = async () => {
      try {
        const token = localStorage.getItem("token"); // récupère le token JWT s'il existe
        const response = await axios.get("http://localhost:8000/api/home/", {
          headers: {
            Authorization: token ? `Bearer ${token}` : undefined,
          },
        });
        setJobOffers(response.data); // suppose que c'est une liste d'offres [{ title, company, location, ... }]
      } catch (error) {
        console.error("Erreur lors de la récupération des offres :", error);
      }
    };

    fetchOffers();
  }, []);

  return (
    <div className="bg-white text-black dark:bg-gray-900 dark:text-white min-h-screen">
      {/* Navbar */}
      <Navbar darkMode={darkMode} setDarkMode={setDarkMode} />

      {/* Main Section */}
      <section className="px-6 py-10 text-center">
        <h1 className="text-5xl font-bold mt-12 font-[Inria-Serif]">
          WELCOME TO THE TALENT ECOSYSTEM
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 max-w-6xl mx-auto">
          {/* Job Seekers */}
          <div className="flex flex-col items-center space-y-8 text-left mt-22">
            <p className="font-medium text-[30px] leading-[130%] tracking-[2%] font-[Poppins] max-w-sm mr-32 mt-32 mb-11">
              nextJob offers you the opportunity to find a job based on your
              skills and experience in the IT field
            </p>
            <img
              src={rectengleleft}
              alt="Job Seekers"
              className="w-[400px] h-auto mr-32 mt-22"
            />
          </div>

          {/* Recruiters */}
          <div className="flex flex-col items-center space-y-4 text-left mt-11">
            <img
              src={rectengleright}
              alt="Recruiters"
              className="w-[400px] h-auto"
            />
            <p className="font-medium text-[30px] leading-[130%] tracking-[2%] font-[Poppins] max-w-sm ml-[80px]">
              This site gives recruiters the opportunity to find talent with the
              skills required for an open position
            </p>
            <span className="font-medium text-[23px] font-[Poppins] ml-[37px]">
              You are a recruiter?{" "}
              <Link
                to="/register?mode=register"
                className="text-[#3B5D8F] dark:text-blue-400 font-semibold hover:underline"
              >
                Register!
              </Link>
            </span>
          </div>
        </div>
      </section>

      {/* Job Offers Section */}
      <section className="flex flex-col items-center py-8 px-4">
        <h1 className="font-[Inria-Serif] font-medium text-[64px] text-center uppercase">
          LAST OFFERS
        </h1>

        <div className="flex flex-col items-center mb-8 w-full max-w-5xl gap-2">
          {jobOffers.map((offer, index) => (
            <div
              key={index}
              className={`flex ${
                index % 2 === 0 ? "justify-start" : "justify-end"
              } w-full`}
            >
              <div className="border-4 border-[#6688CC] rounded-xl p-6 w-[570px] shadow-md flex flex-col gap-3 mb-8">
                <div className="flex items-center gap-2 font-[poppins] font-light text-[20px]">
                  <FaBriefcase className="text-[#3B5D8F] w-5 h-5" />
                  <h2 className="font-bold text-md">{offer.title}</h2>
                </div>

                <div className="flex items-center gap-2 text-[#3B5D8F] text-[16px] font-medium ml-11">
                  <FaBuilding className="w-4 h-4" />
                  <p>{offer.company}</p>
                </div>

                <div className="flex items-center gap-2 text-[#3B5D8F] font-[poppins] font-light ml-11">
                  <FaMapMarkerAlt className="w-4 h-4" />
                  <span>{offer.location}</span>
                </div>

                <div className="flex gap-2 mt-2 justify-end h-7">
                  <span className="bg-[#3B5D8F] text-white text-xs px-2 py-1 rounded-full flex items-center gap-1">
                    <FaFileContract className="w-3 h-3" />
                    {offer.type}
                  </span>
                  <span className="bg-[#3B5D8F] text-white text-xs px-2 py-1 rounded-full flex items-center gap-1">
                    <FaUserTie className="w-3 h-3" />
                    {offer.experience}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <button className="bg-[#3B5D8F] text-white px-6 py-2 rounded-lg hover:bg-blue-600 mb-8 transition-colors w-40 h-12">
          More Offers
        </button>

        <p className="text-center mb-2 font-medium text-[40px] font-[Inria-Serif]">
          Enjoying your experience?{" "}
          <span>We'd love to hear your feedback!</span>
        </p>
        <Link
          to="/contact"
          className="text-[28px] mt-3 text-[#2b589c] dark:text-blue-400 font-bold underline hover:text-blue-600 dark:hover:text-blue-300"
        >
          Feedback Here!
        </Link>
      </section>

      <Footer />
    </div>
  );
};

export default Accueilpage;
