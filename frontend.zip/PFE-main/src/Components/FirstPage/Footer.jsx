import React from "react";
import { Link } from "react-router-dom";
import logo from "../../assets/logo.png";
import { FaMapMarkerAlt, FaPhone, FaCopyright } from "react-icons/fa";
import { SlArrowRight } from "react-icons/sl";
import { IoMailOutline } from "react-icons/io5";
import { FaFacebookF, FaXTwitter, FaLinkedinIn } from "react-icons/fa6";

const Footerentreprise = () => {
  return (
    <footer className="p-6 font-[poppins] shadow-[inset_0px_4px_4px_0px_rgba(0,0,0,0.25)] bg-white text-black dark:bg-gray-900 dark:text-white">
      <div>
        {/* Main Footer Content */}
        <div className="flex flex-col md:flex-row ml-[50px] gap-11">
          {/* Brand Info */}
          <div className="ml-2">
            <img src={logo} alt="nextJob logo" className="h-18" />
            <p className="font-medium text-[20px] w-[230px] ml-4">
              nextJob.com is a professional internet portal dedicated to
              employment and recruitment
            </p>
          </div>

          {/* Links Sections */}
          <div className="flex gap-12 min-w-[300px]">
            {/* Candidate Area */}
            <div className="ml-[450px] mt-12">
              <h3 className="font-bold mb-3 text-[23px] text-[#3B5D8F] dark:text-blue-400">
                For Job Seekers
              </h3>
              <ul>
                <li className="flex items-center mb-4">
                  <SlArrowRight className="mr-3 size-4" />
                  <Link to="/talents" className="font-semibold hover:underline">
                    Browse Talents
                  </Link>
                </li>
                <li className="flex items-center">
                  <SlArrowRight className="mr-3 size-4" />
                  <Link
                    to="/entreprise/profile"
                    className="font-semibold hover:underline"
                  >
                    Profil Settings
                  </Link>
                </li>
                <li className="flex items-center mt-4">
                  <SlArrowRight className="mr-3 size-4" />
                  <Link
                    to="/FeedBackEntreprise"
                    className="font-semibold hover:underline"
                  >
                    Support & Feedback
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          {/* About Us */}
          <div className="mt-12 ml-[480px]">
            <h3 className="font-bold mb-3 text-[23px] text-[#3B5D8F] dark:text-blue-400 ml-9">
              About Us
            </h3>
            <div className="space-y-4">
              <div className="flex items-start">
                <FaMapMarkerAlt className="mr-2 size-4" />
                <span className="font-semibold">Alger, Blida, USDB</span>
              </div>
              <div className="flex items-start">
                <IoMailOutline className="mr-2 size-5 mt-1" />
                <span className="font-semibold">contact@nextJob.com</span>
              </div>
              <div className="flex items-center">
                <FaPhone className="mr-2" />
                <span className="font-semibold ml-2">06 97 71 06 05</span>
              </div>
            </div>

            {/* Social Media Icons */}
            <div className="flex gap-9 mt-6 ml-7">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#3B5D8F] dark:text-blue-400 hover:text-blue-600 dark:hover:text-white"
              >
                <FaFacebookF className="size-5" />
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#3B5D8F] dark:text-blue-400 hover:text-blue-600 dark:hover:text-white"
              >
                <FaXTwitter className="size-5" />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#3B5D8F] dark:text-blue-400 hover:text-blue-600 dark:hover:text-blue-300"
              >
                <FaLinkedinIn className="size-5" />
              </a>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="pt-4 border-t border-gray-200 dark:border-gray-700 flex items-center justify-center text-s mt-4">
          <FaCopyright className="mr-2" />
          <span>2025 nextJob . All rights reserved</span>
        </div>
      </div>
    </footer>
  );
};

export default Footerentreprise;
