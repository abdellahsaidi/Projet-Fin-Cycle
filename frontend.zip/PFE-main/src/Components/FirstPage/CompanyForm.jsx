import { useState, useEffect } from "react";
import { FiUser, FiLock } from "react-icons/fi";
import { IoMail } from "react-icons/io5";
import { FaMapMarkerAlt } from "react-icons/fa";
import { useLocation, useNavigate } from "react-router-dom";
import Navbar from "../FirstPage/Navbar";
import Footer from "./Footer";

export default function CompanyForm() {
  const [loginForm, setLoginForm] = useState({ email: "", password: "" });
  const [registerForm, setRegisterForm] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    name: "",
    phone: "",
  });
  const [error, setError] = useState("");
  const [isRegister, setIsRegister] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);
  const [darkMode, setDarkMode] = useState(false);

  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const mode = params.get("mode");
    setIsRegister(mode === "register");

    const savedMode = localStorage.getItem("darkMode");
    if (savedMode) setDarkMode(savedMode === "true");
  }, [location]);

  useEffect(() => {
    localStorage.setItem("darkMode", darkMode);
  }, [darkMode]);

  const handleLoginSubmit = async () => {
    const { email, password } = loginForm;
    if (!email || !password) {
      setError("Please fill in all fields.");
      return;
    }

    try {
      const response = await fetch("http://localhost:8000/api/login/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      if (!response.ok) throw new Error("Login failed.");
      const data = await response.json();

      localStorage.setItem("token", data.token);
      console.log("Login successful:", data);

      setError("");
      setLoginForm({ email: "", password: "" });
      navigate("/dashboard");
    } catch (err) {
      setError(err.message || "Something went wrong during login.");
    }
  };

  const handleRegisterSubmit = async () => {
    const { email, password, confirmPassword, name, phone } = registerForm;
    if (!email || !password || !confirmPassword || !name || !phone) {
      setError("Please fill in all fields.");
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setError("Please enter a valid email address.");
      return;
    }

    if (password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }

    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    const phoneRegex = /^[0-9]+$/;
    if (!phoneRegex.test(phone)) {
      setError("Phone number must contain digits only.");
      return;
    }

    try {
      const response = await fetch("http://localhost:8000/api/register/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, name, phone }),
      });

      if (!response.ok) throw new Error("Registration failed.");
      const data = await response.json();

      localStorage.setItem("token", data.token);
      console.log("Registration successful:", data);

      setError("");
      setRegisterForm({
        email: "",
        password: "",
        confirmPassword: "",
        name: "",
        phone: "",
      });
      navigate("/dashboard");
    } catch (err) {
      setError(err.message || "Something went wrong during registration.");
    }
  };

  const toggleAuthMode = () => {
    setIsAnimating(true);
    setTimeout(() => {
      setIsRegister(!isRegister);
      setError("");
      setIsAnimating(false);
    }, 5);
  };

  const inputClass = `font-poppins font-light text-[16px] w-full h-[55px] px-4 py-2 rounded-lg ${
    darkMode ? "bg-gray-900 text-white placeholder-white" : "bg-[#3B5D8F] text-white placeholder-white"
  } focus:outline-none`;

  const iconClass = darkMode ? "text-white" : "text-black";

  return (
    <>
      <Navbar darkMode={darkMode} setDarkMode={setDarkMode} />
      <div className={`flex items-center justify-center min-h-screen ${darkMode ? "bg-gray-900" : "bg-blue-200"}`}>
        <div className={`relative w-[75%] h-[29vw] max-w-4xl bg-[#ACBFE6] rounded-[35px] shadow-lg overflow-hidden`}>
          {/* Left Section */}
          <div
            className={`absolute w-[50%] h-full bg-[#3B5D8F] text-white flex flex-col items-center justify-center p-8 rounded-r-[80px] transition-all duration-500 ease-in-out z-10 ${
              isAnimating ? (isRegister ? "translate-x-full" : "translate-x-0") : ""
            }`}
          >
            <div className="mb-[80px] text-center">
              <h1 className="font-bold text-[38px] leading-[100%] font-serif">
                {isRegister ? "Welcome Back!" : "Hello, Welcome!"}
              </h1>
              <p className="mt-5 font-poppins">
                {isRegister ? "Already have an account?" : "Don't have an account?"}
              </p>
              <button
                onClick={toggleAuthMode}
                className="mt-5 px-6 py-2 h-12 border font-poppins border-white rounded-lg hover:bg-blue-400 bg-inherit transition"
              >
                {isRegister ? "Login" : "Register"}
              </button>
            </div>
          </div>

          {/* Right Section */}
          <div
            className={`absolute right-0 w-[50%] h-full p-8 bg-[#ACBFE6] transition-opacity duration-300 ${
              isAnimating ? "opacity-0" : "opacity-100"
            }`}
          >
            <h2 className="font-bold text-[40px] leading-[100%] font-serif mb-6 text-center">
              {isRegister ? "Register" : "Login"}
            </h2>

            <div className="mb-4 space-y-4">
              {isRegister && (
                <>
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="Enter your full name"
                      value={registerForm.name}
                      onChange={(e) => setRegisterForm({ ...registerForm, name: e.target.value })}
                      className={inputClass}
                    />
                    <FiUser className={`absolute right-3 top-4 ${iconClass} text-[23px]`} />
                  </div>

                  <div className="relative">
                    <input
                      type="tel"
                      placeholder="Enter your phone number"
                      value={registerForm.phone}
                      onChange={(e) => {
                        const input = e.target.value;
                        if (/^\d*$/.test(input)) {
                          setRegisterForm({ ...registerForm, phone: input });
                        }
                      }}
                      className={inputClass}
                    />
                    <IoMail className={`absolute right-3 top-4 ${iconClass} text-[23px]`} />
                  </div>
                </>
              )}

              <div className="relative">
                <input
                  type="email"
                  placeholder="Enter your email"
                  value={isRegister ? registerForm.email : loginForm.email}
                  onChange={(e) =>
                    isRegister
                      ? setRegisterForm({ ...registerForm, email: e.target.value })
                      : setLoginForm({ ...loginForm, email: e.target.value })
                  }
                  className={inputClass}
                />
                <FaMapMarkerAlt className={`absolute right-3 top-4 ${iconClass} text-[23px]`} />
              </div>

              <div className="relative">
                <input
                  type="password"
                  placeholder={`Enter your ${isRegister ? "" : "pass"}word`}
                  value={isRegister ? registerForm.password : loginForm.password}
                  onChange={(e) =>
                    isRegister
                      ? setRegisterForm({ ...registerForm, password: e.target.value })
                      : setLoginForm({ ...loginForm, password: e.target.value })
                  }
                  className={inputClass}
                />
                <FiLock className={`absolute right-3 top-4 ${iconClass} text-[23px]`} />
              </div>

              {isRegister && (
                <div className="relative">
                  <input
                    type="password"
                    placeholder="Confirm your password"
                    value={registerForm.confirmPassword}
                    onChange={(e) => setRegisterForm({ ...registerForm, confirmPassword: e.target.value })}
                    className={inputClass}
                  />
                  <FiLock className={`absolute right-3 top-4 ${iconClass} text-[23px]`} />
                </div>
              )}
            </div>

            {error && <p className="text-red-600 text-center mt-2">{error}</p>}

            <div className="flex justify-center mt-6">
              <button
                onClick={isRegister ? handleRegisterSubmit : handleLoginSubmit}
                className="w-[200px] bg-[#3B5D8F] text-white h-12 py-2 rounded-lg hover:bg-blue-400 transition font-poppins font-light text-[16px]"
              >
                {isRegister ? "Register" : "Login"}
              </button>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}
