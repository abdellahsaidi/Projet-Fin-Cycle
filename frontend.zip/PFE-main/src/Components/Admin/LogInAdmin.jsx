import { useState, useEffect } from "react";
import { FiLock } from "react-icons/fi";
import { FaMapMarkerAlt } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Navbar from "./NavbarAdmin";
import Footer from "../FirstPage/Footer";

export default function LogInAdmin() {
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [darkMode, setDarkMode] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const navigate = useNavigate();

  useEffect(() => {
    const savedMode = localStorage.getItem("darkMode");
    if (savedMode) setDarkMode(savedMode === "true");
  }, []);

  useEffect(() => {
    localStorage.setItem("darkMode", darkMode);
  }, [darkMode]);

  const handleLoginSubmit = async () => {
    const { email, password } = form;
    if (!email || !password) {
      setError("Please fill in all fields.");
      return;
    }

    try {
      const response = await axios.post("http://localhost:8000/api/token/", {
        email,
        password,
      });

      const { access } = response.data;
      localStorage.setItem("token", access);
      axios.defaults.headers.common["Authorization"] = `Bearer ${access}`;

      setError("");
      setForm({ email: "", password: "" });
      navigate("/admin/companies");
    } catch (err) {
      setError("Login failed. Please check your credentials.");
    }
  };

  const inputClass = `font-[poppins] font-light text-[16px] w-full h-[55px] px-4 py-2 rounded-lg ${
    darkMode
      ? "bg-gray-900 text-white placeholder-white"
      : "bg-[#3B5D8F] text-white placeholder-white"
  } focus:outline-none`;

  const iconClass = darkMode ? "text-white" : "text-black";

  return (
    <>
      <div
        className={`flex items-center justify-center min-h-screen ${
          darkMode ? "bg-gray-900" : "bg-blue-200"
        }`}
      >
        <div className="w-[90%] max-w-md bg-[#ACBFE6] rounded-[35px] p-8 shadow-lg">
          <h2 className="font-bold text-[40px] font-serif mb-6 text-center">
            Admin Login
          </h2>

          <div className="space-y-4">
            <div className="relative">
              <input
                type="email"
                placeholder="Enter your email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className={inputClass}
              />
              <FaMapMarkerAlt
                className={`absolute right-3 top-4 ${iconClass} text-[23px]`}
              />
            </div>

            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Enter your password"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                className={inputClass}
              />
              <FiLock
                className={`absolute right-3 top-4 ${iconClass} text-[23px]`}
              />
            </div>

            <div className="flex items-center justify-between text-sm">
              <label className="font-poppins">
                <input
                  type="checkbox"
                  className="mr-2"
                  checked={showPassword}
                  onChange={() => setShowPassword(!showPassword)}
                />
                Show Password
              </label>
            </div>

            {error && <p className="text-red-600 text-center">{error}</p>}

            <div className="flex justify-center mt-6">
              <button
                onClick={handleLoginSubmit}
                className="w-[200px] bg-[#3B5D8F] text-white py-2 rounded-lg h-12 hover:bg-blue-400 transition font-poppins font-light text-[16px]"
              >
                Login
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
