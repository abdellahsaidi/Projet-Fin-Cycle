import React, { useState, useEffect } from 'react';
import axios from 'axios';
import NavbarAdmin from './NavbarAdmin';
import SidebarAdmin from './SidebarAdmin';
import Footer from '../FirstPage/Footer';

const FeedbackAdmin = () => {
  const [darkMode, setDarkMode] = useState(false);
  const [candidateFeedbacks, setCandidateFeedbacks] = useState([]);
  const [companyFeedbacks, setCompanyFeedbacks] = useState([]);
  const [loading, setLoading] = useState(true);

  const token = localStorage.getItem("token"); // Assure-toi que le token est stocké dans le localStorage

  useEffect(() => {
    const root = document.documentElement;
    darkMode ? root.classList.add('dark') : root.classList.remove('dark');
  }, [darkMode]);

  useEffect(() => {
    const fetchFeedbacks = async () => {
      try {
        const [candidatesRes, companiesRes] = await Promise.all([
          axios.get("http://localhost:8000/api/manager/feedbacks/candidates/", {
            headers: { Authorization: `Bearer ${token}` },
          }),
          axios.get("http://localhost:8000/api/manager/feedbacks/companies/", {
            headers: { Authorization: `Bearer ${token}` },
          }),
        ]);

        setCandidateFeedbacks(candidatesRes.data);
        setCompanyFeedbacks(companiesRes.data);
      } catch (error) {
        console.error("Erreur lors du chargement des feedbacks :", error);
      } finally {
        setLoading(false);
      }
    };

    fetchFeedbacks();
  }, [token]);

  const deleteFeedback = async (type, id) => {
    const endpoint =
      type === "candidate"
        ? `http://localhost:8000/api/manager/feedbacks/candidates/${id}/`
        : `http://localhost:8000/api/manager/feedbacks/companies/${id}/`;

    try {
      await axios.delete(endpoint, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (type === "candidate") {
        setCandidateFeedbacks((prev) => prev.filter((fb) => fb.id !== id));
      } else {
        setCompanyFeedbacks((prev) => prev.filter((fb) => fb.id !== id));
      }
    } catch (err) {
      console.error("Erreur lors de la suppression du feedback :", err);
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900 text-black dark:text-white transition-colors">
      <NavbarAdmin />
      <div className="flex flex-1">
        <SidebarAdmin />

        <main className="flex-1 p-8">
          <h1 className="text-[45px] font-[inria-serif] font-medium ml-[200px] mt-[10px]">Feedbacks</h1>

          {/* Feedback des candidats */}
          <section className="mt-10 font-[poppins]">
            <h2 className="text-[22px] font-semibold ml-[60px] mb-4">Candidates Feedback:</h2>
            <div className="overflow-x-auto">
              <table className="w-full border-2 border-blue-600 text-center dark:bg-gray-800">
                <thead className="bg-blue-200 dark:bg-blue-700 text-[17px] h-[50px]">
                  <tr>
                    <th className="border p-2">Full Name</th>
                    <th className="border p-2">Email</th>
                    <th className="border w-[270px] p-2">Phone Number</th>
                    <th className="border p-2">Feedback</th>
                    <th className="border w-[180px] p-2">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {candidateFeedbacks.length === 0 ? (
                    <tr>
                      <td colSpan="5" className="text-gray-500 dark:text-gray-300 py-6">
                        Aucune information disponible.
                      </td>
                    </tr>
                  ) : (
                    candidateFeedbacks.map(({ id, name, email, phone, message }) => (
                      <tr key={id} className="hover:bg-blue-50 dark:hover:bg-gray-700 h-[50px]">
                        <td className="border p-2">{name}</td>
                        <td className="border p-2">{email}</td>
                        <td className="border p-2">{phone}</td>
                        <td className="border p-2">{message}</td>
                        <td className="border p-2">
                          <button
                            onClick={() => deleteFeedback("candidate", id)}
                            className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded-[11px]"
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </section>

          {/* Feedback des entreprises */}
          <section className="mt-10 font-[poppins]">
            <h2 className="text-[22px] font-semibold ml-[60px] mb-4">Companies Feedback:</h2>
            <div className="overflow-x-auto">
              <table className="w-full border-2 border-blue-600 text-center dark:bg-gray-800">
                <thead className="bg-blue-200 dark:bg-blue-700 text-[17px] h-[50px]">
                  <tr>
                    <th className="border p-2">Company Name</th>
                    <th className="border p-2">Email</th>
                    <th className="border p-2">Phone Number</th>
                    <th className="border p-2">Feedback</th>
                    <th className="border p-2">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {companyFeedbacks.length === 0 ? (
                    <tr>
                      <td colSpan="5" className="text-gray-500 dark:text-gray-300 py-6">
                        Aucune information disponible.
                      </td>
                    </tr>
                  ) : (
                    companyFeedbacks.map(({ id, name, email, phone, message }) => (
                      <tr key={id} className="hover:bg-blue-50 dark:hover:bg-gray-700 h-[50px]">
                        <td className="border p-2">{name}</td>
                        <td className="border p-2">{email}</td>
                        <td className="border p-2">{phone}</td>
                        <td className="border p-2">{message}</td>
                        <td className="border p-2">
                          <button
                            onClick={() => deleteFeedback("company", id)}
                            className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded-[11px]"
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </section>
        </main>
      </div>
      <Footer />
    </div>
  );
};

export default FeedbackAdmin;
