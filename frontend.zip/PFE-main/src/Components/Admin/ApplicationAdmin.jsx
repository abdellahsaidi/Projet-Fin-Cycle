import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  FaBriefcase,
  FaBuilding,
  FaFileContract,
  FaUserTie,
  FaStar,
  FaAngleRight,
  FaTrash
} from "react-icons/fa";
import { Link } from "react-router-dom";
import Footer from "../FirstPage/Footer";
import NavbarAdmin from "./NavbarAdmin";
import SidebarAdmin from "./SidebarAdmin";

const ApplicationAdmin = () => {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    const root = window.document.documentElement;
    darkMode ? root.classList.add("dark") : root.classList.remove("dark");
  }, [darkMode]);

  useEffect(() => {
    const fetchApplications = async () => {
      try {
        const token = localStorage.getItem("token"); // 🔐 Récupérer le token
        const response = await axios.get(
          "http://localhost:8000/api/manager/applications/", // 👉 À adapter selon ton backend
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setApplications(response.data);
      } catch (error) {
        console.error("Erreur lors du chargement des candidatures :", error);
      } finally {
        setLoading(false);
      }
    };

    fetchApplications();
  }, []);

  const handleDelete = async (id) => {
    try {
      const token = localStorage.getItem("token");
      await axios.delete(
        `http://localhost:8000/api/manager/applications/${id}/`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setApplications(applications.filter((app) => app.id !== id));
    } catch (error) {
      console.error("Erreur lors de la suppression :", error);
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900 text-black dark:text-white transition-colors duration-300">
      <NavbarAdmin />
      <div className="flex flex-1">
        <SidebarAdmin />

        <main className="flex-1 p-8">
          <h1 className="text-[45px] font-[inria-serif] font-medium ml-[200px] mt-[10px]">
            Applications
          </h1>

          <div className="mt-7 mb-14 max-auto mx-auto space-y-8 border-4 w-[820px] border-blue-600 rounded-[11px] p-4 bg-white dark:bg-gray-900">
            {loading ? (
              <p className="text-center font-[poppins] text-xl text-gray-600 dark:text-gray-400">
                Chargement des candidatures...
              </p>
            ) : applications.length === 0 ? (
              <p className="text-center font-[poppins] text-xl text-gray-600 dark:text-gray-400">
                Si aucune information n'est apportée.
              </p>
            ) : (
              applications.map((app) => (
                <div
                  key={app.id}
                  className="p-6 border-2 border-blue-600 bg-white dark:bg-gray-800 rounded-xl w-2/3 mt-5 ml-[140px]"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h2 className="font-[Poppins] dark:text-white font-semibold text-[21px] flex items-center gap-2">
                        <FaBriefcase className="text-[#3B5D8F] dark:text-white" />
                        <Link to={`/application/${app.id}`} className="hover:underline">
                          {app.name}
                        </Link>
                      </h2>

                      <p className="font-[Poppins] dark:text-white text-[#3B5D8F] font-medium text-[15px] ml-5 mt-3 flex items-center gap-2">
                        <FaBuilding />
                        {app.position}
                      </p>

                      <div className="flex items-center gap-1 text-[#FFD700] mt-4 ml-11">
                        {[...Array(app.stars)].map((_, i) => (
                          <FaStar key={i} className="w-4 h-4" />
                        ))}
                      </div>

                      <div className="mt-4 flex flex-wrap gap-3 text-sm font-[poppins] items-center">
                        <span className="bg-[#6587CB] text-white ml-[200px] px-3 py-1 rounded-full flex items-center gap-2">
                          <FaFileContract />
                          {app.education}
                        </span>
                        <span className="bg-[#6587CB] text-white px-3 py-1 rounded-full flex items-center gap-2">
                          <FaUserTie />
                          {app.experience}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => handleDelete(app.id)}
                      className="hover:text-red-500 text-[18px] dark:text-white dark:hover:text-red-500"
                    >
                      <FaTrash />
                    </button>
                  </div>
                </div>
              ))
            )}

            {!loading && (
              <p className="text-[18px] dark:text-white ml-[400px] font-semibold inline-flex items-center gap-1">
                1 <FaAngleRight className="mt-1 dark:text-white" />
              </p>
            )}
          </div>
        </main>
      </div>
      <Footer />
    </div>
  );
};

export default ApplicationAdmin;
