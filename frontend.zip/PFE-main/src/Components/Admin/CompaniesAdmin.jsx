import React, { useState, useEffect } from "react";
import axios from "axios";
import NavbarAdmin from "./NavbarAdmin";
import SidebarAdmin from "./SidebarAdmin";
import Footer from "../FirstPage/Footer";

const Companies = () => {
  const [companies, setCompanies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [darkMode, setDarkMode] = useState(false);
  const [error, setError] = useState(null);

  // Set dark mode
  useEffect(() => {
    const root = window.document.documentElement;
    darkMode ? root.classList.add("dark") : root.classList.remove("dark");
    localStorage.setItem("darkMode", JSON.stringify(darkMode));
  }, [darkMode]);

  // Initialize dark mode from localStorage
  useEffect(() => {
    const savedMode = localStorage.getItem("darkMode");
    if (savedMode) {
      setDarkMode(JSON.parse(savedMode));
    }
  }, []);

  // Fetch companies from backend
  useEffect(() => {
    const fetchCompanies = async () => {
      try {
        const token = localStorage.getItem("token");
        const response = await axios.get(
          "http://localhost:8000/manager/companies/",
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setCompanies(response.data);
      } catch (err) {
        setError(
          err.response?.data?.message ||
            "Erreur lors du chargement des entreprises"
        );
      } finally {
        setLoading(false);
      }
    };

    fetchCompanies();
  }, []);

  const handleDelete = async (id) => {
    try {
      const token = localStorage.getItem("token");
      await axios.delete(`http://localhost:8000/manager/companies/${id}/`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setCompanies(companies.filter((company) => company.id !== id));
    } catch (err) {
      setError(err.response?.data?.message || "Erreur lors de la suppression");
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900 text-black dark:text-white transition-colors duration-300">
      <NavbarAdmin darkMode={darkMode} setDarkMode={setDarkMode} />
      <div className="flex flex-1">
        <SidebarAdmin />
        <main className="flex-1 p-6">
          <div className="flex justify-between items-center ml-[90px] mr-[90px] mt-[40px] mb-6">
            <h2 className="text-[45px] font-[inria-serif] font-medium ml-[200px] mt-[10px]">
              Entreprises
            </h2>
          </div>

          <div className="overflow-x-auto font-[poppins]">
            <table className="w-[90%] ml-[90px] border border-blue-500 dark:border-blue-300 text-center">
              <thead className="bg-blue-200 dark:bg-blue-800">
                <tr className="h-[50px]">
                  <th className="border border-blue-500 dark:border-blue-300 px-4 py-2">
                    Nom
                  </th>
                  <th className="border border-blue-500 dark:border-blue-300 px-4 py-2">
                    Email
                  </th>
                  <th className="border border-blue-500 dark:border-blue-300 px-4 py-2">
                    Téléphone
                  </th>
                  <th className="border border-blue-500 dark:border-blue-300 px-4 py-2">
                    Adresse
                  </th>
                  <th className="border border-blue-500 dark:border-blue-300 px-4 py-2">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td
                      colSpan="5"
                      className="text-gray-500 dark:text-gray-300 py-4"
                    >
                      Chargement des entreprises...
                    </td>
                  </tr>
                ) : error ? (
                  <tr>
                    <td
                      colSpan="5"
                      className="text-red-500 dark:text-red-400 py-4"
                    >
                      {error}
                    </td>
                  </tr>
                ) : companies.length === 0 ? (
                  <tr>
                    <td
                      colSpan="5"
                      className="text-gray-500 dark:text-gray-300 py-4"
                    >
                      Aucune entreprise disponible
                    </td>
                  </tr>
                ) : (
                  companies.map((company) => (
                    <tr
                      key={company.id}
                      className="hover:bg-blue-50 dark:hover:bg-gray-700 h-[60px]"
                    >
                      <td className="border border-blue-500 dark:border-blue-300 px-4 py-2">
                        {company.name}
                      </td>
                      <td className="border border-blue-500 dark:border-blue-300 px-4 py-2">
                        {company.email}
                      </td>
                      <td className="border border-blue-500 dark:border-blue-300 px-4 py-2">
                        {company.phone}
                      </td>
                      <td className="border border-blue-500 dark:border-blue-300 px-4 py-2">
                        {company.address}
                      </td>
                      <td className="border border-blue-500 dark:border-blue-300 px-4 py-2">
                        <button
                          className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded-[11px] mr-2"
                          onClick={() => handleDelete(company.id)}
                        >
                          Supprimer
                        </button>
                        <button
                          className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded-[11px]"
                          onClick={() => {
                            /* Add edit functionality */
                          }}
                        >
                          Modifier
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </main>
      </div>
      <div className="dark:bg-gray-800">
        <Footer darkMode={darkMode} />
      </div>
    </div>
  );
};

export default Companies;
