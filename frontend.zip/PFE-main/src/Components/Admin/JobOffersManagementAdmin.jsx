import React, { useState, useEffect } from "react";
import axios from "axios";
import NavbarAdmin from "./NavbarAdmin";
import SidebarAdmin from "./SidebarAdmin";
import Footer from "../FirstPage/Footer";

const JobOffersManagementAdmin = () => {
  const [jobOffers, setJobOffers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Ici tu mets ton token d'authentification (exemple stocké dans localStorage)
  const token = localStorage.getItem("token");

  useEffect(() => {
    const fetchJobOffers = async () => {
      try {
        setLoading(true);
        setError(null);

        const response = await axios.get(
          "https://ton-api/manager/pending-job-offers/",
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        // Supposons que les offres sont dans response.data
        setJobOffers(response.data);
      } catch (err) {
        setError("Erreur lors du chargement des offres");
      } finally {
        setLoading(false);
      }
    };

    fetchJobOffers();
  }, [token]);

  const handleCancel = (id) => {
    setJobOffers(jobOffers.filter((offer) => offer.id !== id));
    // Ici tu peux ajouter un appel API pour supprimer côté backend si besoin
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900 text-black dark:text-white transition-colors">
      <NavbarAdmin />
      <div className="flex flex-1">
        <SidebarAdmin />

        <main className="flex-1 p-6">
          <h2 className="text-[45px] font-[inria-serif] font-medium ml-[200px] mt-[10px]">
            Job Offers Management
          </h2>

          <div className="overflow-x-auto font-[poppins]">
            {loading ? (
              <p className="text-center mt-10 text-gray-500 dark:text-gray-300">
                Chargement des offres...
              </p>
            ) : error ? (
              <p className="text-center mt-10 text-red-500">{error}</p>
            ) : (
              <table className="w-[90%] ml-20 mt-10 border border-blue-500 text-center">
                <thead className="bg-blue-200">
                  <tr className="h-[50px]">
                    <th className="border border-blue-500 px-4 py-2">
                      Company Name
                    </th>
                    <th className="border border-blue-500 px-4 py-2">Offre</th>
                    <th className="border w-[300px] border-blue-500 px-4 py-2">
                      Action
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {jobOffers.length > 0 ? (
                    jobOffers.map((offer) => (
                      <tr key={offer.id}>
                        <td className="border border-blue-500 h-[70px] px-4 py-2">
                          {offer.companyName || offer.company || "—"}
                        </td>
                        <td className="border border-blue-500 px-4 py-2">
                          {offer.Offre || offer.title || "—"}
                        </td>
                        <td className="border border-blue-500 px-4 py-2">
                          <button className="bg-blue-600 text-white px-3 py-1 rounded-[11px] font-[poppins] mr-5">
                            Accept
                          </button>
                          <button
                            className="bg-red-600 text-white px-3 py-1 rounded-[11px] font-[poppins]"
                            onClick={() => handleCancel(offer.id)}
                          >
                            Cancel
                          </button>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td
                        colSpan="3"
                        className="text-gray-500 dark:text-gray-300 py-4"
                      >
                        Aucune information disponible
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            )}
          </div>
        </main>
      </div>
      <Footer />
    </div>
  );
};

export default JobOffersManagementAdmin;
