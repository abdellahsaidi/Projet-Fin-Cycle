import React, { useState, useEffect } from "react";
import NavbarAdmin from "./NavbarAdmin";
import SidebarAdmin from "./SidebarAdmin";
import { Doughnut, Bar, Pie } from "react-chartjs-2";
import {
  Chart as ChartJS,
  ArcElement,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(
  ArcElement,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend
);

const StatisticsAdmin = () => {
  const [darkMode, setDarkMode] = useState(() => {
    if (typeof window !== "undefined") {
      const savedMode = localStorage.getItem("darkMode");
      if (savedMode !== null) return JSON.parse(savedMode);
      return window.matchMedia("(prefers-color-scheme: dark)").matches;
    }
    return false;
  });

  const [language, setLanguage] = useState("fr");

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
    localStorage.setItem("darkMode", JSON.stringify(darkMode));
  }, [darkMode]);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  const toggleLanguage = () => {
    setLanguage((prev) => (prev === "fr" ? "en" : "fr"));
  };

  const labels = {
    fr: {
      dashboard: "Tableau de Bord Statistiques",
      totalUsers: "Utilisateurs Totaux",
      candidates: "Candidats",
      companies: "Entreprises",
      jobOffers: "Offres d'emploi",
      avgLogin: "Moyenne connexion",
      userDistribution: "Répartition des Utilisateurs",
      offersPerMonth: "Offres d'emploi par mois",
      userActivity: "Activité des Utilisateurs",
      total: "Total",
      active: "actifs",
      medium: "moyens",
      inactive: "inactifs",
    },
    en: {
      dashboard: "Statistics Dashboard",
      totalUsers: "Total Users",
      candidates: "Candidates",
      companies: "Companies",
      jobOffers: "Job Offers",
      avgLogin: "Avg. Time Since Last Login",
      userDistribution: "User Distribution",
      offersPerMonth: "Job Offers per Month",
      userActivity: "User Activity",
      total: "Total",
      active: "active",
      medium: "medium",
      inactive: "inactive",
      switchLang: "Switch to French",
    },
  };

  const t = labels[language];

  const apiData = {
    total_users: 13,
    total_candidates: 6,
    total_companies: 1,
    total_joboffers: 6,
    average_since_last_login: "4.7 jours",
    user_distribution: {
      candidates: 6,
      companies: 1,
    },
    joboffers_per_month: {
      Dec: 0,
      Jan: 0,
      Feb: 0,
      Mar: 0,
      Apr: 0,
      May: 6,
    },
    user_activity: {
      "actifs (<7j)": 2,
      "moyens (<15j)": 0,
      "inactifs (>15j)": 0,
    },
  };

  const textColor = darkMode ? "#FFFFFF" : "#000000";
  const gridColor = darkMode
    ? "rgba(255, 255, 255, 0.1)"
    : "rgba(0, 0, 0, 0.1)";

  const userDistributionChartData = {
    labels: [t.candidates, t.companies],
    datasets: [
      {
        data: [
          apiData.user_distribution.candidates,
          apiData.user_distribution.companies,
        ],
        backgroundColor: ["#36A2EB", "#FF6384"],
        borderColor: ["#36A2EB", "#FF6384"],
        borderWidth: 1,
      },
    ],
  };

  const jobOffersChartData = {
    labels: Object.keys(apiData.joboffers_per_month),
    datasets: [
      {
        label: t.jobOffers,
        data: Object.values(apiData.joboffers_per_month),
        backgroundColor: "rgba(75, 192, 192, 0.6)",
        borderColor: "rgba(75, 192, 192, 1)",
        borderWidth: 1,
      },
    ],
  };

  const userActivityChartData = {
    labels: Object.keys(apiData.user_activity),
    datasets: [
      {
        data: Object.values(apiData.user_activity),
        backgroundColor: ["#4BC0C0", "#FFCE56", "#FF9F40"],
        borderColor: ["#4BC0C0", "#FFCE56", "#FF9F40"],
        borderWidth: 1,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: "top",
        labels: {
          color: textColor,
        },
      },
    },
    scales: {
      x: {
        grid: {
          color: gridColor,
        },
        ticks: {
          color: textColor,
        },
      },
      y: {
        grid: {
          color: gridColor,
        },
        ticks: {
          color: textColor,
        },
      },
    },
  };

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-900">
      <SidebarAdmin darkMode={darkMode} />
      <div className="flex-1 flex flex-col overflow-hidden">
        <NavbarAdmin darkMode={darkMode} toggleDarkMode={toggleDarkMode} />
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50 dark:bg-gray-800 p-6">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-2xl font-semibold text-gray-800 dark:text-white">
              {t.dashboard}
            </h1>
            <button
              onClick={toggleLanguage}
              className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition"
            >
              {t.switchLang}
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-6">
            <div className="bg-white dark:bg-gray-700 p-6 rounded-lg shadow">
              <h3 className="text-md font-medium text-gray-600 dark:text-gray-300">
                {t.totalUsers}
              </h3>
              <p className="text-3xl font-bold mt-2 dark:text-white">
                {apiData.total_users}
              </p>
            </div>
            <div className="bg-white dark:bg-gray-700 p-6 rounded-lg shadow">
              <h3 className="text-md font-medium text-gray-600 dark:text-gray-300">
                {t.candidates}
              </h3>
              <p className="text-3xl font-bold mt-2 dark:text-white">
                {apiData.total_candidates}
              </p>
            </div>
            <div className="bg-white dark:bg-gray-700 p-6 rounded-lg shadow">
              <h3 className="text-md font-medium text-gray-600 dark:text-gray-300">
                {t.companies}
              </h3>
              <p className="text-3xl font-bold mt-2 dark:text-white">
                {apiData.total_companies}
              </p>
            </div>
            <div className="bg-white dark:bg-gray-700 p-6 rounded-lg shadow">
              <h3 className="text-md font-medium text-gray-600 dark:text-gray-300">
                {t.jobOffers}
              </h3>
              <p className="text-3xl font-bold mt-2 dark:text-white">
                {apiData.total_joboffers}
              </p>
            </div>
            <div className="bg-white dark:bg-gray-700 p-6 rounded-lg shadow">
              <h3 className="text-md font-medium text-gray-600 dark:text-gray-300">
                {t.avgLogin}
              </h3>
              <p className="text-3xl font-bold mt-2 dark:text-white">
                {apiData.average_since_last_login}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white dark:bg-gray-700 p-6 rounded-lg shadow">
              <h2 className="text-lg font-medium mb-4 dark:text-white">
                {t.userDistribution}
              </h2>
              <div className="h-64">
                <Pie data={userDistributionChartData} options={chartOptions} />
              </div>
              <div className="mt-2 text-sm text-gray-500 dark:text-gray-300">
                {apiData.user_distribution.candidates} {t.candidates} •{" "}
                {apiData.user_distribution.companies} {t.companies}
              </div>
            </div>

            <div className="bg-white dark:bg-gray-700 p-6 rounded-lg shadow">
              <h2 className="text-lg font-medium mb-4 dark:text-white">
                {t.offersPerMonth}
              </h2>
              <div className="h-64">
                <Bar data={jobOffersChartData} options={chartOptions} />
              </div>
              <div className="mt-2 text-sm text-gray-500 dark:text-gray-300">
                {t.total}: {apiData.total_joboffers} {t.jobOffers.toLowerCase()}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 mt-6">
            <div className="bg-white dark:bg-gray-700 p-6 rounded-lg shadow">
              <h2 className="text-lg font-medium mb-4 dark:text-white">
                {t.userActivity}
              </h2>
              <div className="h-64">
                <Doughnut data={userActivityChartData} options={chartOptions} />
              </div>
              <div className="mt-2 text-sm text-gray-500 dark:text-gray-300">
                {apiData.user_activity["actifs (<7j)"]} {t.active} •{" "}
                {apiData.user_activity["moyens (<15j)"]} {t.medium} •{" "}
                {apiData.user_activity["inactifs (>15j)"]} {t.inactive}
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default StatisticsAdmin;
