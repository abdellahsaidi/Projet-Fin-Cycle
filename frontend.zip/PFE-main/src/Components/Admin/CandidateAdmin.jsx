import React, { useState, useEffect } from 'react';
import axios from 'axios';
import NavbarAdmin from './NavbarAdmin';
import SidebarAdmin from './SidebarAdmin';
import Footer from '../FirstPage/Footer';

const CandidateAdmin = () => {
  const [candidates, setCandidates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    const root = window.document.documentElement;
    darkMode ? root.classList.add('dark') : root.classList.remove('dark');
  }, [darkMode]);

  useEffect(() => {
    const fetchCandidates = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('http://localhost:8000/api/admin/candidates/', {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setCandidates(response.data);
      } catch (error) {
        console.error('Erreur lors de la récupération des candidats :', error);
      } finally {
        setLoading(false);
      }
    };

    fetchCandidates();
  }, []);

  const handleDelete = async (id) => {
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:8000/api/admin/candidates/${id}/`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setCandidates(candidates.filter((candidate) => candidate.id !== id));
    } catch (error) {
      console.error('Erreur lors de la suppression du candidat :', error);
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900 text-black dark:text-white transition-colors">
      <NavbarAdmin />
      <div className="flex flex-1">
        <SidebarAdmin />

        <main className="flex-1 p-6">
          <div className="flex justify-between items-center">
            <h2 className="text-[45px] font-[inria-serif] font-medium ml-[200px] mt-[10px]">
              Candidates
            </h2>
          </div>

          <div className="overflow-x-auto font-[poppins] mt-10">
            <table className="w-[90%] mx-auto border border-blue-500 text-center dark:bg-gray-800">
              <thead className="bg-blue-200 dark:bg-blue-700 dark:text-white">
                <tr className='h-[50px]'>
                  <th className="border border-blue-500 px-4 py-2">Full Name</th>
                  <th className="border border-blue-500 px-4 py-2">Email</th>
                  <th className="border border-blue-500 px-4 py-2">Phone Number</th>
                  <th className="border border-blue-500 px-4 py-2">Address</th>
                  <th className="border border-blue-500 px-4 py-2">Action</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan="5" className="text-gray-500 dark:text-gray-300 py-4">
                      Chargement des candidats...
                    </td>
                  </tr>
                ) : candidates.length === 0 ? (
                  <tr>
                    <td colSpan="5" className="text-gray-500 dark:text-gray-300 py-4">
                      Aucun candidat disponible
                    </td>
                  </tr>
                ) : (
                  candidates.map((candidate) => (
                    <tr key={candidate.id} className="hover:bg-blue-50 dark:hover:bg-gray-700 h-[60px]">
                      <td className="border border-blue-500 px-4 py-2">{candidate.fullName}</td>
                      <td className="border border-blue-500 px-4 py-2">{candidate.email}</td>
                      <td className="border border-blue-500 px-4 py-2">{candidate.phone}</td>
                      <td className="border border-blue-500 px-4 py-2">{candidate.address}</td>
                      <td className="border border-blue-500 px-4 py-2">
                        <button
                          className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded-[11px]"
                          onClick={() => handleDelete(candidate.id)}
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </main>
      </div>
      <Footer />
    </div>
  );
};

export default CandidateAdmin;
