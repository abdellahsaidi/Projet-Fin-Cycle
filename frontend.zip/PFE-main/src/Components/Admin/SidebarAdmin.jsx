import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import {
  FaBuilding,
  FaUser,
  FaClipboard,
  FaClipboardList,
  FaHandshake,
  FaBriefcase,
  FaFlag,
  FaChartLine,
  FaSlidersH,
  FaSignOutAlt,
} from "react-icons/fa";

const SidebarAdmin = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const [showLogoutPopup, setShowLogoutPopup] = useState(false);

  const handleLogout = () => {
    // TODO: Supprimer le token / session ici si nécessaire
    setShowLogoutPopup(false);
    navigate("/auth"); // Redirection correcte vers AuthForm
  };

  const menuItems = [
    { icon: <FaBuilding />, label: "Companies", path: "/admin/companies" },
    { icon: <FaUser />, label: "Candidates", path: "/admin/candidates" },
    {
      icon: <FaClipboard />,
      label: "Applications",
      path: "/admin/applicationsAdmin",
    },
    {
      icon: <FaClipboardList />,
      label: "Applications Management",
      path: "/admin/applications-management",
    },
    {
      icon: <FaHandshake />,
      label: "Job Offers management",
      path: "/admin/job-offers-management",
    },
    { icon: <FaBriefcase />, label: "Job Offers", path: "/admin/job-offers" },
    { icon: <FaFlag />, label: "Feedback", path: "/admin/feedbackAdmin" },
    {
      icon: <FaChartLine />,
      label: "Statistics",
      path: "/admin/StatisticsAdmin",
    },
    { icon: <FaSlidersH />, label: "Settings", path: "/admin/settings" },
    { icon: <FaSignOutAlt />, label: "Log Out", isLogout: true },
  ];

  return (
    <>
      <div className="w-60 h-screen bg-white dark:bg-gray-900 mt-[2px] border-r dark:border-gray-700 p-4 transition-colors">
        <ul className="space-y-4">
          {menuItems.map((item, idx) => (
            <li key={idx}>
              {item.isLogout ? (
                <button
                  onClick={() => setShowLogoutPopup(true)}
                  className={`w-full text-left flex items-center space-x-3 px-2 py-3 rounded-md transition cursor-pointer 
                    ${
                      location.pathname === "/logout"
                        ? "bg-blue-600 text-white"
                        : "text-black dark:text-white hover:bg-blue-600 hover:text-white"
                    }`}
                >
                  <span className="text-[17px]">{item.icon}</span>
                  <span className="text-[17px] font-medium font-[poppins]">
                    {item.label}
                  </span>
                </button>
              ) : (
                <Link
                  to={item.path}
                  className={`flex items-center space-x-3 px-2 py-3 rounded-md transition cursor-pointer 
                    ${
                      location.pathname === item.path
                        ? "bg-blue-600 text-white"
                        : "text-black dark:text-white hover:bg-blue-600 hover:text-white"
                    }`}
                >
                  <span className="text-[17px]">{item.icon}</span>
                  <span className="text-[17px] font-medium font-[poppins]">
                    {item.label}
                  </span>
                </Link>
              )}
            </li>
          ))}
        </ul>
      </div>

      {/* Logout confirmation popup */}
      {showLogoutPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex justify-center items-center z-50">
          <div className="bg-white p-6 rounded shadow-lg text-center dark:bg-gray-800 dark:text-white">
            <p className="mb-4 text-lg font-semibold">
              Do you want to log out?
            </p>
            <div className="flex space-x-4 justify-center">
              <button
                className="px-4 py-2 font-[poppins] font-medium bg-gray-300 hover:bg-gray-400 rounded-lg dark:bg-black dark:hover:bg-slate-600"
                onClick={() => setShowLogoutPopup(false)}
              >
                Cancel
              </button>
              <button
                className="px-4 py-2 font-[poppins] font-medium bg-[#5786e3] hover:bg-blue-600 text-white rounded-lg"
                onClick={handleLogout}
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default SidebarAdmin;
