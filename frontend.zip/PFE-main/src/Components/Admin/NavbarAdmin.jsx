import { useState, useEffect } from "react";
import { FaMoon, FaSun, FaBell } from "react-icons/fa";
import logo from "../../assets/logo.png";

const NavbarAdmin = () => {
  const [darkMode, setDarkMode] = useState(() => {
    if (typeof window !== "undefined") {
      const savedMode = localStorage.getItem("darkMode");
      if (savedMode !== null) return JSON.parse(savedMode);
      return window.matchMedia("(prefers-color-scheme: dark)").matches;
    }
    return false;
  });

  const [hasNotifications, setHasNotifications] = useState(true);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
    localStorage.setItem("darkMode", JSON.stringify(darkMode));
  }, [darkMode]);

  const toggleDarkMode = () => setDarkMode(!darkMode);

  return (
    <div className="bg-white dark:bg-gray-800 shadow-md p-4 transition-colors duration-300">
      <div className="container mx-auto flex justify-between items-center">
        {/* Logo */}
        <div className="w-40 mr-22">
          <img src={logo} alt="Logo" />
        </div>

        <div className="font-[inria-serif] font-semibold text-[47px] mr-40 dark:text-white">
          Admin Dashbord
        </div>

        {/* Right Icons */}
        <div className="flex items-end  space-x-4  ">
          {/* Notification Icon */}
          <div className="relative ">
            <button className="p-2 rounded-full hover:bg-blue-600 dark:hover:bg-blue-400 transition-colors">
              <FaBell className="text-black dark:text-white text-xl" />
              {hasNotifications && (
                <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
              )}
            </button>
          </div>

          {/* Dark Mode Toggle */}
          <button
            onClick={toggleDarkMode}
            className="p-2 rounded-full hover:bg-blue-700  dark:hover:bg-blue-400 transition-colors"
            aria-label={
              darkMode ? "Switch to light mode" : "Switch to dark mode"
            }
          >
            {darkMode ? (
              <FaSun className="text-yellow-400 text-xl " />
            ) : (
              <FaMoon className="text-black text-xl" />
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default NavbarAdmin;
