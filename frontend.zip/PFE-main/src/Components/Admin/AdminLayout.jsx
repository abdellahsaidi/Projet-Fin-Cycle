// AdminLayout.jsx
import ApplicationAdmin from './ApplicationAdmin';
import NavbarAdmin from './NavbarAdmin';
import SidebarAdmin from './SidebarAdmin';
import { Outlet } from 'react-router-dom';

const AdminLayout = () => {
  return (
          <div>
            
            <Outlet />
          </div>
    
  );
};

export default AdminLayout;
