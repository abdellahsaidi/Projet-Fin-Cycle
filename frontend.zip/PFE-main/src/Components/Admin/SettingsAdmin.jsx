import React, { useState, useEffect } from "react";
import { FaLock } from "react-icons/fa";
import NavbarAdmin from "./NavbarAdmin";
import SidebarAdmin from "./SidebarAdmin";
import Footer from "../FirstPage/Footer";
import axios from 'axios';

const SettingsAdmin = () => {
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [darkMode, setDarkMode] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const root = window.document.documentElement;
    if (darkMode) {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
  }, [darkMode]);

  const validatePassword = (password) => {
    const lengthCheck = /.{8,}/;
    const upperCheck = /[A-Z]/;
    const lowerCheck = /[a-z]/;
    const numberCheck = /[0-9]/;
    const specialCharCheck = /[!@#$%^&*(),.?":{}|<>]/;

    if (!lengthCheck.test(password))
      return "Password must be at least 8 characters long.";
    if (!upperCheck.test(password))
      return "Password must include at least one uppercase letter.";
    if (!lowerCheck.test(password))
      return "Password must include at least one lowercase letter.";
    if (!numberCheck.test(password))
      return "Password must include at least one number.";
    if (!specialCharCheck.test(password))
      return "Password must include at least one special character.";

    return "";
  };

  const handleSave = async () => {
    const validationError = validatePassword(newPassword);

    if (validationError) {
      setError(validationError);
      setSuccess("");
      return;
    }

    if (newPassword !== confirmPassword) {
      setError("Passwords do not match!");
      setSuccess("");
      return;
    }

    try {
      setLoading(true);
      const token = localStorage.getItem('manager_access_token');
      
      await axios.post('/api/manager/change-password/', {
        new_password: newPassword,
        confirm_password: confirmPassword
      }, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      setSuccess("Password updated successfully!");
      setError("");
      setNewPassword("");
      setConfirmPassword("");
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to update password');
      setSuccess("");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900 text-black dark:text-white transition-colors">
      <NavbarAdmin />
      <div className="flex flex-1">
        <SidebarAdmin />

        <main className="flex-1 p-6">
          <h2 className="text-[45px] font-[inria-serif] font-medium ml-[360px] mt-[10px]">
            Settings
          </h2>

          <div className="w-[60%] mx-auto border-2 border-blue-600 mt-[40px] rounded-xl p-6 space-y-4 bg-white dark:bg-gray-800">
            <div className="relative">
              <input
                type="password"
                value={newPassword}
                onChange={(e) => {
                  setNewPassword(e.target.value);
                  setError("");
                  setSuccess("");
                }}
                placeholder="Enter your new password"
                className="w-full border-2 border-blue-500 rounded-full px-4 py-2 pr-10 h-[50px] outline-none placeholder:text-black dark:placeholder:text-black"
              />
              <FaLock className="absolute right-5 top-4 text-black dark:text-black" />
            </div>

            <div className="relative">
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => {
                  setConfirmPassword(e.target.value);
                  setError("");
                  setSuccess("");
                }}
                placeholder="Confirm your new password"
                className="w-full border-2 border-blue-500 rounded-full px-4 h-[50px] py-2 pr-10 outline-none placeholder:text-black dark:placeholder:text-black"
              />
              <FaLock className="absolute right-5 top-4 text-black dark:text-black" />
            </div>

            {error && <p className="text-red-600 ml-5 text-[19px]">{error}</p>}
            {success && <p className="text-green-600 ml-5 text-[19px]">{success}</p>}

            <div className="flex justify-end">
             <button
            onClick={handleSave}
            disabled={loading}
            className={`bg-blue-600 hover:bg-blue-700 text-white w-[110px] text-[poppins] text-[19px] font-semibold px-6 py-2 rounded-full ${
              loading ? "opacity-50 cursor-not-allowed" : ""
            }`}
          >
            {loading ? "Saving..." : "Save"}
          </button>
            </div>
          </div>
        </main>
      </div>
      <Footer />
    </div>
  );
};

export default SettingsAdmin;