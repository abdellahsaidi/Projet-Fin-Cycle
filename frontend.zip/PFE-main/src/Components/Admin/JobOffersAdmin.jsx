import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  FaTrash,
  FaBriefcase,
  FaMapMarkerAlt,
  FaBuilding,
  FaAngleRight,
} from "react-icons/fa";
import { FiFileText, FiAward } from "react-icons/fi";
import NavbarAdmin from "./NavbarAdmin";
import SidebarAdmin from "./SidebarAdmin";
import Footer from "../FirstPage/Footer";

const JobOffersAdmin = () => {
  const [offers, setOffers] = useState([]);
  const [darkMode, setDarkMode] = useState(false);
  const [loading, setLoading] = useState(true);

  const token = localStorage.getItem("token");

  useEffect(() => {
    const root = window.document.documentElement;
    if (darkMode) {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }
  }, [darkMode]);

  useEffect(() => {
    const fetchOffers = async () => {
      try {
        const response = await axios.get(
          "http://localhost:8000/manager/pending-job-offers/",
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setOffers(response.data);
      } catch (error) {
        console.error("Erreur lors du chargement des offres :", error);
      } finally {
        setLoading(false);
      }
    };

    fetchOffers();
  }, [token]);

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:8000/manager/pending-job-offers/${id}/`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setOffers(offers.filter((offer) => offer.id !== id));
    } catch (error) {
      console.error("Erreur lors de la suppression :", error);
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900 text-black dark:text-white transition-colors">
      <NavbarAdmin />
      <div className="flex flex-1">
        <SidebarAdmin />
        <main className="flex-1 p-6 overflow-auto">
          <div className="flex justify-center items-center mb-6">
            <h1 className="text-[45px] font-[inria-serif] font-medium -ml-[460px] mt-[10px]">
              Job Offers
            </h1>
          </div>

          <div className="border-4 border-blue-600 rounded-lg p-6 space-y-6 max-w-3xl mx-auto bg-white dark:bg-gray-800">
            {loading ? (
              <p className="text-center text-gray-500 dark:text-gray-300 text-lg">
                Chargement...
              </p>
            ) : offers.length === 0 ? (
              <p className="text-center text-gray-500 dark:text-gray-300 text-lg">
                Aucune offre d'emploi n'est disponible.
              </p>
            ) : (
              offers.map((offer) => (
                <div
                  key={offer.id}
                  className="border-4 border-blue-600 rounded-lg p-4 shadow-sm relative bg-gray-50 dark:bg-gray-900"
                >
                  <div className="flex justify-between items-start">
                    <div className="flex space-x-3">
                      <FaBriefcase className="text-[#5786e3] mt-1 text-[24px]" />
                      <div>
                        <h2 className="font-[Poppins] font-semibold text-[21px] text-gray-800 dark:text-white mb-1">
                          {offer.title}
                        </h2>
                        <p className="text-[#3B5D8F] dark:text-blue-200 font-medium text-[15px] flex items-center">
                          <FaBuilding className="mr-1" /> {offer.company_name}
                        </p>
                        <p className="text-[#3B5D8F] dark:text-blue-200 font-medium text-[15px] mt-1 flex items-center">
                          <FaMapMarkerAlt className="mr-1" /> {offer.location}
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleDelete(offer.id)}
                      className="hover:text-red-500 text-[18px] dark:text-white dark:hover:text-red-500"
                      title="Supprimer l'offre"
                    >
                      <FaTrash />
                    </button>
                  </div>

                  <div className="flex justify-end gap-2 mt-4 font-[Poppins]">
                    <span className="flex items-center text-xs px-2 py-1 bg-[#6587CB] text-white rounded-full">
                      <FiFileText className="mr-1" />
                      {offer.contract_type}
                    </span>
                    <span className="flex items-center text-xs px-2 py-1 bg-[#6587CB] text-white rounded-full">
                      <FiAward className="mr-1" />
                      {offer.experience_level}
                    </span>
                  </div>
                </div>
              ))
            )}

            <div className="flex justify-center mt-6">
              <p className="text-[18px] dark:text-white font-semibold flex items-center gap-1">
                1 <FaAngleRight className="mt-1" />
              </p>
            </div>
          </div>
        </main>
      </div>
      <Footer />
    </div>
  );
};

export default JobOffersAdmin;
