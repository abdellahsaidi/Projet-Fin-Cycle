  import React from 'react'
  import MyProfilEntreprise from './ProfilEntreprise/MyProfilEntreprise'
  import MyApplicationEntreprise from './ProfilEntreprise/MyApplicationEntreprise'
  import SettingsEntreprise from './ProfilEntreprise/SettingsEntreprise'
  import NotificationsEntreprise from './ProfilEntreprise/NotificationsEntreprise'

  const ProfilEntrepriseApp = () => {
    return (
      <div>
      <MyProfilEntreprise/>
      {/* <MyApplicationEntreprise/> */}
      {/* <SettingsEntreprise/> */}
      {/* <NotificationsEntreprise/> */}
      </div>
    )
  }

  export default ProfilEntrepriseApp
