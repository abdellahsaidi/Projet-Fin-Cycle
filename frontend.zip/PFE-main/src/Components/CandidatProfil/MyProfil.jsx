import { useState, useEffect } from "react";
import {
  FaStar,
  FaRegStar,
  FaLinkedin,
  FaTwitter,
  FaFacebook,
  FaChevronDown,
  FaEnvelope,
  FaPhone,
  FaMapMarkerAlt,
} from "react-icons/fa";
import { MdEdit } from "react-icons/md";
import Sidebar from "./Sidebar";
import Footer from "../FirstPage/Footer";
import { TbFileUpload } from "react-icons/tb";
import { FiUpload } from "react-icons/fi";
import NavbarCandidat from "../CandidatProfil/NavbarCandidat";

const MyProfile = () => {
  const [rating] = useState(3);
  const [darkMode, setDarkMode] = useState(false);
  const [showLogoutPopup, setShowLogoutPopup] = useState(false);
  const [showEditCVPopup, setShowEditCVPopup] = useState(false);
  const [showPersonalDataPopup, setShowPersonalDataPopup] = useState(false);
  const [showHiringPreferencesPopup, setShowHiringPreferencesPopup] =
    useState(false);

  const renderStars = () => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        i <= rating ? (
          <FaStar key={i} className="text-yellow-400" />
        ) : (
          <FaRegStar key={i} className="text-gray-400" />
        )
      );
    }
    return stars;
  };

  useEffect(() => {
    const mode = localStorage.getItem("darkMode");
    if (mode !== null) setDarkMode(JSON.parse(mode));

    const observer = new MutationObserver(() => {
      const updated = localStorage.getItem("darkMode");
      setDarkMode(JSON.parse(updated));
    });

    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["class"],
    });

    const handleStorageChange = () => {
      const updated = localStorage.getItem("darkMode");
      setDarkMode(JSON.parse(updated));
    };
    window.addEventListener("storage", handleStorageChange);

    return () => {
      observer.disconnect();
      window.removeEventListener("storage", handleStorageChange);
    };
  }, []);

  return (
    <div className="flex flex-col dark:bg-gray-900">
      <NavbarCandidat />
      <div className="flex flex-1">
        <div className="h-[128vh]">
          <Sidebar onLogoutClick={() => setShowLogoutPopup(true)} />
        </div>

        <main
          className={`flex-1 p-6 ${
            darkMode ? "bg-gray-900 text-white" : "bg-gray-50 text-black"
          } mt-1`}
        >
          <div className="max-w-2xl mx-auto">
            <h1 className="font-normal text-[42px] font-[Inria-Serif] mb-8">
              My Profile
            </h1>

            {/* CV Card */}
            <div className="relative border-4 border-[#5786e3] rounded-lg p-6 bg-white dark:bg-gray-800 shadow-md mb-6">
              <div className="flex justify-between items-start">
                <div>
                  <h2 className="font-[Poppins] font-medium text-[27px] mb-2">
                    My CV
                  </h2>
                  <p className="font-[Poppins] font-medium text-[17px] mb-3">
                    Attachment: not available
                  </p>
                  <div className="flex">
                    <span className="mr-2 font-[Poppins] font-medium text-[17px]">
                      Rating:
                    </span>
                    <div className="flex mt-1">{renderStars()}</div>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <button
                    className="p-2 rounded-full bg-[#6688CC] hover:bg-blue-300"
                    onClick={() => setShowEditCVPopup(true)}
                  >
                    <MdEdit className="text-[25px]" />
                  </button>
                </div>
              </div>
              <div className="space-y-2 mt-4 font-[Poppins] font-medium text-[17px]">
                <p>Domain:</p>
                <p>Education level:</p>
                <p>Experience: (years)</p>
                <p>Status:</p>
              </div>
            </div>

            {/* Personal Data */}
            <div className="relative border-4 border-[#6688CC] rounded-lg p-6 bg-white dark:bg-gray-800 shadow-md mb-6">
              <div className="flex justify-between items-start mb-4">
                <h3 className="font-[Poppins] font-medium text-[25px]">
                  Personal Data
                </h3>
                <div className="flex space-x-2">
                  <button
                    className="p-2 rounded-full bg-[#6688CC] hover:bg-blue-300"
                    onClick={() => setShowPersonalDataPopup(true)}
                  >
                    <MdEdit className="text-[25px]" />
                  </button>
                </div>
              </div>
              <div className="mb-4 ml-28 font-[Poppins] font-medium text-[17px] flex items-center">
                <p>Full Name</p>
              </div>
              <div className="font-[Poppins] font-medium text-[17px] space-y-3">
                <div className="flex items-center">
                  <FaEnvelope className="mr-2 text-gray-600 dark:text-gray-300" />
                  <p>contact@nextJob.com</p>
                </div>
                <div className="flex items-center">
                  <FaPhone className="mr-2 text-gray-600 dark:text-gray-300" />
                  <p>+213 59 XX XX XX</p>
                </div>
                <div className="flex items-center">
                  <FaMapMarkerAlt className="mr-2 text-gray-600 dark:text-gray-300" />
                  <p>Alger.Blido.USDB</p>
                </div>
                <div className="mt-4">
                  <div className="flex space-x-4 -mt-1 ml-2">
                    <p className="font-[Poppins] font-semibold text-[17px]">
                      Social Media links:
                    </p>
                    <FaTwitter className="text-blue-400 text-[22px]" />
                    <FaFacebook className="text-blue-600 text-[22px]" />
                    <FaLinkedin className="text-blue-500 text-[22px]" />
                  </div>
                </div>
                <div className="flex justify-center mt-6">
                  <button className="flex items-center px-4 py-2 rounded-lg text-[#3B5D8F] font-[Poppins] font-medium hover:bg-blue-300">
                    More
                    <FaChevronDown className="ml-2 text-[#3B5D8F] hover:bg-blue-300" />
                  </button>
                </div>
              </div>
            </div>

            {/* Hiring Preferences */}
            <div className="relative border-4 border-[#6688CC] rounded-lg p-6 bg-white dark:bg-gray-800 shadow-md">
              <div className="flex justify-between items-start mb-4">
                <h3 className="font-[Poppins] font-medium text-[25px]">
                  Hiring Preferences
                </h3>
                <div className="flex space-x-2">
                  <button
                    className="p-2 rounded-full bg-[#6688CC] hover:bg-blue-300"
                    onClick={() => setShowHiringPreferencesPopup(true)}
                  >
                    <MdEdit className="text-[25px]" />
                  </button>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <p className="font-[Poppins] font-medium text-[17px] mb-1">
                    Mobility :
                  </p>
                </div>
                <div>
                  <p className="font-[Poppins] font-medium text-[17px] mb-1">
                    Desired Wage :
                  </p>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Logout Popup */}
      {showLogoutPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex justify-center items-center z-50">
          <div className="bg-white dark:bg-gray-700 border-4 border-[#5786e3] p-6 rounded-lg shadow-lg flex flex-col items-center">
            <p className="font-[poppins] font-semibold text-[18px] mb-4 dark:text-white">
              Do you want to log out ?
            </p>
            <div className="flex space-x-4">
              <button
                className="px-4 py-2 font-[poppins] font-medium bg-gray-300 hover:bg-gray-400 rounded-lg"
                onClick={() => setShowLogoutPopup(false)}
              >
                Cancel
              </button>
              <button
                className="px-4 py-2 font-[poppins] font-medium bg-[#5786e3] hover:bg-blue-600 text-white rounded-lg"
                onClick={() => {
                  setShowLogoutPopup(false);
                }}
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit CV Popup */}
      {showEditCVPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex justify-center items-center z-50">
          <div className="bg-white dark:bg-gray-700 border-4 border-[#5786e3] p-6 rounded-lg shadow-lg w-[600px] h-[660px] flex flex-col items-center">
            <h2 className="font-[inria-serif] font-normal text-[26px] mb-6 dark:text-white">
              Editing My CV
            </h2>

            <div className="border-2 border-[#5786e3] border-dashed p-6 w-full h-[202px] flex flex-col items-center mb-4">
              <TbFileUpload className="w-20 h-12 mb-2" />
              <p className="font-[Poppins] text-[19px] dark:text-gray-300">
                Drop file here or
              </p>
              <button className="text-[#5786e3] font-[Poppins] text-[16px] mt-3 hover:underline">
                click to upload
              </button>
            </div>

            <select className="w-1/2 mr-[275px] mt-3 border-2 border-[#5786e3] rounded-[11px] p-2 mb-6 font-[Poppins] font-semibold">
              <option>Domain</option>
            </select>
            <select className="w-1/2 mr-[275px] border-2 border-[#5786e3] rounded-[11px] p-2 mb-6 font-[Poppins] font-semibold">
              <option>Education Level</option>
            </select>
            <input
              type="text"
              placeholder="Years Of Experience"
              className="w-1/2 mr-[275px] border-2 border-[#5786e3] rounded-[11px] font-[Poppins] placeholder-black placeholder:font-[600] p-2 mb-6"
            />
            <select className="w-1/2 mr-[275px] border-2 border-[#5786e3] rounded-[11px] p-2 mb-6 font-[Poppins] font-semibold">
              <option>Status</option>
            </select>

            <button
              className="bg-[#3B5D8F] ml-96 hover:bg-blue-600 text-white font-[Poppins] px-6 py-2 rounded-[11px]"
              onClick={() => setShowEditCVPopup(false)}
            >
              Save
            </button>
          </div>
        </div>
      )}

      {/* Personal Data Popup */}
      {showPersonalDataPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex justify-center items-center z-50">
          <div className="bg-white dark:bg-gray-800 border-4 border-[#5786e3] p-6 rounded-lg shadow-lg w-[600px]">
            <h2 className="text-center tracking-wider font-medium text-[25px] font-[inria-serif] mb-6 dark:text-white">
              Editing Personal Data
            </h2>

            {/* Full Name, Email and Upload Photo */}
            <div className="flex items-start justify-between mb-2">
              {/* Left side: inputs */}
              <div className="flex flex-col space-y-3 w-[70%]">
                <input
                  type="text"
                  placeholder="Full Name"
                  className="p-2 border-2 mb-2 border-[#5786e3] rounded-[11px] font-[Poppins] placeholder-black placeholder:font-[600]"
                />
                <input
                  type="email"
                  placeholder="Email"
                  className="p-2 border-2 border-[#5786e3] rounded-[11px] font-[Poppins] placeholder-black placeholder:font-[600]"
                />
              </div>

              {/* Right side: Upload photo */}
              <div className="border-2 border-dashed border-[#3B5D8F] p-3 w-34 h-32 flex flex-col items-center justify-center rounded ml-2">
                <label className="cursor-pointer flex flex-col items-center text-gray-500 text-center text-xs">
                  <FiUpload className="text-3xl mb-3 text-[#3B5D8F] dark:text-white" />
                  <span className="text-black font-semibold font-[Poppins] dark:text-white">
                    Upload Photo here
                  </span>
                  <input type="file" className="hidden" />
                </label>
              </div>
            </div>

            {/* Form */}
            <form className="space-y-4">
              <input
                type="text"
                placeholder="Phone Number"
                className="w-[70%] p-2 border-2 border-[#5786e3] rounded-[11px] font-[Poppins] placeholder-black placeholder:font-[600]"
              />
              <input
                type="text"
                placeholder="Address"
                className="w-[70%] p-2 border-2 border-[#5786e3] rounded-[11px] font-[Poppins] placeholder-black placeholder:font-[600]"
              />
              <input
                type="text"
                placeholder="GitHub Link"
                className="w-[70%] p-2 border-2 border-[#5786e3] rounded-[11px] font-[Poppins] placeholder-black placeholder:font-[600]"
              />
              <input
                type="text"
                placeholder="Facebook Link"
                className="w-[70%] p-2 border-2 border-[#5786e3] rounded-[11px] font-[Poppins] placeholder-black placeholder:font-[600]"
              />
              <input
                type="text"
                placeholder="LinkedIn Link"
                className="w-[70%] p-2 border-2 border-[#5786e3] rounded-[11px] font-[Poppins] placeholder-black placeholder:font-[600]"
              />
              <select className="w-[55%] font-semibold p-2 border-2 border-[#5786e3] rounded-[11px] font-[Poppins]">
                <option>Military Service</option>
              </select>
              <select className="w-[55%] font-semibold p-2 border-2 border-[#5786e3] rounded-[11px] font-[Poppins] placeholder-black placeholder:font-[600]">
                <option>Driving License</option>
              </select>
              <select className="w-[55%] font-semibold p-2 border-2 border-[#5786e3] rounded-[11px] font-[Poppins] placeholder-black placeholder:font-[600]">
                <option>Handicap Situation</option>
              </select>

              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={() => setShowPersonalDataPopup(false)}
                  className="bg-[#3B5D8F] font-[Poppins] hover:bg-blue-400 text-white px-6 py-2 rounded-[11px]"
                >
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Hiring Preferences Popup */}
      {showHiringPreferencesPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex justify-center items-center z-50">
          <div className="bg-white dark:bg-gray-800 border-4 border-[#5786e3] p-6 rounded-lg shadow-lg w-[500px] h-[270px]">
            <h2 className="text-center font-[inria-serif] font-medium tracking-wider text-[25px] mb-4 dark:text-white">
              Editing Hiring Preferences
            </h2>

            <form className="space-y-4">
              <select className="w-[55%] mb-3 font-semibold p-2 border-2 border-[#5786e3] rounded-[11px] font-[Poppins]">
                <option value="telecommuting">Telecommuting</option>
                <option value="onsite">On-site</option>
                <option value="hybrid">Hybrid</option>
              </select>

              <input
                type="text"
                placeholder="Desired Wage"
                className="w-[75%] font-semibold p-2 border-2 border-[#5786e3] rounded-[11px] font-[Poppins] placeholder-black placeholder:font-[600]"
              />

              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={() => setShowHiringPreferencesPopup(false)}
                  className="bg-[#3B5D8F] font-[Poppins] hover:bg-blue-400 text-white px-6 py-2 rounded-[11px]"
                >
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="mt-1">
        <Footer />
      </div>
    </div>
  );
};

export default MyProfile;
