import {
  FaTrash,
  FaBriefcase,
  FaMapMarkerAlt,
  FaBuilding,
} from "react-icons/fa";
import { FiFileText, FiAward } from "react-icons/fi";
import Sidebar from "./Sidebar";
import Footer from "../../Components/FirstPage/Footer";
import NavbarCandidat from "../CandidatProfil/NavbarCandidat";
import { useEffect, useState } from "react";
import axios from "axios";

const MyApplications = () => {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchApplications = async () => {
      try {
        const token = localStorage.getItem("token");
        const response = await axios.get(
          "http://localhost:8000/api/candidat/my-applications/",
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setApplications(response.data);
      } catch (error) {
        console.error("Failed to fetch applications:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchApplications();
  }, []);

  const handleDelete = async (id) => {
    try {
      const token = localStorage.getItem("token");
      await axios.delete(
        `http://localhost:8000/api/candidat/my-applications/${id}/`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setApplications(applications.filter((app) => app.id !== id));
    } catch (error) {
      console.error("Error deleting application:", error);
    }
  };

  return (
    <div className="flex flex-col bg-gray-50 dark:bg-gray-900">
      <NavbarCandidat />

      <div className="flex flex-1">
        <div className="h-[115vh]">
          <Sidebar />
        </div>

        <main className="flex-1 p-6">
          <h1 className="font-normal text-[42px] font-[Inria-Serif] mb-8 mr-80 text-center text-gray-800 dark:text-white">
            My Applications
          </h1>

          <div className="border-4 border-[#5786e3] rounded-lg p-4 space-y-4 max-w-2xl mx-auto">
            {loading ? (
              <p className="text-center text-gray-600 dark:text-gray-300">
                Loading...
              </p>
            ) : applications.length === 0 ? (
              <p className="text-center text-gray-600 dark:text-gray-300">
                No applications found.
              </p>
            ) : (
              applications.map((app) => (
                <div
                  key={app.id}
                  className="border-4 border-[#5786e3] rounded-lg p-4 bg-white dark:bg-gray-800 shadow-sm relative"
                >
                  <div className="flex justify-between items-start">
                    <div className="flex space-x-3 items-start">
                      <FaBriefcase className="text-[#5786e3] mt-1 text-[24px]" />
                      <div>
                        <h2 className="font-[Poppins] font-semibold text-[21px] mb-2 text-gray-800 dark:text-white">
                          {app.title}
                        </h2>
                        <p className="font-[Poppins] text-[#3B5D8F] dark:text-blue-200 font-medium text-[15px] flex items-center">
                          <FaBuilding className="mr-1" /> {app.company}
                        </p>
                        <p className="font-[Poppins] text-[#3B5D8F] dark:text-blue-200 font-medium text-[15px] mt-2 flex items-center">
                          <FaMapMarkerAlt className="mr-1" /> {app.location}
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleDelete(app.id)}
                      className="hover:text-red-500 text-[18px] dark:text-white dark:hover:text-red-500"
                    >
                      <FaTrash />
                    </button>
                  </div>

                  <div className="flex mt-4 space-x-3 font-[Poppins]">
                    <span className="flex items-center text-xs px-2 py-1 ml-auto bg-[#6587CB] text-white rounded-full">
                      <FiFileText className="mr-1" />
                      {app.contract}
                    </span>
                    <span className="flex items-center text-xs px-2 py-1 bg-[#6587CB] text-white rounded-full">
                      <FiAward className="mr-1" />
                      {app.experience}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </main>
      </div>

      <div className="mt-[119px]">
        <Footer />
      </div>
    </div>
  );
};

export default MyApplications;
