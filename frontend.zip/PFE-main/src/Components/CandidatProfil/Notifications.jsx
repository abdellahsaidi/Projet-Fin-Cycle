import { useState, useEffect } from "react";
import {
  FaBell,
  FaRegBell,
  FaRegClock,
  FaCheckCircle,
  FaTrashAlt,
} from "react-icons/fa";
import Sidebar from "./Sidebar";
import Footer from "../../Components/FirstPage/Footer";
import NavbarCandidat from "../CandidatProfil/NavbarCandidat";
import axios from "axios";

const Notifications = () => {
  const [notifications, setNotifications] = useState([]);
  const [darkMode, setDarkMode] = useState(() => {
    if (typeof window !== "undefined") {
      const savedMode = localStorage.getItem("darkMode");
      return savedMode ? JSON.parse(savedMode) : false;
    }
    return false;
  });

  const token = localStorage.getItem("token"); // JWT Token

  // Fetch notifications
  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const response = await axios.get(
          "http://localhost:8000/api/candidat/notifications/",
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setNotifications(response.data);
      } catch (error) {
        console.error("Failed to fetch notifications:", error);
      }
    };

    fetchNotifications();
  }, [token]);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
    localStorage.setItem("darkMode", JSON.stringify(darkMode));
  }, [darkMode]);

  const markAsRead = (id) => {
    setNotifications(
      notifications.map((notification) =>
        notification.id === id ? { ...notification, read: true } : notification
      )
    );
  };

  const deleteNotification = async (id) => {
    try {
      await axios.delete(
        `http://localhost:8000/api/candidat/notifications/${id}/delete/`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setNotifications(
        notifications.filter((notification) => notification.id !== id)
      );
    } catch (error) {
      console.error("Failed to delete notification:", error);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900">
      <NavbarCandidat />
      <div className="flex flex-1">
        <div className="h-[169vh]">
          <Sidebar />
        </div>

        <div className="flex-1 flex flex-col">
          <main className="flex-1 p-6 ml-[270px] mt-12">
            <div className="max-w-4xl mx-auto">
              <div className="flex items-center mb-8">
                <FaBell className="text-blue-600 dark:text-blue-400 text-2xl mr-3" />
                <h1 className="font-[Inria-Serif] font-normal text-[45px] tracking-wider dark:text-white">
                  Notifications
                </h1>
              </div>

              <div className="space-y-4 ">
                {notifications.length === 0 && (
                  <p className="text-gray-500 dark:text-gray-400">
                    No notifications found.
                  </p>
                )}
                {notifications.map((notification) => (
                  <div
                    key={notification.id}
                    className={`p-4 rounded-lg border relative ${
                      notification.read
                        ? "bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700"
                        : "bg-blue-50 dark:bg-blue-900/30 border-blue-200 dark:border-blue-700"
                    }`}
                  >
                    {!notification.read && (
                      <div className="absolute top-3 left-3 w-2 h-2 bg-red-500 rounded-full"></div>
                    )}

                    <div className="flex items-start pl-4 h-[80px]">
                      <div className="mr-3 pt-1">
                        {notification.read ? (
                          <FaCheckCircle className="text-gray-400 dark:text-gray-500" />
                        ) : (
                          <FaRegBell className="text-blue-500 dark:text-blue-400" />
                        )}
                      </div>
                      <div className="flex-1">
                        <p
                          className={`font-medium text-[20px]  ${
                            notification.read
                              ? "text-gray-600 dark:text-gray-300"
                              : "text-gray-800 dark:text-white"
                          }`}
                        >
                          {notification.message}
                        </p>
                        <div className="flex items-center mt-2 text-[18px] text-gray-500 dark:text-gray-400">
                          <FaRegClock className="mr-1" />
                          <span>{notification.time || "Some time ago"}</span>
                        </div>
                      </div>

                      <div className="flex gap-2 ml-2">
                        {!notification.read && (
                          <button
                            onClick={() => markAsRead(notification.id)}
                            className="text-blue-500 dark:text-blue-400 cursor-pointer transition-colors duration-200"
                          >
                            Mark as read
                          </button>
                        )}
                        <button
                          onClick={() => deleteNotification(notification.id)}
                          className="text-black hover:text-red-500 dark:text-white transition-colors duration-200 ml-4 text-[18px]"
                          title="Delete"
                        >
                          <FaTrashAlt />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </main>

          <div className="mt-[543px] dark:bg-gray-800">
            <Footer darkMode={darkMode} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Notifications;
