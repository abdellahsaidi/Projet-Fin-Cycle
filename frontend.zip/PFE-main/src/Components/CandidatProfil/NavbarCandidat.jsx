import React, { useState, useEffect } from "react";
import {
  FaHome,
  FaBriefcase,
  FaCommentAlt,
  FaMoon,
  FaSun,
  FaBell,
  FaUserCircle,
  FaChevronDown,
} from "react-icons/fa";
import { Link, useNavigate } from "react-router-dom";
import logo from "../../assets/logo.png";

const Navbar = () => {
  const [darkMode, setDarkMode] = useState(() => {
    if (typeof window !== "undefined") {
      const savedMode = localStorage.getItem("darkMode");
      if (savedMode !== null) return JSON.parse(savedMode);
      return window.matchMedia("(prefers-color-scheme: dark)").matches;
    }
    return false;
  });

  const [showProfileDropdown, setShowProfileDropdown] = useState(false);
  const [hasNotifications, setHasNotifications] = useState(true);
  const [showLogoutPopup, setShowLogoutPopup] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
    localStorage.setItem("darkMode", JSON.stringify(darkMode));
  }, [darkMode]);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  const toggleProfileDropdown = () => {
    setShowProfileDropdown(!showProfileDropdown);
  };

  const handleSignOut = async () => {
    const refresh = localStorage.getItem("refresh");
    try {
      if (refresh) {
        const response = await fetch("http://localhost:8000/candidat/logout/", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${localStorage.getItem("access")}`,
          },
          body: JSON.stringify({ refresh }),
        });
        if (!response.ok) {
          alert("Erreur lors de la déconnexion !");
        }
      }
    } catch (error) {
      alert("Erreur lors de la déconnexion !");
      console.log(error)
    }
    localStorage.clear();
    setShowLogoutPopup(false);
    navigate("/login");
  };

  return (
    <>
      <div className="bg-white dark:bg-gray-800 shadow-md p-4 transition-colors duration-300">
        <div className="container mx-auto flex justify-between items-center">
          {/* Logo */}
          <div className="w-[180px] -ml-[120px]">
            <img src={logo} alt="not-found" />
          </div>

          <div className="flex items-center space-x-40">
            {/* Navigation Links */}
            <nav className="hidden md:flex space-x-48 font-[Poppins] font-medium text-[22px]">
              <Link
                to="/Home"
                className="flex items-center dark:text-white hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
              >
                <FaHome className="mr-2" />
                Home
              </Link>
              <Link
                to="/Opportunities"
                className="flex items-center dark:text-white hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
              >
                <FaBriefcase className="mr-2" />
                Opportunities
              </Link>
              <Link
                to="/FeedBack"
                className="flex items-center dark:text-white hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
              >
                <FaCommentAlt className="mr-2" />
                Feedback
              </Link>
            </nav>

            {/* Icons Section */}
            <div className="flex items-center space-x-4">
              {/* Notification Icon */}
              <div className="relative left-[155px] hover:bg-gray-200 rounded-full">
                <Link to="/Notifications">
                  <button className="p-2 rounded-full hover:bg-blue-600 dark:hover:bg-blue-400 transition-colors">
                    <FaBell className="text-black dark:text-white text-[25px]" />
                    {hasNotifications && (
                      <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
                    )}
                  </button>
                </Link>
              </div>

              {/* Dark Mode Toggle */}
              <button
                onClick={toggleDarkMode}
                className="p-2 rounded-full relative left-[150px] hover:bg-gray-200 dark:hover:bg-gray-700 focus:outline-none transition-colors"
                aria-label={
                  darkMode ? "Switch to light mode" : "Switch to dark mode"
                }
              >
                {darkMode ? (
                  <FaSun className="text-yellow-400 text-[25px]" />
                ) : (
                  <FaMoon className="text-black text-[25px]" />
                )}
              </button>

              {/* Profile Dropdown */}
              <div className="relative">
                <button
                  onClick={toggleProfileDropdown}
                  className="flex items-center relative left-[145px] space-x-1 hover:bg-blue-600 dark:hover:bg-blue-400 transition-colors rounded-full p-1 pr-2"
                >
                  <FaUserCircle className="text-gray-700 dark:text-gray-300 text-[25px]" />
                  <FaChevronDown
                    className={`text-gray-500 dark:text-gray-400 text-[18px] transition-transform ${
                      showProfileDropdown ? "transform rotate-180" : ""
                    }`}
                  />
                </button>

                {/* Dropdown Menu */}
                {showProfileDropdown && (
                  <div className="absolute -left-8 mt-4 font-[poppins] w-56 bg-white dark:bg-gray-700 rounded-md shadow-lg py-1 z-50 border border-gray-200 dark:border-gray-600">
                    <Link
                      to="/my-profile"
                      className="block px-4 py-2 mt-1 mb-2 dark:text-gray-200 hover:bg-blue-600 hover:text-white dark:hover:bg-blue-600"
                      onClick={() => setShowProfileDropdown(false)}
                    >
                      Your Profile
                    </Link>
                    <Link
                      to="/settings"
                      className="block px-4 py-2 mb-2 dark:text-gray-200 hover:bg-blue-600 hover:text-white dark:hover:bg-blue-600"
                      onClick={() => setShowProfileDropdown(false)}
                    >
                      Settings
                    </Link>
                    <button
                      onClick={() => {
                        setShowProfileDropdown(false);
                        setShowLogoutPopup(true);
                      }}
                      className="block w-full text-left px-4 py-2 mb-1 hover:bg-blue-600 hover:text-white dark:text-gray-200 dark:hover:bg-blue-600"
                    >
                      Sign out
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Logout Confirmation Popup */}
      {showLogoutPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex justify-center items-center z-50">
          <div className="bg-white dark:bg-gray-800 p-6 rounded shadow-lg text-center">
            <p className="mb-4 text-lg font-semibold text-gray-900 dark:text-white">
              Do you want to log out?
            </p>
            <div className="flex justify-center space-x-4">
              <button
                onClick={() => setShowLogoutPopup(false)}
                className="px-4 py-2 font-[poppins] font-medium bg-gray-300 hover:bg-gray-400 rounded-lg"
              >
                Cancel
              </button>
              <button
                onClick={handleSignOut}
                className="px-4 py-2 font-[poppins] font-medium bg-[#5786e3] hover:bg-blue-600 text-white rounded-lg"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Navbar;
