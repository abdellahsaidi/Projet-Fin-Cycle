import React, { useState } from "react";
import { FaUser, FaFileAlt, FaBell, FaCog, FaSignOutAlt } from "react-icons/fa";
import { Link, useNavigate } from "react-router-dom";

const Sidebar = () => {
  const [showLogoutPopup, setShowLogoutPopup] = useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    // Add your logout logic here (e.g., clearing tokens or user data)
    // localStorage.removeItem("token"); // Example
    setShowLogoutPopup(false);
    navigate("/login"); // Redirect to login page after logout
  };

  return (
    <>
      <div className="w-[270px] h-[128vh] mt-[10px] bg-white dark:bg-gray-800 text-black dark:text-white p-4 absolute left-0 top-[108px] border-r-2 border-r-[#00000040] dark:top-[107px]">
        <nav className="space-y-2 ">
          <SidebarItem icon={<FaUser />} text="My Profile" link="/profile" />
          <SidebarItem icon={<FaFileAlt />} text="My Application" link="/applications" />
          <SidebarItem icon={<FaBell />} text="Notifications" link="/notifications" />
          <SidebarItem icon={<FaCog />} text="Settings" link="/settings" />
          <SidebarItem
            icon={<FaSignOutAlt />}
            text="Log Out"
            onClick={() => setShowLogoutPopup(true)}
          />
        </nav>
      </div>

      {showLogoutPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex justify-center items-center z-50">
          <div className="bg-white p-6 rounded shadow-lg text-center">
            <p className="mb-4 text-lg font-semibold">
              Do you want to log out?
            </p>
            <div className="flex space-x-4">
              <button
                className="px-4 py-2 font-[poppins] font-medium bg-gray-300 hover:bg-gray-400 rounded-lg"
                onClick={() => setShowLogoutPopup(false)}
              >
                Cancel
              </button>
              <button
                className="px-4 py-2 font-[poppins] font-medium bg-[#5786e3] hover:bg-blue-600 text-white rounded-lg"
                onClick={handleLogout}
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

const SidebarItem = ({ icon, text, link, onClick }) => {
  if (link) {
    return (
      <Link
        to={link}
        className="flex items-center p-3 rounded-lg transition-colors h-16 w-full text-black dark:text-white hover:bg-blue-800 dark:hover:bg-blue-600 hover:text-white"
      >
        <span className="mr-3 font-[Poppins] font-medium text-[18px]">{icon}</span>
        <span className="font-[Poppins] font-medium text-[18px]">{text}</span>
      </Link>
    );
  }

  return (
    <button
      onClick={onClick}
      className="flex items-center p-3 rounded-lg transition-colors h-16 w-full text-black dark:text-white hover:bg-blue-800 dark:hover:bg-blue-600 hover:text-white"
    >
      <span className="mr-3 font-[Poppins] font-medium text-[18px]">{icon}</span>
      <span className="font-[Poppins] font-medium text-[18px]">{text}</span>
    </button>
  );
};

export default Sidebar;
