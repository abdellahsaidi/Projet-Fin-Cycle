import React, { useState, useEffect } from "react";
import axios from "axios";
import NavbarEntreprise from "../Entreprise/NavbarEntreprise";
import Footer from "../FirstPage/Footer";
import {
  FaSearch,
  FaBriefcase,
  FaBuilding,
  FaFileContract,
  FaUserTie,
  FaStar,
} from "react-icons/fa";
import { FaAngleRight } from "react-icons/fa6";
import talentimg from "../../assets/talentimg.png";
import { Link } from "react-router-dom";

const Talents = () => {
  const [searchInput, setSearchInput] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [talents, setTalents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchTalents = async () => {
      try {
        const token = localStorage.getItem("token");
        const response = await axios.get(
          "http://localhost:8000/api/company/talents/",
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setTalents(response.data);
        setLoading(false);
      } catch (err) {
        setError("Failed to fetch talents.");
        setLoading(false);
      }
    };

    fetchTalents();
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    setSearchTerm(searchInput.trim());
  };

  const filteredTalents = talents.filter((talent) => {
    const search = searchTerm.toLowerCase();
    return (
      talent.full_name?.toLowerCase().includes(search) ||
      talent.title?.toLowerCase().includes(search) ||
      talent.location?.toLowerCase().includes(search) ||
      talent.education_level?.toLowerCase().includes(search) ||
      talent.experience_level?.toLowerCase().includes(search)
    );
  });

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <NavbarEntreprise />
      <div className="container mx-auto px-4 py-8">
        {/* Title Section */}
        <div className="max-w-6xl mb-16 mx-auto">
          <div className="flex flex-col md:flex-row items-center text-left mt-12 gap-8 md:gap-16 lg:gap-[300px]">
            <div className="leading-[170%] tracking-[0.9px] max-w-sm text-black dark:text-white">
              <p className="font-medium mb-6 font-[inria-serif] text-3xl md:text-[38px]">Unlock new potential</p>
              <p className="font-medium font-[poppins] text-lg md:text-[22px]">Find the Skills That Move You Forward</p>
            </div>
            <img
              src={talentimg}
              alt="Entreprise dashboard"
              className="w-full max-w-[400px] h-auto"
            />
          </div>
        </div>

        {/* Search Bar */}
        <div className="mb-12 flex justify-center">
          <form className="w-full max-w-4xl flex flex-col sm:flex-row gap-4" onSubmit={handleSearch}>
            <div className="relative flex-1">
              <FaSearch className="absolute dark:text-white left-4 top-1/2 transform -translate-y-1/2 text-black" />
              <input
                type="text"
                placeholder="Domain, Job, Name..."
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                className="w-full dark:bg-gray-900 h-[59px] pl-12 pr-4 py-3 border-4 border-[#3B5D8F] rounded-[11px] font-[poppins] placeholder:text-black dark:placeholder:text-white"
              />
            </div>
            <button
              type="submit"
              className="bg-[#3B5D8F] text-white px-6 py-3 rounded-[11px] font-[poppins] font-semibold h-[59px]"
            >
              Search
            </button>
          </form>
        </div>

        {/* Candidate Cards */}
        <div className="max-w-5xl dark:bg-gray-900 mx-auto space-y-8 border-4 min-h-auto w-full md:w-[820px] mt-8 border-[#5786e3] rounded-[11px] p-4 bg-white">
          {loading ? (
            <p className="text-center font-[poppins] text-xl text-gray-600">Loading candidates...</p>
          ) : error ? (
            <p className="text-center text-red-500 font-[poppins] text-xl">{error}</p>
          ) : filteredTalents.length === 0 ? (
            <p className="text-center font-[poppins] text-xl text-gray-600">No candidates found.</p>
          ) : (
            filteredTalents.map((talent, index) => (
              <div
                key={index}
                className="p-6 dark:bg-gray-900 border-2 border-[#5786e3] bg-white rounded-xl w-full md:w-2/3 mt-5 mx-auto md:ml-[140px]"
              >
                <h2 className="font-[Poppins] dark:text-white font-semibold text-[21px] flex items-center gap-2">
                  <FaBriefcase className="text-[#3B5D8F] dark:text-white" />
                  <Link
                    to={`/talent/${talent.id}`}
                    className="hover:underline"
                  >
                    {talent.full_name}
                  </Link>
                </h2>

                <p className="font-[Poppins] dark:text-white text-[#3B5D8F] font-medium text-[15px] ml-5 mt-3 flex items-center gap-2">
                  <FaBuilding />
                  {talent.title}
                </p>
                <div className="flex items-center gap-1 text-[#FFD700] mt-4 ml-11">
                  {[...Array(5)].map((_, i) => (
                    <FaStar key={i} className="w-4 h-4" />
                  ))}
                </div>
                <div className="mt-4 flex flex-wrap gap-3 text-sm font-[poppins] items-center">
                  <span className="bg-[#6587CB] text-white md:ml-[200px] px-3 py-1 rounded-full flex items-center gap-2">
                    <FaFileContract />
                    {talent.education_level}
                  </span>
                  <span className="bg-[#6587CB] text-white px-3 py-1 rounded-full flex items-center gap-2">
                    <FaUserTie />
                    {talent.experience_level}
                  </span>
                </div>
              </div>
            ))
          )}
          <p className="text-[18px] dark:text-white text-center  font-semibold inline-flex items-center gap-1 justify-center w-full">
            1 <FaAngleRight className="mt-1 dark:text-white" />
          </p>
        </div>
      </div>

      <div className="mt-24">
        <Footer />
      </div>
    </div>
  );
};

export default Talents;
