import React, { useState, useEffect } from "react";
import NavbarEntreprise from "./NavbarEntreprise";
import Footer from "../FirstPage/Footer";
import Accueilimg from "../../assets/Accueilimg.png";
import { FaBriefcase, FaBuilding, FaFileContract, FaUserTie, FaStar } from "react-icons/fa";
import { Link } from 'react-router-dom';

const AccueilEntreprise = () => {
  const [darkMode, setDarkMode] = useState(() => {
    return localStorage.getItem("theme") === "dark";
  });
  const [jobOffers, setJobOffers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
  }, [darkMode]);

  useEffect(() => {
    const fetchCandidates = async () => {
      try {
        // Get the token from localStorage (assuming you store it there after login)
        const token = localStorage.getItem("companyToken");
        
        if (!token) {
          throw new Error("No authentication token found");
        }

        const response = await fetch("http://your-api-domain.com/company/talents/", {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`,
          },
        });

        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        setJobOffers(data); // Assuming your API returns an array of candidates
      } catch (err) {
        console.error("Error fetching candidates:", err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchCandidates();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen bg-white dark:bg-gray-900">
        <div className="text-2xl font-[poppins]">Loading candidates...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex justify-center items-center min-h-screen bg-white dark:bg-gray-900">
        <div className="text-red-500 text-xl font-[poppins]">Error: {error}</div>
      </div>
    );
  }

  return (
    <div className="bg-white text-black dark:bg-gray-900 dark:text-white min-h-screen">
      {/* <NavbarEntreprise /> */}

      {/* Hero Section */}
      <section className="px-6 py-10 text-center">
        <h1 className="text-5xl uppercase font-bold mt-12 font-[Inria-Serif]">
          Welcome to the talent ecosysteM
        </h1>

        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row items-center text-left mt-32 gap-8 md:gap-[300px]">
            <p className="font-medium text-2xl md:text-[33px] leading-[140%] tracking-[0.8px] font-[poppins] max-w-sm">
              nextJob gives recruiters the opportunity 
              to find talent with the skills required 
              for an open position
            </p>
            <img
              src={Accueilimg}
              alt="Entreprise dashboard"
              className="w-full max-w-[400px] h-auto"
            />
          </div>
        </div>
      </section>

      {/* Job Offers Section */}
      <section className="flex flex-col items-center py-8 px-4">
        <h1 className="font-[Inria-Serif] font-medium text-4xl md:text-[64px] mt-8 mb-9 text-center uppercase">
          top candidates
        </h1>

        <div className="flex flex-col items-center mb-8 w-full max-w-5xl gap-2">
          {jobOffers.length > 0 ? (
            jobOffers.map((offer, index) => (
              <div
                key={offer.id || index}
                className={`flex ${
                  index % 2 === 0 ? "justify-start" : "justify-end"
                } w-full`}
              >
                <div className="border-4 border-[#6688CC] rounded-xl p-6 w-full md:w-[570px] shadow-md flex flex-col gap-3 mb-8">
                  <div className="flex items-center gap-2 font-[poppins] font-light text-lg md:text-[20px]">
                    <FaBriefcase className="text-[#3B5D8F] w-5 h-5" />
                    <Link 
                      to={`/company/candidates/${offer.id}`} 
                      className="font-bold hover:underline"
                    >
                      {offer.title || `${offer.first_name} ${offer.last_name}`}
                    </Link>
                  </div>

                  <div className="flex items-center gap-2 text-[#3B5D8F] text-sm md:text-[16px] font-medium ml-11">
                    <FaBuilding className="w-4 h-4" />
                    <p>{offer.company || offer.current_position}</p>
                  </div>
                  <div className="flex items-center gap-1 text-[#FFD700] ml-11">
                    {[...Array(5)].map((_, i) => (
                      <FaStar key={i} className="w-4 h-4" />
                    ))}
                  </div>

                  <div className="flex gap-2 mt-2 justify-end h-7">
                    <span className="bg-[#3B5D8F] text-white text-xs px-2 py-1 rounded-full flex items-center gap-1">
                      <FaFileContract className="w-3 h-3" />
                      {offer.type || offer.education_level}
                    </span>
                    <span className="bg-[#3B5D8F] text-white text-xs px-2 py-1 rounded-full flex items-center gap-1">
                      <FaUserTie className="w-3 h-3" />
                      {offer.experience || "experienced"}
                    </span>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <p className="text-center font-[poppins] text-xl">
              No candidates found.
            </p>
          )}
        </div>

        <Link to="/entreprise/talents">
          <button className="bg-[#3B5D8F] font-[poppins] text-white px-6 py-2 rounded-lg hover:bg-blue-700 mb-8 transition-colors w-40 h-12">
            More Talents
          </button>
        </Link>

        <p className="text-center mb-2 font-medium text-2xl md:text-[40px] font-[Inria-Serif]">
          Enjoying your experience?{" "}
          <span>We'd love to hear your feedback!</span>
        </p>

        <Link
          to="/entreprise/feedback"
          className="text-xl md:text-[28px] mt-3 text-[#3B5D8F] dark:text-[#3B5D8F] font-bold underline hover:text-blue-700 dark:hover:text-blue-300"
        >
          Feedback Here!
        </Link>
      </section>

      <Footer />
    </div>
  );
};

export default AccueilEntreprise;