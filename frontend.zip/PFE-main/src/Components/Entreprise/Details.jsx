import React, { useEffect, useState } from "react";
import NavbarEntreprise from "./NavbarEntreprise";
import { FaFacebook, FaGithub, FaLinkedin } from "react-icons/fa";
import { IoMdPerson } from "react-icons/io";
import Footer from "../../Components/FirstPage/Footer";
import { EnvelopeIcon, MapPinIcon } from '@heroicons/react/24/outline';

const Details = () => {
  const [user, setUser] = useState(null); // Store user details
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const token = localStorage.getItem("token"); // Assumes token is stored in localStorage

  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        const response = await fetch("https://your-api-url.com/api/user/details", {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        });

        if (!response.ok) throw new Error("Failed to fetch user details");

        const data = await response.json();
        setUser(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchUserDetails();
  }, [token]);

  if (loading) return <div className="text-center py-20 text-xl">Loading...</div>;
  if (error) return <div className="text-center py-20 text-red-500">Error: {error}</div>;
  if (!user) return null;

  return (
    <div className="font-poppins bg-[#f4f6fa] dark:bg-gray-900 min-h-screen">
      {/* <NavbarEntreprise /> */}

      {/* Header */}
      <div className="w-full bg-gradient-to-r from-[#415C99] to-[#6587CB] text-white px-4 py-8 border-b">
        <div className="max-w-7xl mx-auto md:ml-28 h-[160px] flex flex-col md:flex-row items-center md:items-start justify-center md:justify-start">
          <div className="bg-white dark:bg-gray-900 border rounded-xl mt-24 h-[150px] w-[130px] shadow p-4 mr-4 flex flex-col items-center">
            <IoMdPerson className="text-black dark:text-white text-[68px] mb-2" />
            <div className="flex dark:text-white justify-center gap-4 mt-2 text-[#415C99] text-[18px]">
              <FaFacebook className="cursor-pointer text-[22px] hover:text-blue-600" />
              <FaGithub className="cursor-pointer text-[22px] hover:text-black" />
              <FaLinkedin className="cursor-pointer text-[22px] hover:text-blue-500" />
            </div>
          </div>
          <div className="text-center md:text-left mt-24">
            <h1 className="font-semibold mt-2 ml-7 text-[45px]">{user.fullName}</h1>
          </div>
        </div>
      </div>

      {/* Details */}
      <div className="max-w-4xl mt-20 mx-auto px-4 py-10">

        {/* Personal Information */}
        <div className="bg-gradient-to-r from-[#3B5D8F] to-[#6587CB] rounded-lg p-6 shadow-lg text-white mb-6">
          <h2 className="font-[inria-serif] font-medium tracking-[2px] text-[23px] mb-4">Personal Information :</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-black">
            <div className="flex items-center gap-3">
              <div className="bg-white rounded-full h-12 w-12 flex items-center justify-center text-[#3B5D8F] font-bold text-xl">👤</div>
              <div>
                <p className="font-medium text-[20px]">Full Name :</p>
                <p className="text-[18px]">{user.fullName}</p>
              </div>
            </div>
            <div>
              <p className="font-medium text-[20px]">Military Service :</p>
              <p className="text-[18px]">{user.militaryService || "Invalid"}</p>
            </div>
            <div className="ml-14">
              <p className="font-medium text-[20px]">Email :</p>
              <p className="flex items-center text-black text-[18px]">
                <EnvelopeIcon className="h-5 w-5 mr-2" />
                {user.email}
              </p>
            </div>
            <div>
              <p className="font-medium text-[20px]">Driving licence :</p>
              <p className="text-[18px]">{user.drivingLicense ? "Valid" : "Invalid"}</p>
            </div>
            <div className="ml-14">
              <p className="font-medium text-[20px]">Phone Number :</p>
              <p className="text-[18px]">{user.phone}</p>
            </div>
            <div>
              <p className="font-medium text-[20px]">Handicap Situation :</p>
              <p className="text-[18px]">{user.handicapSituation || "Invalid"}</p>
            </div>
            <div className="col-span-2 ml-14">
              <p className="font-medium text-[20px]">Address :</p>
              <p className="flex items-center text-[18px]">
                <MapPinIcon className="h-5 w-5 mr-2" />
                {user.address}
              </p>
            </div>
          </div>
        </div>

        {/* Professional Information */}
        <div className="bg-gradient-to-r from-[#3B5D8F] to-[#6587CB] rounded-lg p-6 shadow-lg text-white mb-6">
          <h2 className="font-[inria-serif] font-medium tracking-[2px] text-[23px] mb-4">Professional Information :</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-black">
            <div>
              <p className="font-medium text-[20px]">Domain :</p>
              <p className="text-[18px]">{user.domain}</p>
            </div>
            <div>
              <p className="font-medium text-[20px]">Status :</p>
              <p className="text-[18px]">{user.status}</p>
            </div>
            <div>
              <p className="font-medium text-[20px]">Education Level :</p>
              <p className="text-[18px]">{user.educationLevel}</p>
            </div>
            <div>
              <p className="font-medium text-[20px]">Telecommuting :</p>
              <p className="text-[18px]">{user.telecommuting || "Invalid"}</p>
            </div>
            <div>
              <p className="font-medium text-[20px]">Experience :</p>
              <p className="text-[18px]">{user.experience}</p>
            </div>
            <div>
              <p className="font-medium text-[20px]">Desired Wage :</p>
              <p className="text-[18px]">{user.desiredWage}</p>
            </div>
          </div>

          {/* Apply Button */}
          <div className="mt-6 text-center md:text-right md:pr-6">
            <button className="bg-[#3B5D8F] hover:bg-blue-600 text-white font-semibold text-[18px] px-6 py-3 rounded-[11px] transition">
              Apply
            </button>
          </div>
        </div>

        {/* Attachment */}
        <div className="bg-gradient-to-r from-[#3B5D8F] to-[#6587CB] rounded-lg p-6 shadow-lg text-white">
          <h2 className="font-[inria-serif] font-medium tracking-[2px] text-[23px] mb-2">Attachment :</h2>
        </div>
      </div>

      <div className="mt-[115px]">
        <Footer />
      </div>
    </div>
  );
};

export default Details;
