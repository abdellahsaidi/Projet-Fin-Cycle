import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

// Import your components/pages
import Home from "./CandidatHome/Home";
import FeedBack from "./CandidatHome/FeedBack"
import Opportunities from "../Components/CandidatHome/Opportunities";

function HomeApp() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/feedback" element={<FeedBack />} />

        <Route path="/opportunities" element={<Opportunities />} />
      </Routes>
    </Router>
  );
}

export default HomeApp;
