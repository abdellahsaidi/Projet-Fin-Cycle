import React from 'react'
import { Routes, Route } from 'react-router-dom'
import Home from './Entreprise/AccueilEntreprise'
import Talents from './Entreprise/Talents'
import FeedBackEntreprise from './Entreprise/FeedBackEntreprise'

const EntrepriseApp = () => {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/talents" element={<Talents />} />
      <Route path="/feedback" element={<FeedBackEntreprise />} />
    </Routes>
  )
}

export default EntrepriseApp