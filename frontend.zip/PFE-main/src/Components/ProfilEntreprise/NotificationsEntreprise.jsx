import { useState, useEffect } from 'react';
import { FaBell, FaRegBell, FaRegClock, FaCheckCircle } from 'react-icons/fa';
import NavbarEntreprise from '../Entreprise/NavbarEntreprise';
import SidebarEntreprise from './SidebarEntreprise';
import Footer from '../FirstPage/Footer';
import axios from 'axios';

const NotificationsEntreprise = () => {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [darkMode, setDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
      const savedMode = localStorage.getItem('darkMode');
      return savedMode ? JSON.parse(savedMode) : false;
    }
    return false;
  });

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('darkMode', JSON.stringify(darkMode));
  }, [darkMode]);

  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const token = localStorage.getItem('company_access_token');
        const response = await axios.get('/api/company/notifications/', {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setNotifications(response.data);
      } catch (err) {
        setError(err.response?.data?.message || 'Erreur lors du chargement des notifications.');
      } finally {
        setLoading(false);
      }
    };

    fetchNotifications();
  }, []);

  const deleteNotification = async (id) => {
    try {
      const token = localStorage.getItem('company_access_token');
      await axios.delete(`/api/company/notifications/${id}/delete/`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setNotifications(notifications.filter((n) => n.id !== id));
    } catch (err) {
      setError(err.response?.data?.message || 'Erreur lors de la suppression de la notification.');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col dark:bg-gray-900">
        <NavbarEntreprise />
        <div className="flex flex-1 justify-center items-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex flex-col dark:bg-gray-900">
        <NavbarEntreprise />
        <div className="flex flex-1 justify-center items-center">
          <div className="text-red-500 dark:text-red-400">{error}</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col dark:bg-gray-900">
      <NavbarEntreprise />
      <div className="flex flex-1">
        {/* Sidebar */}
        <div className="h-[198vh]">
          <SidebarEntreprise />
        </div>

        {/* Content */}
        <div className="flex-1 flex flex-col">
          <main className="flex-1 p-6 ml-[270px] mt-12">
            <div className="max-w-4xl mx-auto">
              <div className="flex items-center mb-8">
                <FaBell className="text-blue-500 dark:text-blue-400 text-2xl mr-3" />
                <h1 className="font-[Inria-Serif] font-normal text-[45px] tracking-wider dark:text-white">
                  Notifications
                </h1>
              </div>

              {notifications.length === 0 ? (
                <div className="text-center py-10">
                  <p className="text-gray-500 dark:text-gray-400">Aucune information disponible.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-4 rounded-lg border relative ${
                        notification.read
                          ? 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700'
                          : 'bg-blue-50 dark:bg-blue-900/30 border-blue-200 dark:border-blue-700'
                      }`}
                    >
                      {!notification.read && (
                        <div className="absolute top-3 left-3 w-2 h-2 bg-red-500 rounded-full"></div>
                      )}

                      <div className="flex items-start pl-4">
                        <div className="mr-3 pt-1">
                          {notification.read ? (
                            <FaCheckCircle className="text-gray-400 dark:text-gray-500" />
                          ) : (
                            <FaRegBell className="text-blue-500 dark:text-blue-400" />
                          )}
                        </div>
                        <div className="flex-1">
                          <p
                            className={`font-medium ${
                              notification.read
                                ? 'text-gray-600 dark:text-gray-300'
                                : 'text-gray-800 dark:text-white'
                            }`}
                          >
                            {notification.message}
                          </p>
                          <div className="flex items-center mt-2 text-sm text-gray-500 dark:text-gray-400">
                            <FaRegClock className="mr-1" />
                            <span>{new Date(notification.created_at).toLocaleString()}</span>
                          </div>
                        </div>
                        <button
                          onClick={() => deleteNotification(notification.id)}
                          className="ml-2 text-red-600 dark:text-red-400 hover:text-red-800 dark:hover:text-red-300 transition-colors duration-200"
                        >
                          Supprimer
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </main>

          {/* Footer */}
          <div className="dark:bg-gray-800">
            <Footer darkMode={darkMode} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotificationsEntreprise;
