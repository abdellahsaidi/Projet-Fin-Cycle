import React, { useState } from "react";
import {
  FaUser,
  FaFileAlt,
  FaBell,
  FaChartBar,
  FaCog,
  FaSignOutAlt,
} from "react-icons/fa";
import { Link, useNavigate } from "react-router-dom";

const SidebarEntreprise = () => {
  const [showLogoutPopup, setShowLogoutPopup] = useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    setShowLogoutPopup(false);
    navigate("/register"); // Redirect to CompanyForm.jsx route
  };

  return (
    <>
      <div className="w-[270px] h-[157vh] bg-white dark:bg-gray-800 text-black dark:text-white p-3 absolute left-0 top-[108px] border-r-2 border-r-[#00000040] dark:top-[107px]">
        <nav className="space-y-6">
          <SidebarItem icon={<FaUser />} text="My Profile" to="/entreprise/profile" />
          <SidebarItem icon={<FaFileAlt />} text="My Application" to="/entreprise/application" />
          <SidebarItem icon={<FaBell />} text="Notifications" to="/entreprise/notifications" />
          <SidebarItem icon={<FaChartBar />} text="Statistics" to="#" />
          <SidebarItem icon={<FaCog />} text="Settings" to="/entreprise/settings" />
          <SidebarItem
            icon={<FaSignOutAlt />}
            text="Log Out"
            onClick={() => setShowLogoutPopup(true)}
          />
        </nav>
      </div>

      {showLogoutPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex justify-center items-center z-50">
          <div className="bg-white p-6 rounded shadow-lg text-center dark:bg-gray-800 dark:text-white">
            <p className="mb-4 text-[20px] font-semibold">Do you want to log out?</p>
            <div className="flex space-x-4 justify-center">
              <button
                className="px-4 py-2 font-[poppins] font-medium bg-gray-300 hover:bg-gray-400 rounded-lg dark:bg-black dark:hover:bg-slate-600"
                onClick={() => setShowLogoutPopup(false)}
              >
                Cancel
              </button>
              <button
                className="px-4 py-2 font-[poppins] font-medium bg-[#5786e3] hover:bg-blue-600 text-white rounded-lg"
                onClick={handleLogout}
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

const SidebarItem = ({ icon, text, to, onClick }) => {
  const classes =
    "flex items-center font-[poppins] font-medium text-[18px] gap-3 px-2 py-4 rounded hover:bg-blue-600 hover:text-white transition w-full";

  return to ? (
    <Link to={to} className={classes}>
      {icon}
      <span>{text}</span>
    </Link>
  ) : (
    <button onClick={onClick} className={classes + " text-left"}>
      {icon}
      <span>{text}</span>
    </button>
  );
};

export default SidebarEntreprise;
