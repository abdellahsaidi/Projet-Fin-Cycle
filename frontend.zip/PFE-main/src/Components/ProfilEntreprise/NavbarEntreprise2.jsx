import React, { useState, useEffect } from 'react';
import { FaHome, FaCommentAlt, FaMoon, FaSun, FaBell, FaUserCircle, FaChevronDown } from 'react-icons/fa';
import { GiAlliedStar } from "react-icons/gi";
import logo from "../../assets/logo.png";

const NavbarEntreprise2 = () => {
  const [darkMode, setDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
      const savedMode = localStorage.getItem('darkMode');
      if (savedMode !== null) return JSON.parse(savedMode);
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  const [showProfileDropdown, setShowProfileDropdown] = useState(false);
  const [hasNotifications, setHasNotifications] = useState(true);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('darkMode', JSON.stringify(darkMode));
  }, [darkMode]);

  const toggleDarkMode = () => setDarkMode(!darkMode);
  const toggleProfileDropdown = () => setShowProfileDropdown(!showProfileDropdown);

  return (
    <div className="bg-white dark:bg-gray-800 shadow-md p-4 transition-colors duration-300">
      <div className="container mx-auto flex justify-between items-center">
        
        {/* Logo */}
        <div className="w-40 mr-22">
          <img src={logo} alt="Logo" />
        </div>

        <div className="flex items-center space-x-40">
          
          {/* Navigation */}
          <nav className="hidden md:flex space-x-48 font-[Poppins] font-medium text-[22px]">
            <a to="/" className="flex items-center dark:text-white hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
              <FaHome className="mr-2" />
              Home
            </a>
            <a to="/talents" className="flex items-center dark:text-white hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
              <GiAlliedStar className="mr-2" />
              Talents
            </a>
            <a to="/feedback" className="flex items-center dark:text-white hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
              <FaCommentAlt className="mr-2" />
              Feedback
            </a>
          </nav>

          {/* Right Icons */}
          <div className="flex items-center space-x-4">
            
            {/* Notification Icon */}
            <div className="relative">
              <button className="p-2 rounded-full hover:bg-blue-600 dark:hover:bg-blue-400 transition-colors">
                <FaBell className="text-black dark:text-white text-xl" />
                {hasNotifications && (
                  <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
                )}
              </button>
            </div>

            {/* Dark Mode Toggle */}
            <button
              onClick={toggleDarkMode}
              className="p-2 rounded-full hover:bg-blue-700 dark:hover:bg-blue-400 transition-colors"
              aria-label={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
            >
              {darkMode ? (
                <FaSun className="text-yellow-400 text-xl" />
              ) : (
                <FaMoon className="text-black text-xl" />
              )}
            </button>

            {/* Profile Dropdown */}
            <div className="relative">
              <button
                onClick={toggleProfileDropdown}
                className="flex items-center space-x-1 hover:bg-blue-700 dark:hover:bg-blue-400 rounded-full p-1 pr-2 transition-colors"
              >
                <FaUserCircle className="text-gray-700 dark:text-gray-300 text-2xl" />
                <FaChevronDown
                  className={`text-gray-500 dark:text-gray-400 text-xs transition-transform ${
                    showProfileDropdown ? 'transform rotate-180' : ''
                  }`}
                />
              </button>

              {showProfileDropdown && (
                <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-700 rounded-md shadow-lg py-1 z-50">
                  <a href="#" className="block px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-600">
                    Your Profile
                  </a>
                  <a href="#" className="block px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-600">
                    Settings
                  </a>
                  <a href="#" className="block px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-600">
                    Sign out
                  </a>
                </div>
              )}
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};

export default NavbarEntreprise2;


