import React, { useState, useEffect } from "react";
import NavbarEntreprise from "../Entreprise/NavbarEntreprise";
import SidebarEntreprise from "./SidebarEntreprise";
import Footer from "../FirstPage/Footer";
import {
  FaEnvelope,
  FaPhone,
  FaMapMarkerAlt,
  FaFacebook,
  FaGithub,
  FaLinkedin,
} from "react-icons/fa";
import { MdEdit } from "react-icons/md";
import { AiOutlinePlus } from "react-icons/ai";
import { GoOrganization } from "react-icons/go";
import { FiUpload } from "react-icons/fi";

const MyProfilEntreprise = () => {
  const [darkMode, setDarkMode] = useState(false);
  const [showRequirements, setShowRequirements] = useState(true);
  const [showAdvantages, setShowAdvantages] = useState(true);
  const [showPersonalDataPopup, setShowPersonalDataPopup] = useState(false);
  const [showEditCVPopup, setShowEditCVPopup] = useState(false); 
  const [showAddRequirementPopup, setShowAddRequirementPopup] = useState(false);
  const [showEditRequirementPopup, setShowEditRequirementPopup] = useState(false);
  const [showAddAdvantagePopup, setShowAddAdvantagePopup] = useState(false);
  const [showEditAdvantagePopup, setShowEditAdvantagePopup] = useState(false);

  useEffect(() => {
    const mode = localStorage.getItem("darkMode");
    if (mode !== null) setDarkMode(JSON.parse(mode));

    const observer = new MutationObserver(() => {
      const updated = localStorage.getItem("darkMode");
      setDarkMode(JSON.parse(updated));
    });

    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["class"],
    });

    return () => observer.disconnect();
  }, []);

  const cardClass = `border-4 border-[#5786e3] rounded-lg p-5 bg-white dark:bg-gray-800 shadow-md mb-5`;

  return (
    <div className="flex flex-col dark:bg-gray-900 min-h-screen">
      <NavbarEntreprise/>
      {/* <NavbarEntreprise/> */}
      <div className="flex flex-1">

      <div className="h-[157vh]">
        <SidebarEntreprise />
        </div>

        <main className={`flex-1 p-6 ${darkMode ? "text-white" : "text-black"} mt-1`}>
          <div className="max-w-2xl mx-auto">
            <h1 className="text-4xl font-[Inria-Serif] mt-5 font-medium mb-9">My Profile</h1>

            {/* Job Offers */}
            <div className={cardClass}>
              <div className="flex justify-between items-start mb-3">
                <h2 className="text-xl font-[poppins] font-medium">Job Offers</h2>
                <div className="flex space-x-2">
                  <button
                    className="p-2 rounded-full bg-[#6688CC] hover:bg-blue-300"
                    onClick={() => setShowEditCVPopup(true)}
                  >
                    <MdEdit className="text-xl" />
                  </button>
                </div>
              </div>
              <div className="text-lg font-[poppins] font-medium">
                <p className="mb-2">Domain:</p>
                <p className="mb-2">Position:</p>
                <p className="mb-2">Number of Positions:</p>
                <p className="mb-2">Education Level Required:</p>
                <p className="mb-2">Contract Type:</p>
                <p className="mb-2">Date of Expiration:</p>
              </div>
            </div>

            {/* Company Data */}
            <div className={cardClass}>
              <div className="flex justify-between items-start mb-3">
                <h2 className="text-xl font-[poppins] font-medium">Company Data</h2>
                <button
                  className="p-2 rounded-full bg-[#6688CC] hover:bg-blue-300"
                  onClick={() => setShowPersonalDataPopup(true)}
                >
                  <MdEdit className="text-xl" />
                </button>
              </div>
              <div className="flex items-center space-x-2 mb-2">
                <GoOrganization className="text-4xl text-[#6688CC]" />
                <p className="text-lg font-medium">Company Name</p>
              </div>
              <div className="space-y-2 text-sm font-[poppins]">
                <div className="flex items-center">
                  <FaEnvelope className="mr-2 mb-2" />
                  <span className="mb-2">contact@company.com</span>
                </div>
                <div className="flex items-center">
                  <FaPhone className="mr-2 mb-2" />
                  <span className="mb-2">+213 59 XX XX XX X</span>
                </div>
                <div className="flex items-center">
                  <FaMapMarkerAlt className="mr-2 mb-2" />
                  <span className="mb-2">Alger, Blida, USDB</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="font-semibold ml-2">Social Media links :</span>
                  <FaGithub className="text-lg" />
                  <FaFacebook className="text-blue-500 text-lg" />
                  <FaLinkedin className="text-blue-500 text-lg" />
                </div>
              </div>
            </div>

            {/* Requirements */}
            <div className={cardClass}>
              <div className="flex justify-between items-center mb-3">
                <h2 className="text-xl font-[poppins] font-medium">Requirements</h2>
                <div className="flex space-x-2">
                  <button
                    className="p-2 rounded-full border-2 border-[#6688CC] mr-2 hover:bg-blue-300"
                    onClick={() => setShowAddRequirementPopup(true)}
                  >
                    <AiOutlinePlus />
                  </button>
                  <button
                    className="p-2 rounded-full bg-[#6688CC] hover:bg-blue-300"
                    onClick={() => setShowEditRequirementPopup(true)}
                  >
                    <MdEdit />
                  </button>
                </div>
              </div>
              {showRequirements && (
                <ul className="list-disc pl-6 space-y-2 text-sm font-[poppins] font-medium">
                  <li>Minimum 3 years of experience in the field</li>
                  <li>Strong problem-solving skills</li>
                  <li>Ability to work in a team environment</li>
                </ul>
              )}
            </div>

            {/* Advantages */}
            <div className={cardClass}>
              <div className="flex justify-between items-center mb-3">
                <h2 className="text-xl font-[Poppins] font-medium">Advantages</h2>
                <div className="flex space-x-2">
                  <button
                    className="p-2 rounded-full border-2 border-[#6688CC] mr-2 hover:bg-blue-300"
                    onClick={() => setShowAddAdvantagePopup(true)}
                  >
                    <AiOutlinePlus />
                  </button>
                  <button
                    className="p-2 rounded-full bg-[#6688CC] hover:bg-blue-300"
                    onClick={() => setShowEditAdvantagePopup(true)}
                  >
                    <MdEdit />
                  </button>
                </div>
              </div>
              {showAdvantages && (
                <ul className="list-disc pl-6 space-y-2 text-sm font-[poppins] font-medium">
                  <li>Opportunity to work in a dynamic and innovative environment</li>
                  <li>Opportunity to take part in a variety of stimulating projects</li>
                  <li>Ongoing training and career development opportunities</li>
                </ul>
              )}
            </div>
          </div>
        </main>
      </div>

      {/* Edit Job Offers Popup */}
      {showEditCVPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex justify-center items-center z-50">
          <div className="bg-white dark:bg-gray-700 border-4 border-[#5786e3] p-6 rounded-lg shadow-lg w-full max-w-md flex flex-col">
            <h2 className="font-[inria-serif] font-normal text-xl mb-6 dark:text-white text-center">Editing Job Offers</h2>
           
            <select className="w-full border-2 border-[#5786e3] rounded-lg p-2 mb-4 font-[Poppins] font-semibold">
              <option>Domain</option>
            </select>
            <input 
              type="text" 
              placeholder="Position" 
              className="w-full border-2 border-[#5786e3] rounded-lg font-[Poppins] placeholder-black dark:placeholder-gray-300 placeholder:font-[600] p-2 mb-4" 
            />

            <input 
              type="text" 
              placeholder="Number of Positions" 
              className="w-full border-2 border-[#5786e3] rounded-lg font-[Poppins] placeholder-black dark:placeholder-gray-300 placeholder:font-[600] p-2 mb-4" 
            />

            <select className="w-full border-2 border-[#5786e3] rounded-lg p-2 mb-4 font-[Poppins] font-semibold">
              <option>Education Level</option>
            </select>
            <input 
              type="text" 
              placeholder="Contract type" 
              className="w-full border-2 border-[#5786e3] rounded-lg font-[Poppins] placeholder-black dark:placeholder-gray-300 placeholder:font-[600] p-2 mb-4" 
            />

            <input 
              type="date" 
              placeholder="Expiration date" 
              className="w-full border-2 border-[#5786e3] rounded-lg font-[Poppins] placeholder-black dark:placeholder-gray-300 placeholder:font-[600] p-2 mb-6" 
            />

            <button
              className="bg-[#3B5D8F] hover:bg-blue-600 text-white font-[Poppins] px-6 py-2 rounded-lg self-end"
              onClick={() => setShowEditCVPopup(false)}
            >
              Save
            </button>
          </div>
        </div>
      )}

      {/* Edit Personal Data Popup */}
      {showPersonalDataPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex justify-center items-center z-50">
          <div className="bg-white dark:bg-gray-800 border-4 border-[#5786e3] p-6 rounded-lg shadow-lg w-full max-w-md">
            <h2 className="text-center tracking-wider font-medium text-xl font-[inria-serif] mb-6 dark:text-white">
              Editing Company Data
            </h2>
            <div className="flex items-start justify-between mb-4">
              <div className="flex flex-col space-y-3 w-[70%]">
                <input 
                  type="text" 
                  placeholder="Company Name" 
                  className="p-2 border-2 border-[#5786e3] rounded-lg font-[Poppins] placeholder-black dark:placeholder-gray-300 placeholder:font-[600]" 
                />
                <input 
                  type="email" 
                  placeholder="Email" 
                  className="p-2 border-2 border-[#5786e3] rounded-lg font-[Poppins] placeholder-black dark:placeholder-gray-300 placeholder:font-[600]" 
                />
              </div>
              <div className="border-2 border-dashed border-[#3B5D8F] p-3 w-24 h-24 flex flex-col items-center justify-center rounded ml-2">
                <label className="cursor-pointer flex flex-col items-center text-gray-500 text-center text-xs">
                  <FiUpload className="text-2xl mb-1 text-[#3B5D8F] dark:text-white" />
                  <span className="text-black font-semibold font-[Poppins] dark:text-white">Upload Logo</span>
                  <input type="file" className="hidden" />
                </label>
              </div>
            </div>
            <form className="space-y-4">
              <input 
                type="text" 
                placeholder="Phone Number" 
                className="w-full p-2 border-2 border-[#5786e3] rounded-lg font-[Poppins] placeholder-black dark:placeholder-gray-300 placeholder:font-[600]" 
              />
              <input 
                type="text" 
                placeholder="Address" 
                className="w-full p-2 border-2 border-[#5786e3] rounded-lg font-[Poppins] placeholder-black dark:placeholder-gray-300 placeholder:font-[600]" 
              />
              <input 
                type="text" 
                placeholder="GitHub Link" 
                className="w-full p-2 border-2 border-[#5786e3] rounded-lg font-[Poppins] placeholder-black dark:placeholder-gray-300 placeholder:font-[600]" 
              />
              <input 
                type="text" 
                placeholder="Facebook Link" 
                className="w-full p-2 border-2 border-[#5786e3] rounded-lg font-[Poppins] placeholder-black dark:placeholder-gray-300 placeholder:font-[600]" 
              />
              <input 
                type="text" 
                placeholder="LinkedIn Link" 
                className="w-full p-2 border-2 border-[#5786e3] rounded-lg font-[Poppins] placeholder-black dark:placeholder-gray-300 placeholder:font-[600]" 
              />
              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={() => setShowPersonalDataPopup(false)}
                  className="bg-[#3B5D8F] font-[Poppins] hover:bg-blue-400 text-white px-6 py-2 rounded-lg"
                >
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Requirement Popup */}
      {showAddRequirementPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex justify-center items-center z-50">
          <div className="bg-white border-4 border-[#5786e3] rounded-lg p-6 w-full max-w-md">
            <h2 className="text-center text-xl font-[Inria-Serif] font-medium mb-4">
              Adding Requirements
            </h2>
            <textarea
              rows="4"
              className="w-full border-2 border-[#5786e3] rounded-lg p-2 mb-4 resize-none focus:outline-none"
              placeholder="Enter requirement..."
            />
            <div className="flex justify-end">
              <button
                onClick={() => setShowAddRequirementPopup(false)}
                className="bg-[#3B5D8F] font-[Poppins] hover:bg-blue-400 text-white px-6 py-2 rounded-lg"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Requirement Popup */}
      {showEditRequirementPopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex justify-center items-center z-50">
          <div className="bg-white border-4 border-[#5786e3] rounded-lg p-6 w-full max-w-md">
            <h2 className="text-center text-xl font-[Inria-Serif] font-medium mb-4">Editing Requirements</h2>
            <ul className="space-y-2 mb-4">
              <li className="flex items-center">
                <input type="text" defaultValue="Minimum 3 years of experience" className="border-2 border-[#5786e3] rounded-lg p-1 w-full" />
                <button className="ml-2 text-red-500">×</button>
              </li>
              <li className="flex items-center">
                <input type="text" defaultValue="Strong problem-solving skills" className="border-2 border-[#5786e3] rounded-lg p-1 w-full" />
                <button className="ml-2 text-red-500">×</button>
              </li>
              <li className="flex items-center">
                <input type="text" defaultValue="Ability to work in a team" className="border-2 border-[#5786e3] rounded-lg p-1 w-full" />
                <button className="ml-2 text-red-500">×</button>
              </li>
            </ul>
            <button className="flex items-center text-[#3B5D8F] mb-4">
              <AiOutlinePlus className="mr-1" /> Add New Requirement
            </button>
            <div className="flex justify-end">
              <button
                onClick={() => setShowEditRequirementPopup(false)}
                className="bg-[#3B5D8F] font-[Poppins] hover:bg-blue-400 text-white px-6 py-2 rounded-lg"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Advantage Popup */}
      {showAddAdvantagePopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex justify-center items-center z-50">
          <div className="bg-white border-4 border-[#5786e3] rounded-lg p-6 w-full max-w-md">
            <h2 className="text-center text-xl font-[Inria-Serif] font-medium mb-4">Adding Advantages</h2>
            <input
              type="text"
              placeholder="Enter advantage..."
              className="w-full border-2 border-[#6688CC] rounded-lg p-2 mb-4"
            />
            <div className="flex justify-end">
              <button
                onClick={() => setShowAddAdvantagePopup(false)}
                className="bg-[#3B5D8F] font-[Poppins] hover:bg-blue-400 text-white px-6 py-2 rounded-lg"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Advantage Popup */}
      {showEditAdvantagePopup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex justify-center items-center z-50">
          <div className="bg-white border-4 border-[#5786e3] rounded-lg p-6 w-full max-w-md">
            <h2 className="text-center text-xl font-[Inria-Serif] font-medium mb-4">Editing Advantages</h2>
            <ul className="space-y-2 mb-4">
              <li className="flex items-center">
                <input type="text" defaultValue="Dynamic work environment" className="border-2 border-[#5786e3] rounded-lg p-1 w-full" />
                <button className="ml-2 text-red-500">×</button>
              </li>
              <li className="flex items-center">
                <input type="text" defaultValue="Stimulating projects" className="border-2 border-[#5786e3] rounded-lg p-1 w-full" />
                <button className="ml-2 text-red-500">×</button>
              </li>
              <li className="flex items-center">
                <input type="text" defaultValue="Career development" className="border-2 border-[#5786e3] rounded-lg p-1 w-full" />
                <button className="ml-2 text-red-500">×</button>
              </li>
            </ul>
            <button className="flex items-center text-[#3B5D8F] mb-4">
              <AiOutlinePlus className="mr-1" /> Add New Advantage
            </button>
            <div className="flex justify-end">
              <button
                onClick={() => setShowEditAdvantagePopup(false)}
                className="bg-[#3B5D8F] font-[Poppins] hover:bg-blue-400 text-white px-6 py-2 rounded-lg"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="mt-[1px]">
        <Footer />
      </div>
    </div>
  );
};

export default MyProfilEntreprise;