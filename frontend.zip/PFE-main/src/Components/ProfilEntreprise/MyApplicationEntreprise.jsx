import React, { useEffect, useState } from 'react';
import axios from 'axios';
import NavbarEntreprise from '../Entreprise/NavbarEntreprise';
import SidebarEntreprise from './SidebarEntreprise';
import { FaBriefcase, FaRegFileAlt, FaRegStar } from 'react-icons/fa';
import { FiFileText, FiAward } from "react-icons/fi";
import Footer from "../FirstPage/Footer";

const renderStars = () => {
  return Array.from({ length: 5 }, (_, i) => <FaRegStar key={i} className="text-gray-400" />);
};

const MyApplicationEntreprise = () => {
  const [applications, setApplications] = useState([]);

  useEffect(() => {
    const fetchApplications = async () => {
      try {
        const token = localStorage.getItem('token'); // assuming you store JWT like this
        const response = await axios.get('http://localhost:8000/company/applications/', {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setApplications(response.data);
      } catch (error) {
        console.error('Error fetching applications:', error);
      }
    };

    fetchApplications();
  }, []);

  return (
    <div className="flex flex-col dark:bg-gray-900">
      <NavbarEntreprise />
      <div className="flex flex-1">
        <div className="h-[135vh]">
          <SidebarEntreprise />
        </div>
        <main className="flex-1 p-6 mt-1 dark:bg-gray-900 text-black dark:text-white">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-[48px] font-[Inria-Serif] font-medium mb-8 mt-8">My Applications</h1>

            <div className="border-4 border-[#5786e3] rounded-lg p-4 bg-white dark:bg-gray-800 space-y-4">
              {applications.length === 0 ? (
                <p>No applications found.</p>
              ) : (
                applications.map((app, index) => (
                  <div
                    key={index}
                    className="border-2 border-[#5786e3] rounded-lg p-3 bg-white dark:bg-gray-700 shadow-sm"
                  >
                    <div className="flex items-center mb-2">
                      <FaBriefcase className="text-[#3B5D8F] mr-3 text-xl" />
                      <h2 className="font-[Poppins] font-semibold text-lg">{app.name}</h2>
                    </div>
                    <div className="flex items-center mb-1 ml-7">
                      <FaRegFileAlt className="text-[#3B5D8F] mr-2" />
                      <p className="font-[poppins] text-[15px] text-[#3B5D8F] dark:text-white">{app.position}</p>
                    </div>
                    <div className="flex ml-8 mt-4 ">{renderStars()}</div>
                    <div className="flex space-x-2 mt-3 ml-[500px] ">
                      <span className="flex items-center bg-[#3B5D8F] h-7 text-white px-2 py-1 text-xs rounded-lg">
                        <FiFileText className="mr-1" />
                        {app.degree}
                      </span>
                      <span className="flex items-center bg-[#3B5D8F] text-white px-2 py-1 text-xs rounded-lg">
                        <FiAward className="mr-1" />
                        {app.experience}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </main>
      </div>
      <div className="mt-[201px]">
        <Footer />
      </div>
    </div>
  );
};

export default MyApplicationEntreprise;
