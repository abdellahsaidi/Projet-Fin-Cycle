import React, { useState } from "react";
import axios from "axios";
import NavbarEntreprise from "../Entreprise/NavbarEntreprise";
import SidebarEntreprise from "./SidebarEntreprise";
import Footer from "../FirstPage/Footer";
import { FaEnvelope, FaPhoneAlt, FaLock } from "react-icons/fa";

const SettingsEntreprise = () => {
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const token = localStorage.getItem("token"); // adapte selon ton système

  const handleSave = async (field) => {
    let data = {};

    switch (field) {
      case "email":
        data = { email };
        break;
      case "phone":
        data = { phone };
        break;
      case "password":
        if (password !== confirmPassword) {
          setError("Passwords do not match.");
          return;
        }
        data = { password };
        break;
      default:
        return;
    }

    try {
      setError("");
      setMessage("");

      const response = await axios.patch(
        "/api/company/settings/",
        data,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );

      setMessage("Changes saved successfully.");
    } catch (err) {
      setError(
        err.response?.data?.detail || "An error occurred while saving settings."
      );
    }
  };

  return (
    <div className="min-h-screen flex flex-col text-black dark:bg-gray-900 dark:text-white">
      <NavbarEntreprise />
      <div className="flex flex-1 min-h-[132vh]">
        <SidebarEntreprise />

        <div className="flex-1 p-6 flex flex-col justify-between">
          <div className="max-w-2xl mx-auto font-[poppins] flex-grow">
            <h2 className="font-medium text-[48px] font-[Inria-Serif] mb-6">Settings</h2>

            {/* Messages */}
            {(message || error) && (
              <div className={`mb-4 px-4 py-2 rounded ${error ? "bg-red-200 text-red-700" : "bg-green-200 text-green-700"}`}>
                {error || message}
              </div>
            )}

            {/* Email Section */}
            <div className="border-4 w-[45vw] mt-10 border-[#5786e3] dark:border-blue-400 bg-white dark:bg-gray-800 rounded-lg p-4 mb-6">
              <div className="relative mb-4">
                <input
                  type="email"
                  placeholder="Enter your new e-mail address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-2 pr-10 rounded-full font-poppins placeholder-black dark:placeholder-white border-4 border-[#5786e3] dark:border-blue-400 bg-white dark:bg-gray-900 text-black dark:text-white focus:outline-none"
                />
                <FaEnvelope className="absolute right-3 top-4 text-black dark:text-white" />
              </div>
              <div className="text-right">
                <button onClick={() => handleSave("email")} className="bg-[#3B5D8F] font-semibold text-[15px] text-white px-6 py-2 rounded-full hover:bg-[#2d4770] transition">
                  Save
                </button>
              </div>
            </div>

            {/* Phone Section */}
            <div className="border-4 w-[45vw] mt-20 border-[#5786e3] dark:border-blue-400 bg-white dark:bg-gray-800 rounded-lg p-4 mb-6">
              <div className="relative mb-4">
                <input
                  type="tel"
                  placeholder="Enter your new phone number"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-4 py-2 pr-10 rounded-full font-poppins placeholder-black dark:placeholder-white border-4 border-[#5786e3] dark:border-blue-400 bg-white dark:bg-gray-900 text-black dark:text-white focus:outline-none"
                />
                <FaPhoneAlt className="absolute right-3 top-3 text-black dark:text-white" />
              </div>
              <div className="text-right">
                <button onClick={() => handleSave("phone")} className="bg-[#3B5D8F] font-semibold text-[15px] text-white px-6 py-2 rounded-full hover:bg-[#2d4770] transition">
                  Save
                </button>
              </div>
            </div>

            {/* Password Section */}
            <div className="border-4 w-[45vw] mt-20 border-[#5786e3] dark:border-blue-400 bg-white dark:bg-gray-800 rounded-lg p-4">
              <div className="relative mb-4">
                <input
                  type="password"
                  placeholder="Enter your new password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-2 pr-10 mb-4 rounded-full font-poppins placeholder-black dark:placeholder-white border-4 border-[#5786e3] dark:border-blue-400 bg-white dark:bg-gray-900 text-black dark:text-white focus:outline-none"
                />
                <FaLock className="absolute right-3 top-3 text-black dark:text-white" />
              </div>
              <div className="relative mb-4">
                <input
                  type="password"
                  placeholder="Confirm your new password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full px-4 py-2 pr-10 rounded-full font-poppins placeholder-black dark:placeholder-white border-4 border-[#5786e3] dark:border-blue-400 bg-white dark:bg-gray-900 text-black dark:text-white focus:outline-none"
                />
                <FaLock className="absolute right-3 top-4 text-black dark:text-white" />
              </div>
              <div className="text-right">
                <button onClick={() => handleSave("password")} className="bg-[#3B5D8F] font-semibold text-[15px] text-white px-6 py-2 rounded-full hover:bg-[#2d4770] transition">
                  Save
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-[228px]">
        <Footer />
      </div>
    </div>
  );
};

export default SettingsEntreprise;
