from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions, generics,viewsets
from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken
from .serializers import (
    CandidateDetailSerializer,
    CandidateFeedbackManagerSerializer,
    CandidateListSerializer,
    CandidatePhotoUploadSerializer,
    CandidateSignupSerializer,
    CandidateLoginSerializer,
    CompanyFeedbackManagerSerializer,
    CompanyListSerializer,
    CompanyNotificationSerializer,
    CompanySignupSerializer,
    CompanyLoginSerializer,
    JobOfferManagementSerializer,
    ManagerLoginSerializer,
    OpportunityOfferManagerSerializer,
    TalentCandidateSerializer,
)
from .models import CandidateFeedback, CandidateNotification, CompanyFeedback, CompanyNotification, User

# --- CANDIDATE ---


class CandidateSignupView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = CandidateSignupSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(
                {"message": "Compte candidat créé avec succès."},
                status=status.HTTP_201_CREATED,
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class CandidateLoginView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = CandidateLoginSerializer(data=request.data)
        if serializer.is_valid():
            email = serializer.validated_data["email"]
            password = serializer.validated_data["password"]
            user = authenticate(request, email=email, password=password)
            if user is not None and user.user_type == "candidate":
                refresh = RefreshToken.for_user(user)
                return Response(
                    {
                        "refresh": str(refresh),
                        "access": str(refresh.access_token),
                    }
                )
            else:
                return Response(
                    {"error": "Email ou mot de passe incorrect."},
                    status=status.HTTP_401_UNAUTHORIZED,
                )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class CandidateLogoutView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        try:
            refresh_token = request.data["refresh"]
            token = RefreshToken(refresh_token)
            token.blacklist()
            return Response(
                {"message": "Déconnexion réussie."},
                status=status.HTTP_205_RESET_CONTENT,
            )
        except Exception:
            return Response(
                {"error": "Token invalide ou déjà blacklisté."},
                status=status.HTTP_400_BAD_REQUEST,
            )


# --- COMPANY ---


class CompanySignupView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = CompanySignupSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(
                {"message": "Compte entreprise créé avec succès."},
                status=status.HTTP_201_CREATED,
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class CompanyLoginView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = CompanyLoginSerializer(data=request.data)
        if serializer.is_valid():
            email = serializer.validated_data["email"]
            password = serializer.validated_data["password"]
            user = authenticate(request, email=email, password=password)
            if user is not None and user.user_type == "company":
                refresh = RefreshToken.for_user(user)
                return Response(
                    {
                        "refresh": str(refresh),
                        "access": str(refresh.access_token),
                    }
                )
            else:
                return Response(
                    {"error": "Email ou mot de passe incorrect."},
                    status=status.HTTP_401_UNAUTHORIZED,
                )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class CompanyLogoutView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        try:
            refresh_token = request.data["refresh"]
            token = RefreshToken(refresh_token)
            token.blacklist()
            return Response(
                {"message": "Déconnexion réussie."},
                status=status.HTTP_205_RESET_CONTENT,
            )
        except Exception:
            return Response(
                {"error": "Token invalide ou déjà blacklisté."},
                status=status.HTTP_400_BAD_REQUEST,
            )

class ManagerLoginView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = ManagerLoginSerializer(data=request.data)
        if serializer.is_valid():
            email = serializer.validated_data["email"]
            password = serializer.validated_data["password"]
            user = authenticate(request, email=email, password=password)  # avec backend email OU username=email
            # ou user = authenticate(request, username=email, password=password)
            if user is not None and user.user_type == "manager":
                refresh = RefreshToken.for_user(user)
                return Response(
                    {
                        "refresh": str(refresh),
                        "access": str(refresh.access_token),
                    }
                )
            else:
                return Response(
                    {"error": "Email or password incorrect, or not a manager."},
                    status=status.HTTP_401_UNAUTHORIZED,
                )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class ManagerLogoutView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        try:
            refresh_token = request.data["refresh"]
            token = RefreshToken(refresh_token)
            token.blacklist()
            return Response(
                {"message": "Logout successful."}, status=status.HTTP_205_RESET_CONTENT
            )
        except Exception:
            return Response(
                {"error": "Invalid or already blacklisted token."},
                status=status.HTTP_400_BAD_REQUEST,
            )


from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from .serializers import CandidateSettingsSerializer


class CandidateSettingsView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request):
        user = request.user
        if user.user_type != "candidate":
            return Response(
                {"error": "Unauthorized."}, status=status.HTTP_403_FORBIDDEN
            )
        serializer = CandidateSettingsSerializer(user, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({"message": "Settings updated successfully."})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from .serializers import CompanySettingsSerializer


class CompanySettingsView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request):
        user = request.user
        if user.user_type != "company":
            return Response(
                {"error": "Unauthorized."}, status=status.HTTP_403_FORBIDDEN
            )
        serializer = CompanySettingsSerializer(user, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({"message": "Settings updated successfully."})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from .serializers import ManagerSettingsSerializer


class ManagerSettingsView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request):
        user = request.user
        if user.user_type != "manager":
            return Response(
                {"error": "Unauthorized."}, status=status.HTTP_403_FORBIDDEN
            )
        serializer = ManagerSettingsSerializer(user, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({"message": "Settings updated successfully."})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from .serializers import (
    CandidateCVSerializer,
    CandidateProfileSerializer,
    CandidateHiringPreferenceSerializer,
)
from .models import CandidateProfile, CandidateCV


# --- Modifier le CV ---
class CandidateCVUpdateView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request):
        profile = request.user.candidate_profile
        # Création du CV s'il n'existe pas
        cv, created = CandidateCV.objects.get_or_create(user=request.user)
        serializer = CandidateCVSerializer(cv, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({"message": "CV updated successfully."})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# --- Modifier les données personnelles ---


class CandidateProfileUpdateView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request):
        # Création du profil s'il n'existe pas
        profile, created = CandidateProfile.objects.get_or_create(user=request.user)
        serializer = CandidateProfileSerializer(
            profile, data=request.data, partial=True
        )
        if serializer.is_valid():
            serializer.save()
            return Response({"message": "Personal data updated successfully."})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# --- Modifier les préférences d’embauche ---
class CandidateHiringPreferenceUpdateView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request):
        profile = request.user.candidate_profile
        serializer = CandidateHiringPreferenceSerializer(
            profile, data=request.data, partial=True
        )
        if serializer.is_valid():
            serializer.save()
            return Response({"message": "Hiring preferences updated successfully."})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# --- API globale : afficher tout le profil ---
class CandidateFullProfileView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        profile, _ = CandidateProfile.objects.get_or_create(user=request.user)
        # Accès au CV via user.candidate_cv, pas via profile
        try:
            cv = request.user.candidate_cv
        except CandidateCV.DoesNotExist:
            cv = None
        profile_data = CandidateProfileSerializer(profile).data
        cv_data = CandidateCVSerializer(cv).data if cv else None
        hiring_pref_data = {
            "work_type": profile.work_type,
            "desired_wage": profile.desired_wage,
        }
        return Response(
            {
                "personal_data": profile_data,
                "cv": cv_data,
                "hiring_preferences": hiring_pref_data,
            }
        )


from django.http import FileResponse, Http404


def download_cv(request, user_id):
    try:
        cv = CandidateCV.objects.get(user_id=user_id)
        return FileResponse(cv.cv_file.open(), content_type="application/pdf")
    except CandidateCV.DoesNotExist:
        raise Http404("CV not found")


# job offer
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from .models import CompanyProfile, JobOffer, Requirement, Advantage
from .serializers import (
    EditCompanyDataSerializer,
    EditJobOfferSerializer,
    AddRequirementSerializer,
    AddAdvantageSerializer,
)


# --- Modifier les données entreprise ---
class EditCompanyDataView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request):
        profile, _ = CompanyProfile.objects.get_or_create(user=request.user)
        serializer = EditCompanyDataSerializer(profile, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({"message": "Company data updated successfully."})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# --- Modifier ou ajouter une offre d'emploi ---
class EditJobOfferView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request, offer_id=None):
        profile, _ = CompanyProfile.objects.get_or_create(user=request.user)
        if offer_id:
            job_offer = JobOffer.objects.filter(id=offer_id, company=profile).first()
            if not job_offer:
                return Response(
                    {"error": "Job offer not found."}, status=status.HTTP_404_NOT_FOUND
                )
        else:
            job_offer = JobOffer.objects.create(company=profile)
        serializer = EditJobOfferSerializer(job_offer, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({"message": "Job offer updated successfully."})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# --- Ajouter ou modifier une exigence ---
class AddRequirementView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request, offer_id):
        job_offer = JobOffer.objects.filter(
            id=offer_id, company__user=request.user
        ).first()
        if not job_offer:
            return Response(
                {"error": "Job offer not found."}, status=status.HTTP_404_NOT_FOUND
            )
        requirement, _ = Requirement.objects.get_or_create(offer=job_offer)
        serializer = AddRequirementSerializer(
            requirement, data=request.data, partial=True
        )
        if serializer.is_valid():
            serializer.save()
            return Response({"message": "Requirement updated successfully."})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# --- Ajouter ou modifier un avantage ---
class AddAdvantageView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request, offer_id):
        job_offer = JobOffer.objects.filter(
            id=offer_id, company__user=request.user
        ).first()
        if not job_offer:
            return Response(
                {"error": "Job offer not found."}, status=status.HTTP_404_NOT_FOUND
            )
        advantage, _ = Advantage.objects.get_or_create(offer=job_offer)
        serializer = AddAdvantageSerializer(advantage, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({"message": "Advantage updated successfully."})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import permissions, status
from .models import CompanyProfile, JobOffer
from .serializers import CompanyProfileSerializer
from .serializers import EditJobOfferSerializer


class CompanyFullProfileView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        # Récupère ou crée le profil entreprise pour l'utilisateur connecté
        try:
            profile = request.user.company_profile
        except CompanyProfile.DoesNotExist:
            return Response(
                {"error": "Company profile not found."},
                status=status.HTTP_404_NOT_FOUND,
            )

        company_data = CompanyProfileSerializer(profile).data

        # Récupère toutes les offres d'emploi de cette entreprise
        job_offers = JobOffer.objects.filter(company=profile)
        job_offers_data = EditJobOfferSerializer(job_offers, many=True).data

        return Response({"company_data": company_data, "job_offers": job_offers_data})


from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializers import CandidateFeedbackSerializer, CompanyFeedbackSerializer


class CandidateFeedbackView(APIView):
    def post(self, request):
        serializer = CandidateFeedbackSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(
                {"message": "Feedback envoyé avec succès."},
                status=status.HTTP_201_CREATED,
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class CompanyFeedbackView(APIView):
    def post(self, request):
        serializer = CompanyFeedbackSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(
                {"message": "Feedback envoyé avec succès."},
                status=status.HTTP_201_CREATED,
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# page home
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import JobOffer
from django.db.models import F


class CandidateHomeView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        # Sélectionne 5 offres random (ou moins si <5)
        offers = JobOffer.objects.select_related("company").order_by("?")[
            :5
        ]  # order_by('?') pour random, slice pour max 5
        data = [
            {
                "domain": offer.domain,
                "company_name": offer.company.name,
                "company_address": offer.company.address,
                "expiration_date": offer.expiration,
            }
            for offer in offers
        ]
        return Response(data, status=status.HTTP_200_OK)


class CompanyHomeView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        # On prend les users qui ont un CV (relation OneToOne)
        users_with_cv = User.objects.filter(
            user_type="candidate", candidate_cv__isnull=False
        ).order_by("?")[:5]
        data = []
        for user in users_with_cv:
            profile = getattr(user, "candidate_profile", None)
            cv = getattr(user, "candidate_cv", None)
            data.append(
                {
                    "full_name": profile.full_name if profile else None,
                    "domain": cv.domain if cv else None,
                    "rating": getattr(cv, "rating", None) if cv else None,
                    "cv_type": cv.cv_type if cv else None,
                    "education_level": cv.education_level if cv else None,
                    "years_of_experience": cv.years_of_experience if cv else None,
                }
            )
        return Response(data, status=status.HTTP_200_OK)


from rest_framework.generics import ListAPIView
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.pagination import PageNumberPagination
from django_filters.rest_framework import DjangoFilterBackend
from .models import JobOffer
from .serializers import OpportunityOfferSerializer


# Pagination personnalisée (5 offres par page par défaut)
class OpportunitiesPagination(PageNumberPagination):
    page_size = 5
    page_size_query_param = "page_size"


# API 1 : Liste paginée des offres avec filtres en query params
class OpportunitiesListView(ListAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = OpportunityOfferSerializer
    queryset = JobOffer.objects.select_related("company").all()
    filter_backends = [DjangoFilterBackend]
    filterset_fields = [
        "domain",
        "position",
        "education_level",
        "contract_type",
        "expiration",
        "is_approved",
        "years_of_experience",
    ]


# API 2 : Liste des valeurs de filtres disponibles
class OpportunitiesFiltersView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        return Response(
            {
                "education_levels": list(
                    JobOffer.objects.values_list(
                        "education_level", flat=True
                    ).distinct()
                ),
                "domains": list(
                    JobOffer.objects.values_list("domain", flat=True).distinct()
                ),
                "years_of_experience": list(
                    JobOffer.objects.values_list(
                        "years_of_experience", flat=True
                    ).distinct()
                ),
                "telecommuting_options": [True, False],
            }
        )


from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import JobOffer
from .serializers import JobOfferDetailSerializer


class JobOfferDetailView(APIView):
    def get(self, request, offer_id):
        try:
            offer = (
                JobOffer.objects.select_related("company")
                .prefetch_related("requirements", "advantages")
                .get(id=offer_id)
            )
        except JobOffer.DoesNotExist:
            return Response(
                {"detail": "Offre non trouvée."}, status=status.HTTP_404_NOT_FOUND
            )
        serializer = JobOfferDetailSerializer(offer)
        return Response(serializer.data, status=status.HTTP_200_OK)


# notification (genere + afficher ) company


class ApplyJobOfferView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, offer_id):
        user = request.user
        if getattr(user, "user_type", None) != "candidate":
            return Response(
                {"detail": "Seuls les candidats peuvent postuler."},
                status=status.HTTP_403_FORBIDDEN,
            )
        try:
            offer = JobOffer.objects.select_related("company").get(id=offer_id)
        except JobOffer.DoesNotExist:
            return Response(
                {"detail": "Offre non trouvée."}, status=status.HTTP_404_NOT_FOUND
            )
        company_profile = offer.company

        # Récupère le profil candidat lié à l'utilisateur
        candidate_profile = getattr(user, "candidate_profile", None)
        if not candidate_profile:
            return Response(
                {"detail": "Profil candidat introuvable."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Génère le message personnalisé
        message = f"The candidate {user.username} has been applied for your job offer."

        # Crée la notification
        CompanyNotification.objects.create(
            company=company_profile,
            candidate=candidate_profile,  # <-- Correction ici !
            job_offer=offer,
            message=message,
        )
        return Response(
            {
                "message": "Votre candidature a été envoyée et la notification a été générée."
            },
            status=status.HTTP_201_CREATED,
        )


class CompanyNotificationListView(generics.ListAPIView):
    serializer_class = CompanyNotificationSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        # Vérifie que l'utilisateur est bien une entreprise
        if getattr(user, "user_type", None) != "company":
            return CompanyNotification.objects.none()
        return CompanyNotification.objects.filter(company__user=user)


class CompanyNotificationDeleteView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def delete(self, request, notification_id):
        user = request.user
        if getattr(user, "user_type", None) != "company":
            return Response(
                {"detail": "Accès refusé."}, status=status.HTTP_403_FORBIDDEN
            )
        try:
            notification = CompanyNotification.objects.get(
                id=notification_id, company__user=user
            )
        except CompanyNotification.DoesNotExist:
            return Response(
                {"detail": "Notification introuvable."},
                status=status.HTTP_404_NOT_FOUND,
            )
        notification.delete()
        return Response(
            {"message": "Notification supprimée avec succès."},
            status=status.HTTP_204_NO_CONTENT,
        )


from django.contrib.auth import get_user_model


class TalentPagination(PageNumberPagination):
    page_size = 5
    page_size_query_param = "page_size"


class TalentListView(ListAPIView):
    serializer_class = TalentCandidateSerializer
    permission_classes = [IsAuthenticated]
    pagination_class = TalentPagination

    def get_queryset(self):
        User = get_user_model()
        return (
            User.objects.filter(
                user_type="candidate",
                candidate_cv__isnull=False,
                candidate_profile__isnull=False,
            )
            .select_related("candidate_cv", "candidate_profile")
            .order_by("-candidate_cv__rating", "candidate_profile__full_name")
        )


class CandidateDetailView(APIView):
    def get(self, request, candidate_id):
        User = get_user_model()
        try:
            user = User.objects.get(id=candidate_id, user_type="candidate")
        except User.DoesNotExist:
            return Response(
                {"detail": "Candidat non trouvé."}, status=status.HTTP_404_NOT_FOUND
            )

        candidate_profile = getattr(user, "candidate_profile", None)
        candidate_cv = getattr(user, "candidate_cv", None)

        data = {"candidate_profile": candidate_profile, "candidate_cv": candidate_cv}
        serializer = CandidateDetailSerializer(data)
        return Response(serializer.data, status=status.HTTP_200_OK)


class DownloadCVFileView(APIView):
    permission_classes = [permissions.AllowAny]  # Ou AllowAny si besoin

    def get(self, request, candidate_id):
        try:
            cv = CandidateCV.objects.get(user__id=candidate_id)
        except CandidateCV.DoesNotExist:
            raise Http404("CV introuvable.")

        if not cv.cv_file:
            return Response(
                {"detail": "Ce candidat n'a pas de CV."},
                status=status.HTTP_404_NOT_FOUND,
            )

        return FileResponse(
            cv.cv_file.open("rb"),
            as_attachment=True,
            filename=cv.cv_file.name.split("/")[-1],
        )


class ApplyToCandidateView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, candidate_id):
        user = request.user
        if getattr(user, "user_type", None) != "company":
            return Response(
                {"detail": "Seules les entreprises peuvent utiliser ce bouton."},
                status=status.HTTP_403_FORBIDDEN,
            )
        try:
            candidate_profile = CandidateProfile.objects.get(id=candidate_id)
        except CandidateProfile.DoesNotExist:
            return Response(
                {"detail": "Candidat non trouvé."}, status=status.HTTP_404_NOT_FOUND
            )
        company_profile = CompanyProfile.objects.get(user=user)
        message = f"The company {company_profile.name} would like to interview you."
        CandidateNotification.objects.create(
            candidate=candidate_profile, company=company_profile  # <-- correction ici
        )
        return Response(
            {"message": "Notification envoyée au candidat."},
            status=status.HTTP_201_CREATED,
        )


from rest_framework import generics, permissions
from .models import CandidateNotification
from .serializers import CandidateNotificationSerializer


class CandidateNotificationListView(generics.ListAPIView):
    serializer_class = CandidateNotificationSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        candidate_profile = getattr(user, "candidate_profile", None)
        if not candidate_profile:
            return CandidateNotification.objects.none()
        return CandidateNotification.objects.filter(
            candidate=candidate_profile
        ).order_by("-created_at")


class CandidateNotificationDeleteView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def delete(self, request, notification_id):
        user = request.user
        try:
            notif = CandidateNotification.objects.get(
                id=notification_id, candidate=user
            )
        except CandidateNotification.DoesNotExist:
            return Response(
                {"detail": "Notification introuvable."},
                status=status.HTTP_404_NOT_FOUND,
            )
        notif.delete()
        return Response(
            {"message": "Notification supprimée."}, status=status.HTTP_204_NO_CONTENT
        )


from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions

class CandidatePhotoUploadView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def patch(self, request):
        profile = request.user.candidate_profile
        serializer = CandidatePhotoUploadSerializer(profile, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({"message": "Photo de profil mise à jour avec succès."})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



# manger views


# class CompanyManagerViewSet(viewsets.ModelViewSet):
#     queryset = CompanyProfile.objects.all()
#     serializer_class = CompanyListSerializer
#     permission_classes = [IsManager]  # <-- Seuls les managers accèdent à cette vue

#     def destroy(self, request, *args, **kwargs):
#         instance = self.get_object()
#         instance.delete()
#         return Response({"message": "Entreprise supprimée avec succès."}, status=204)
from rest_framework.generics import ListAPIView, DestroyAPIView
from .models import CompanyProfile
from .serializers import CompanyListSerializer
from rest_framework.permissions import IsAuthenticated, BasePermission
class IsManager(BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and getattr(request.user, 'user_type', None) == 'manager'

class CompanyListView(ListAPIView):
    queryset = CompanyProfile.objects.all()
    serializer_class = CompanyListSerializer
    permission_classes = [IsManager]

class CompanyDeleteView(DestroyAPIView):
    queryset = CompanyProfile.objects.all()
    serializer_class = CompanyListSerializer
    permission_classes = [IsManager]

class CandidateListView(ListAPIView):
    queryset = CandidateProfile.objects.all()
    serializer_class = CandidateListSerializer
    permission_classes = [IsManager]

class CandidateDeleteView(DestroyAPIView):
    queryset = CandidateProfile.objects.all()
    serializer_class = CandidateListSerializer
    permission_classes = [IsManager]

class CandidateFeedbackListView(ListAPIView):
    queryset = CandidateFeedback.objects.all()
    serializer_class = CandidateFeedbackManagerSerializer
    permission_classes = [IsManager]

class CandidateFeedbackDeleteView(DestroyAPIView):
    queryset = CandidateFeedback.objects.all()
    serializer_class = CandidateFeedbackManagerSerializer
    permission_classes = [IsManager]

class CompanyFeedbackListView(ListAPIView):
    queryset = CompanyFeedback.objects.all()
    serializer_class = CompanyFeedbackManagerSerializer
    permission_classes = [IsManager]

class CompanyFeedbackDeleteView(DestroyAPIView):
    queryset = CompanyFeedback.objects.all()
    serializer_class = CompanyFeedbackManagerSerializer
    permission_classes = [IsManager]


from rest_framework.generics import ListAPIView
from rest_framework.permissions import BasePermission
from .models import CandidateProfile
from .serializers import CandidateApplicationManagerSerializer

class IsManager(BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and getattr(request.user, 'user_type', None) == 'manager'

class CandidateApplicationManagerListView(ListAPIView):
    serializer_class = CandidateApplicationManagerSerializer
    permission_classes = [IsManager]

    def get_queryset(self):
        # Annotate le rating du CV lié pour trier
        from django.db.models import OuterRef, Subquery, FloatField
        from .models import CandidateCV

        cv_rating = CandidateCV.objects.filter(user=OuterRef('user')).values('rating')
        return CandidateProfile.objects.annotate(
            cv_rating=Subquery(cv_rating[:1], output_field=FloatField())
        ).order_by('-cv_rating', 'id')  # Tri décroissant sur le rating du CV

class OpportunityOfferManagerListView(ListAPIView):
    serializer_class = OpportunityOfferManagerSerializer
    permission_classes = [IsManager]

    def get_queryset(self):
        return JobOffer.objects.all().order_by('-created_at')


class JobOfferManagerListView(ListAPIView):
    serializer_class = JobOfferManagementSerializer
    permission_classes = [IsManager]

    def get_queryset(self):
        return JobOffer.objects.all().order_by('-created_at')

class JobOfferManagerDeleteView(DestroyAPIView):
    queryset = JobOffer.objects.all()
    serializer_class = JobOfferManagementSerializer
    permission_classes = [IsManager]

class JobOfferManagerAcceptView(APIView):
    permission_classes = [IsManager]

    def post(self, request, pk):
        try:
            offer = JobOffer.objects.get(pk=pk)
        except JobOffer.DoesNotExist:
            return Response({'error': 'Offer not found.'}, status=status.HTTP_404_NOT_FOUND)
        offer.is_approved = True
        offer.save()
        return Response({'message': 'Offer accepted.'}, status=status.HTTP_200_OK)