from rest_framework import serializers
from .models import CompanyNotification, User, CandidateProfile, CompanyProfile
from django.contrib.auth.hashers import make_password

# --- CANDIDATE ---

class CandidateSignupSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)
    full_name = serializers.CharField(write_only=True)
    phone = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = ['full_name', 'email', 'phone', 'password']

    def create(self, validated_data):
        full_name = validated_data.pop('full_name')
        phone = validated_data.pop('phone')
        email = validated_data['email']
        username = email  # username = email pour unicité
        user = User.objects.create_user(
            email=email,
            username=username,
            user_type='candidate',
            password=validated_data['password']
        )
        CandidateProfile.objects.create(user=user, full_name=full_name, phone=phone)
        return user

class CandidateLoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True)

# --- COMPANY ---

class CompanySignupSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)
    name = serializers.CharField(write_only=True)
    phone = serializers.CharField(write_only=True)
    address = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = ['name', 'email', 'phone', 'address', 'password']

    def create(self, validated_data):
        name = validated_data.pop('name')
        phone = validated_data.pop('phone')
        address = validated_data.pop('address')
        email = validated_data['email']
        username = email
        user = User.objects.create_user(
            email=email,
            username=username,
            user_type='company',
            password=validated_data['password']
        )
        CompanyProfile.objects.create(user=user, name=name, phone=phone, address=address)
        return user

class CompanyLoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True)


from rest_framework import serializers

class ManagerLoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True)


from rest_framework import serializers
from django.contrib.auth.hashers import make_password
from .models import User, CandidateProfile
class CandidateSettingsSerializer(serializers.Serializer):
    email = serializers.EmailField(required=False)
    phone = serializers.CharField(required=False)
    new_password = serializers.CharField(write_only=True, required=False)
    confirm_password = serializers.CharField(write_only=True, required=False)

    def validate(self, data):
        new_password = data.get("new_password")
        confirm_password = data.get("confirm_password")
        if new_password or confirm_password:
            if new_password != confirm_password:
                raise serializers.ValidationError("Passwords do not match.")
        return data

    def update(self, instance, validated_data):
        # instance = user
        if "email" in validated_data:
            instance.email = validated_data["email"]
        if "new_password" in validated_data:
            instance.password = make_password(validated_data["new_password"])
        instance.save()
        # MAJ du profil candidat
        profile = getattr(instance, "candidate_profile", None)
        if profile and "phone" in validated_data:
            profile.phone = validated_data["phone"]
            profile.save()
        return instance


from rest_framework import serializers
from django.contrib.auth.hashers import make_password
from .models import User, CompanyProfile

class CompanySettingsSerializer(serializers.Serializer):
    email = serializers.EmailField(required=False)
    address = serializers.CharField(required=False)
    new_password = serializers.CharField(write_only=True, required=False)
    confirm_password = serializers.CharField(write_only=True, required=False)

    def validate(self, data):
        if data.get("new_password") or data.get("confirm_password"):
            if data.get("new_password") != data.get("confirm_password"):
                raise serializers.ValidationError("Passwords do not match.")
        return data

    def update(self, instance, validated_data):
        # instance = user
        if "email" in validated_data:
            instance.email = validated_data["email"]
        if "new_password" in validated_data:
            instance.password = make_password(validated_data["new_password"])
        instance.save()
        # MAJ du profil company
        profile = getattr(instance, "company_profile", None)
        if profile and "address" in validated_data:
            profile.address = validated_data["address"]
            profile.save()
        return instance


from rest_framework import serializers
from django.contrib.auth.hashers import make_password
from .models import User

class ManagerSettingsSerializer(serializers.Serializer):
    email = serializers.EmailField(required=False)
    new_password = serializers.CharField(write_only=True, required=False)
    confirm_password = serializers.CharField(write_only=True, required=False)

    def validate(self, data):
        if data.get("new_password") or data.get("confirm_password"):
            if data.get("new_password") != data.get("confirm_password"):
                raise serializers.ValidationError("Passwords do not match.")
        return data

    def update(self, instance, validated_data):
        if "email" in validated_data:
            instance.email = validated_data["email"]
        if "new_password" in validated_data:
            instance.password = make_password(validated_data["new_password"])
        instance.save()
        return instance


from rest_framework import serializers
from .models import CandidateProfile, CandidateCV

# --- CV ---
class CandidateCVSerializer(serializers.ModelSerializer):
    class Meta:
        model = CandidateCV
        fields = ['cv_file', 'domain', 'education_level', 'years_of_experience', 'status']

# --- Données personnelles ---
class CandidateProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = CandidateProfile
        exclude = ['user']

# --- Préférences d’embauche ---
class CandidateHiringPreferenceSerializer(serializers.ModelSerializer):
    class Meta:
        model = CandidateProfile
        fields = ['work_type', 'desired_wage']


from rest_framework import serializers
from .models import CompanyProfile, JobOffer, Requirement, Advantage

# --- Édition des données entreprise ---
class EditCompanyDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = CompanyProfile
        fields = [
            "name", "github_link", "facebook_link", "linkedin_link", "profile_picture"
        ]
        extra_kwargs = {
            "name": {"required": False, "allow_blank": True},
            "github_link": {"required": False, "allow_blank": True},
            "facebook_link": {"required": False, "allow_blank": True},
            "linkedin_link": {"required": False, "allow_blank": True},
            "profile_picture": {"required": False, "allow_null": True},  # PAS allow_blank ici
        }


# --- Édition/offre d'emploi ---
class EditJobOfferSerializer(serializers.ModelSerializer):
    class Meta:
        model = JobOffer
        fields = [
            "domain",
            "position",
            "number_of_positions",
            "education_level",
            "contract_type",
            "expiration",
            "is_telecommuting",
            "years_of_experience",
        ]
        extra_kwargs = {
            "domain": {"required": False, "allow_blank": True},
            "position": {"required": False, "allow_blank": True},
            "education_level": {"required": False, "allow_blank": True},
            "contract_type": {"required": False, "allow_blank": True},
            "number_of_positions": {"required": False, "allow_null": True},
            "expiration": {"required": False, "allow_null": True},
            "is_telecommuting": {"required": False, "allow_null": True},
            "years_of_experience": {"required": False, "allow_null": True},
        }


# --- Ajout/édition d'une exigence ---
class AddRequirementSerializer(serializers.ModelSerializer):
    class Meta:
        model = Requirement
        fields = ["text"]
        extra_kwargs = {"text": {"required": False, "allow_null": True, "allow_blank": True}}

# --- Ajout/édition d'un avantage ---
class AddAdvantageSerializer(serializers.ModelSerializer):
    class Meta:
        model = Advantage
        fields = ["text"]
        extra_kwargs = {"text": {"required": False, "allow_null": True, "allow_blank": True}}

class CompanyProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = CompanyProfile
        fields = [
            'name', 'phone', 'address', 'github_link',
            'facebook_link', 'linkedin_link', 'profile_picture'
        ]


from rest_framework import serializers
from .models import CandidateFeedback, CompanyFeedback

class CandidateFeedbackSerializer(serializers.ModelSerializer):
    class Meta:
        model = CandidateFeedback
        fields = ['first_name', 'last_name', 'email', 'phone', 'message']

class CompanyFeedbackSerializer(serializers.ModelSerializer):
    class Meta:
        model = CompanyFeedback
        fields = ['company_name', 'email', 'phone', 'message']




class CandidateHomeSerializer(serializers.ModelSerializer):
    domainOfCV = serializers.CharField(source='candidate_cv.domain', allow_null=True)
    education_level = serializers.CharField(source='candidate_cv.education_level', allow_null=True)
    year_of_experience = serializers.IntegerField(source='candidate_cv.years_of_experience', allow_null=True)
    statut = serializers.CharField(source='candidate_cv.status', allow_null=True)
    rating = serializers.FloatField(source='candidate_cv.rating', allow_null=True, required=False)  # Ajoute ce champ dans le modèle si besoin

    class Meta:
        model = CandidateProfile
        fields = [
            'full_name',
            'domainOfCV',
            'rating',
            'statut',
            'education_level',
            'year_of_experience',
        ]


from rest_framework import serializers

class TopCandidateSerializer(serializers.Serializer):
    full_name = serializers.CharField()
    domain = serializers.CharField(source='candidate_cv.domain', allow_null=True)
    rating = serializers.FloatField(source='candidate_cv.rating', allow_null=True, required=False)
    status = serializers.CharField(source='candidate_cv.status', allow_null=True)
    education_level = serializers.CharField(source='candidate_cv.education_level', allow_null=True)
    years_of_experience = serializers.IntegerField(source='candidate_cv.years_of_experience', allow_null=True)
    cv_type = serializers.CharField(source='candidate_cv.cv_type', allow_null=True)


class OpportunityOfferSerializer(serializers.Serializer):
    position = serializers.CharField()
    company_name = serializers.CharField(source='company.name')
    company_address = serializers.CharField(source='company.address')
    domain = serializers.CharField()
    expiration_date = serializers.DateField(source='expiration')
    education_level = serializers.CharField()
    telecommuting = serializers.BooleanField(source='is_telecommuting')
    years_of_experience = serializers.IntegerField()


from rest_framework import serializers
from .models import JobOffer, Requirement, Advantage

class RequirementSerializer(serializers.ModelSerializer):
    class Meta:
        model = Requirement
        fields = ['text']

class AdvantageSerializer(serializers.ModelSerializer):
    class Meta:
        model = Advantage
        fields = ['text']

class CompanyInfoSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(source='user.email', read_only=True)

    class Meta:
        model = CompanyProfile
        fields = [
            'name',
            'address',
            'phone',
            'email',
            'facebook_link',
            'github_link',
            'linkedin_link',
            'profile_picture'
        ]

class JobOfferDetailSerializer(serializers.ModelSerializer):
    company = CompanyInfoSerializer(read_only=True)
    requirements = RequirementSerializer(many=True, read_only=True)
    advantages = AdvantageSerializer(many=True, read_only=True)

    class Meta:
        model = JobOffer
        fields = [
            'position',
            'company',
            'contract_type',
            'number_of_positions',
            'education_level',
            'expiration',
            'requirements',
            'advantages'
        ]

#notifications
class CompanyNotificationSerializer(serializers.ModelSerializer):
    candidate_username = serializers.CharField(source='candidate.username', read_only=True)
    job_offer_title = serializers.CharField(source='job_offer.position', read_only=True)

    class Meta:
        model = CompanyNotification
        fields = ['id', 'message', 'candidate_username', 'job_offer_title', 'is_read', 'created_at']



from rest_framework import serializers

class TalentCandidateSerializer(serializers.Serializer):
    full_name = serializers.CharField(source='candidate_profile.full_name')
    domain = serializers.CharField(source='candidate_cv.domain', allow_null=True)
    rating = serializers.FloatField(source='candidate_cv.rating', allow_null=True)
    statut = serializers.CharField(source='candidate_cv.status', allow_null=True)
    education_level = serializers.CharField(source='candidate_cv.education_level', allow_null=True)
    years_of_experience = serializers.IntegerField(source='candidate_cv.years_of_experience', allow_null=True)
    cv_type = serializers.CharField(source='candidate_cv.cv_type', allow_null=True)


class CandidateProfileSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(source='user.email', read_only=True)
    github_link = serializers.CharField(read_only=True)
    facebook_link = serializers.CharField(read_only=True)
    linkedin_link = serializers.CharField(read_only=True)
    photo = serializers.ImageField(read_only=True, use_url=True)

    class Meta:
        model = CandidateProfile
        fields = [
            'full_name', 'email', 'phone', 'address',
            'github_link', 'facebook_link', 'linkedin_link',
            'photo', 'military_service', 'driving_license', 'handicap_situation',
            'desired_wage'
        ]

class CandidateCVSerializer(serializers.ModelSerializer):
    class Meta:
        model = CandidateCV
        fields = [
            'domain', 'education_level', 'years_of_experience', 'status',
            'is_telecommuting', 'cv_file', 'cv_type'
        ]

class CandidateDetailSerializer(serializers.Serializer):
    personal_info = CandidateProfileSerializer(source='candidate_profile')
    professional_info = CandidateCVSerializer(source='candidate_cv')


from rest_framework import serializers
from .models import CandidateNotification

class CandidateNotificationSerializer(serializers.ModelSerializer):
    company_name = serializers.CharField(source='company.name', read_only=True)
    class Meta:
        model = CandidateNotification
        fields = ['id', 'message', 'company_name', 'is_read', 'created_at']

from rest_framework import generics, permissions
class JobOfferListSerializer(serializers.ModelSerializer):
    class Meta:
        model = JobOffer
        fields = [
            'id', 'domain', 'position', 'number_of_positions', 'education_level',
            'contract_type', 'expiration', 'is_approved', 'is_telecommuting',
            'years_of_experience', 'created_at'
        ]

class CompanyJobOfferListView(generics.ListAPIView):
    serializer_class = JobOfferListSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        company_profile = CompanyProfile.objects.get(user=user)
        return JobOffer.objects.filter(company=company_profile).order_by('-created_at')


class CandidatePhotoUploadSerializer(serializers.ModelSerializer):
    class Meta:
        model = CandidateProfile
        fields = ['photo']


#        manger
class CompanyListSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(source='user.email', read_only=True)
    phone_number = serializers.CharField(source='phone', read_only=True)

    class Meta:
        model = CompanyProfile
        fields = ['id', 'name', 'email', 'phone_number', 'address']

class CandidateListSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(source='user.email', read_only=True)

    class Meta:
        model = CandidateProfile
        fields = ['id', 'full_name', 'email', 'phone']

class CandidateFeedbackManagerSerializer(serializers.ModelSerializer):
    full_name = serializers.CharField(source='candidate.full_name', read_only=True)
    email = serializers.EmailField(source='candidate.user.email', read_only=True)
    phone_number = serializers.CharField(source='candidate.phone', read_only=True)

    class Meta:
        model = CandidateFeedback
        fields = ['id', 'full_name', 'email', 'phone_number', 'message']

class CompanyFeedbackManagerSerializer(serializers.ModelSerializer):
    company_name = serializers.CharField(source='company.name', read_only=True)
    email = serializers.EmailField(source='company.user.email', read_only=True)
    phone_number = serializers.CharField(source='company.phone', read_only=True)

    class Meta:
        model = CompanyFeedback
        fields = ['id', 'company_name', 'email', 'phone_number', 'message'] 


class CandidateApplicationManagerSerializer(serializers.ModelSerializer):
    domainOfCV = serializers.SerializerMethodField()
    education_level = serializers.SerializerMethodField()
    year_of_experience = serializers.SerializerMethodField()
    statut = serializers.SerializerMethodField()
    rating = serializers.SerializerMethodField()

    class Meta:
        model = CandidateProfile
        fields = [
            'id',
            'full_name',
            'domainOfCV',
            'rating',
            'statut',
            'education_level',
            'year_of_experience',
        ]

    def get_domainOfCV(self, obj):
        return getattr(getattr(obj, 'user', None), 'candidate_cv', None) and obj.user.candidate_cv.domain

    def get_education_level(self, obj):
        return getattr(getattr(obj, 'user', None), 'candidate_cv', None) and obj.user.candidate_cv.education_level

    def get_year_of_experience(self, obj):
        return getattr(getattr(obj, 'user', None), 'candidate_cv', None) and obj.user.candidate_cv.years_of_experience

    def get_statut(self, obj):
        return getattr(getattr(obj, 'user', None), 'candidate_cv', None) and obj.user.candidate_cv.status

    def get_rating(self, obj):
        return getattr(getattr(obj, 'user', None), 'candidate_cv', None) and obj.user.candidate_cv.rating

class OpportunityOfferManagerSerializer(serializers.ModelSerializer):
    company_name = serializers.CharField(source='company.name')
    company_address = serializers.CharField(source='company.address')
    expiration_date = serializers.DateField(source='expiration')
    telecommuting = serializers.BooleanField(source='is_telecommuting')

    class Meta:
        model = JobOffer
        fields = [
            'id',
            'position',
            'company_name',
            'company_address',
            'domain',
            'expiration_date',
            'education_level',
            'telecommuting',
            'years_of_experience',
            'is_approved'
        ]


class JobOfferManagementSerializer(serializers.ModelSerializer):
    company_name = serializers.CharField(source='company.name', read_only=True)
    company_address = serializers.CharField(source='company.address', read_only=True)

    class Meta:
        model = JobOffer
        fields = [
            'id', 'position', 'company_name', 'company_address',
            'domain', 'expiration', 'education_level',
            'is_telecommuting', 'years_of_experience', 'created_at',
            'is_approved', 'number_of_positions', 'contract_type'
        ]