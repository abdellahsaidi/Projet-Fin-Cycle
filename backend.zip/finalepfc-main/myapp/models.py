from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin

class UserManager(BaseUserManager):
    def create_user(self, email, username, user_type, password=None, **extra_fields):
        if not email:
            raise ValueError('Email obligatoire')
        if not username:
            raise ValueError('Nom d’utilisateur obligatoire')
        if not user_type:
            raise ValueError('Type utilisateur obligatoire')
        email = self.normalize_email(email)
        user = self.model(email=email, username=username, user_type=user_type, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, username, user_type='candidate', password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        return self.create_user(email, username, user_type, password, **extra_fields)

class User(AbstractBaseUser, PermissionsMixin):
    USER_TYPE_CHOICES = (
        ('candidate', 'Candidate'),
        ('company', 'Company'),
        ('manager', 'Manager'),
        ('admin', 'Admin'),
    )
    email = models.EmailField(unique=True)
    username = models.CharField(max_length=150, unique=True)
    user_type = models.CharField(max_length=20, choices=USER_TYPE_CHOICES)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)

    objects = UserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username', 'user_type']

    def __str__(self):
        return f"{self.username} ({self.user_type})"

# -----------------------
# Candidate Profile & CV
# -----------------------

class CandidateProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='candidate_profile')
    full_name = models.CharField(max_length=255, blank=True, null=True)
    address = models.CharField(max_length=255, blank=True, null=True)
    github_link = models.URLField(blank=True, null=True)
    facebook_link = models.URLField(blank=True, null=True)
    linkedin_link = models.URLField(blank=True, null=True)
    photo = models.ImageField(upload_to="ProfileCandidat/", blank=True, null=True)
    military_service = models.CharField(max_length=50, blank=True, null=True)
    driving_license = models.CharField(max_length=50, blank=True, null=True)
    handicap_situation = models.CharField(max_length=50, blank=True, null=True)
    status = models.CharField(max_length=50, blank=True, null=True)
    work_type = models.CharField(max_length=50, blank=True, null=True)
    desired_wage = models.CharField(max_length=100, blank=True, null=True)
    phone = models.CharField(max_length=20, blank=True, null=True)
    def __str__(self):
        return f"Profil de {self.user.username}"

class CandidateCV(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='candidate_cv')
    cv_file = models.FileField(upload_to="CV/", blank=True, null=True)
    domain = models.CharField(max_length=100, blank=True, null=True)
    education_level = models.CharField(max_length=100, blank=True, null=True)
    years_of_experience = models.PositiveIntegerField(blank=True, null=True)
    rating = models.FloatField(default=0)
    status = models.CharField(max_length=100, blank=True, null=True)
    is_telecommuting = models.BooleanField(default=False)
    cv_type = models.CharField(max_length=100,default="simple")

    def __str__(self):
        return f"CV de {self.user.username}"

# -----------------------
# Company Profile & JobOffer
# -----------------------

class CompanyProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='company_profile')
    name = models.CharField(max_length=255)
    phone = models.CharField(max_length=20, blank=True, null=True)
    address = models.CharField(max_length=255, blank=True, null=True)
    github_link = models.URLField(blank=True, null=True)
    facebook_link = models.URLField(blank=True, null=True)
    linkedin_link = models.URLField(blank=True, null=True)
    profile_picture = models.ImageField(upload_to="ProfileCompany/", blank=True, null=True)

    def __str__(self):
        return self.name

class JobOffer(models.Model):
    company = models.ForeignKey(CompanyProfile, on_delete=models.CASCADE, related_name="job_offers")
    domain = models.CharField(max_length=100, blank=True, null=True)
    position = models.CharField(max_length=100, blank=True, null=True)
    number_of_positions = models.PositiveIntegerField(blank=True, null=True)
    education_level = models.CharField(max_length=100, blank=True, null=True)
    contract_type = models.CharField(max_length=100, blank=True, null=True)
    expiration = models.DateField(blank=True, null=True)
    is_approved = models.BooleanField(default=False)
    is_telecommuting = models.BooleanField(default=False)
    number_of_positions = models.PositiveIntegerField(blank=True, null=True)
    contract_type = models.CharField(max_length=100, blank=True, null=True)
    years_of_experience = models.PositiveIntegerField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.position or 'Sans poste'} at {self.company.name}"

class Requirement(models.Model):
    offer = models.ForeignKey(JobOffer, on_delete=models.CASCADE, related_name="requirements")
    text = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.text or "Sans exigence"

class Advantage(models.Model):
    offer = models.ForeignKey(JobOffer, on_delete=models.CASCADE, related_name="advantages")
    text = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.text or "Sans avantage"



class Manager(User):
    class Meta:
        verbose_name = "Manager"
        verbose_name_plural = "Managers"

    def __str__(self):
        return self.email



class CandidateFeedback(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=20, blank=True, null=True)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Candidate Feedback"
        verbose_name_plural = "Candidate Feedbacks"
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.first_name} {self.last_name} - {self.email}"

class CompanyFeedback(models.Model):
    company_name = models.CharField(max_length=255)
    email = models.EmailField()
    phone = models.CharField(max_length=20, blank=True, null=True)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Company Feedback"
        verbose_name_plural = "Company Feedbacks"
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.company_name} - {self.email}"



class CompanyNotification(models.Model):
    company = models.ForeignKey(
        CompanyProfile, on_delete=models.CASCADE, related_name="notifications"
    )
    candidate = models.ForeignKey(CandidateProfile, on_delete=models.CASCADE)
    job_offer = models.ForeignKey('JobOffer', on_delete=models.CASCADE)
    message = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)

    class Meta:
        ordering = ['-created_at']
        verbose_name = "Company Notification"
        verbose_name_plural = "Company Notifications"

    def __str__(self):
        return f"Notification for {self.company.name} - {self.message}"

class CandidateNotification(models.Model):
    candidate = models.ForeignKey(
        CandidateProfile, on_delete=models.CASCADE, related_name="notifications"
    )
    company = models.ForeignKey(CompanyProfile, on_delete=models.CASCADE)
    job_offer = models.ForeignKey(JobOffer, on_delete=models.CASCADE, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)
    message = models.TextField(blank=True, null=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = "Candidate Notification"
        verbose_name_plural = "Candidate Notifications"

    def __str__(self):
        return f"Notification for {self.candidate.full_name} - {self.message}"


