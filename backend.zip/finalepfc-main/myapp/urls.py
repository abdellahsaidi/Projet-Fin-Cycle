from django.urls import path

from myapp.serializers import CompanyJobOfferListView
from .views import (
    ApplyToCandidateView, CandidateApplicationManagerListView, CandidateDeleteView, CandidateDetailView, CandidateFeedbackView, CandidateHomeView, CandidateListView, CandidateNotificationDeleteView, CandidateNotificationListView, CandidatePhotoUploadView, CandidateSignupView, CandidateLoginView, CandidateLogoutView, CompanyDeleteView, CompanyFeedbackView, CompanyFullProfileView, CompanyHomeView, CompanyListView, CompanyNotificationDeleteView, CompanySettingsView,
    CompanySignupView, CompanyLoginView, CompanyLogoutView, DownloadCVFileView, JobOfferDetailView,
    ManagerLoginView, ManagerLogoutView, CandidateSettingsView, ManagerSettingsView,
    CandidateCVUpdateView,
    CandidateProfileUpdateView,
    CandidateHiringPreferenceUpdateView,
    CandidateFullProfileView,
    EditCompanyDataView,
    EditJobOfferView,
    AddRequirementView,
    AddAdvantageView, OpportunitiesFiltersView, OpportunitiesListView,
    ApplyJobOfferView, CompanyNotificationListView, OpportunityOfferManagerListView, TalentListView,
    CandidateFeedbackListView, CandidateFeedbackDeleteView,
    CompanyFeedbackListView, CompanyFeedbackDeleteView,
    JobOfferManagerListView,
    JobOfferManagerDeleteView,
    JobOfferManagerAcceptView
)
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView

from myapp import views

urlpatterns = [
    # Candidate
    path('candidat/signup/', CandidateSignupView.as_view(), name='candidat-signup'),
    path('candidat/login/', CandidateLoginView.as_view(), name='candidat-login'),
    path('candidat/logout/', CandidateLogoutView.as_view(), name='candidat-logout'),
    path('candidat/settings/', CandidateSettingsView.as_view(), name='candidat-settings'),
    path('candidat/cv/', CandidateCVUpdateView.as_view(), name='candidat-cv-update'),
    path('candidat/personal/', CandidateProfileUpdateView.as_view(), name='candidat-profile-update'),
    path('candidat/hiring/', CandidateHiringPreferenceUpdateView.as_view(), name='candidat-hiring-update'),
    path('candidat/profile/', CandidateFullProfileView.as_view(), name='candidat-full-profile'),
    path('cv/download/<int:user_id>/', views.download_cv, name='cv-download'),
    path('candidate/feedback/', CandidateFeedbackView.as_view(), name='feedback-candidate'),
    path('candidat/home/', CandidateHomeView.as_view(), name='candidat-home'),
    path('candidat/opportunities/', OpportunitiesListView.as_view(), name='opportunities-list'),
    path('candidat/opportunities/filters/', OpportunitiesFiltersView.as_view(), name='opportunities-filters'),
    path('candidat/offers/<int:offer_id>/', JobOfferDetailView.as_view(), name='offer-detail'),
    path('candidat/offers/<int:offer_id>/apply/', ApplyJobOfferView.as_view(), name='apply-job-offer'),
    path('candidat/<int:candidate_id>/download-cv/', DownloadCVFileView.as_view(), name='download-cvfile'),
    path('candidat/notifications/', CandidateNotificationListView.as_view(), name='candidat-notifications'),
    path('candidat/notifications/<int:notification_id>/delete/', CandidateNotificationDeleteView.as_view(), name='candidat-notification-delete'),
    path('candidat/photo/', CandidatePhotoUploadView.as_view(), name='candidat-photo-upload'),




    # Company
    path('company/signup/', CompanySignupView.as_view(), name='company-signup'),
    path('company/login/', CompanyLoginView.as_view(), name='company-login'),
    path('company/logout/', CompanyLogoutView.as_view(), name='company-logout'),
    path('company/settings/', CompanySettingsView.as_view(), name='company-settings'),
    path('company/data/', EditCompanyDataView.as_view(), name='edit-company-data'),
    path('company/joboffer/', EditJobOfferView.as_view(), name='add-job-offer'),  # pour ajouter
    path('company/joboffer/<int:offer_id>/', EditJobOfferView.as_view(), name='edit-job-offer'),  # pour modifier
    path('company/joboffer/<int:offer_id>/requirement/', AddRequirementView.as_view(), name='add-requirement'),
    path('company/joboffer/<int:offer_id>/advantage/', AddAdvantageView.as_view(), name='add-advantage'),
    path('company/profile/', CompanyFullProfileView.as_view(), name='company-full-profile'),
    path('company/feedback/', CompanyFeedbackView.as_view(), name='feedback-company'),
    path('company/home/', CompanyHomeView.as_view(), name='homecompany'),
    
    path('company/notifications/', CompanyNotificationListView.as_view(), name='company-notifications'),
    path('company/notifications/<int:notification_id>/delete/', CompanyNotificationDeleteView.as_view(), name='company-notification-delete'),
    path('company/talent/', TalentListView.as_view(), name='talent-list'),
    path('company/candidates/<int:candidate_id>/', CandidateDetailView.as_view(), name='candidate-detail'),
    path('company/candidates/<int:candidate_id>/apply/', ApplyToCandidateView.as_view(), name='company-apply-candidate'),
    path('company/joboffers/', CompanyJobOfferListView.as_view(), name='company-joboffer-list'),





    # Manager
    path('manager/login/', ManagerLoginView.as_view(), name='manager-login'),
    path('manager/logout/', ManagerLogoutView.as_view(), name='manager-logout'),
    path('manager/settings/', ManagerSettingsView.as_view(), name='manager-settings'),
    path('manager/companies/', CompanyListView.as_view(), name='manager-companies-list'),
    path('manager/companies/<int:pk>/delete/', CompanyDeleteView.as_view(), name='manager-companies-delete'),
    path('manager/candidates/', CandidateListView.as_view(), name='manager-candidates-list'),
    path('manager/candidates/<int:pk>/delete/', CandidateDeleteView.as_view(), name='manager-candidates-delete'),
    path('manager/feedbacks/candidates/', CandidateFeedbackListView.as_view(), name='manager-candidate-feedback-list'),
    path('manager/feedbacks/candidates/<int:pk>/delete/', CandidateFeedbackDeleteView.as_view(), name='manager-candidate-feedback-delete'),
    path('manager/feedbacks/companies/', CompanyFeedbackListView.as_view(), name='manager-company-feedback-list'),
    path('manager/feedbacks/companies/<int:pk>/delete/', CompanyFeedbackDeleteView.as_view(), name='manager-company-feedback-delete'),
    path('manager/applications/', CandidateApplicationManagerListView.as_view(), name='manager-applications-list'),
    path('manager/joboffers/', OpportunityOfferManagerListView.as_view(), name='manager-joboffers-list'),
    path('manager/joboffers/management/', JobOfferManagerListView.as_view(), name='manager-joboffers-list'),
    path('manager/joboffers/management/<int:pk>/delete/', JobOfferManagerDeleteView.as_view(), name='manager-joboffers-delete'),
    path('manager/joboffers/management/<int:pk>/accept/', JobOfferManagerAcceptView.as_view(), name='manager-joboffers-accept'),

    

    # JWT endpoints (optionnel)
    path('token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
]


