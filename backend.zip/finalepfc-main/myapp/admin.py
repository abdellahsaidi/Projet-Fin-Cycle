from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User, CandidateProfile, CompanyProfile, Manager, CandidateCV, JobOffer, Requirement, Advantage, CandidateFeedback, CompanyFeedback, CandidateNotification, CompanyNotification
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User

class CustomUserAdmin(BaseUserAdmin):
    model = User
    list_display = ('email', 'username', 'user_type', 'is_staff', 'is_superuser')
    list_filter = ('user_type', 'is_staff', 'is_superuser')
    search_fields = ('email', 'username')
    ordering = ('email',)
    fieldsets = (
        (None, {'fields': ('email', 'username', 'user_type', 'password')}),
        ('Permissions', {'fields': ('is_staff', 'is_active', 'is_superuser', 'groups', 'user_permissions')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'username', 'user_type', 'password1', 'password2', 'is_staff', 'is_superuser', 'is_active')}
        ),
    )

admin.site.register(User, CustomUserAdmin)
admin.site.register(CandidateProfile)
admin.site.register(CompanyProfile)
admin.site.register(Manager)
admin.site.register(CandidateCV)
admin.site.register(JobOffer)
admin.site.register(Requirement)
admin.site.register(Advantage)
admin.site.register(CandidateFeedback)
admin.site.register(CompanyFeedback)
admin.site.register(CandidateNotification)
admin.site.register(CompanyNotification)
